import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * 高德 Web服务(REST) 开发代理。
 *
 * 为什么需要它：
 *   1) 浏览器的 fetch 受 CORS 限制，直连 restapi.amap.com 会被拦掉；
 *   2) REST Key 写在 .env 的 AMAP_REST_KEY（**故意不加 VITE_ 前缀**），
 *      只有 Node 侧能读到，由代理注入到查询串 —— 所以它
 *      **不会出现在前端打包产物里**，比浏览器端 JS API Key 更安全。
 *
 * 注意：`npm run build` 产出的静态站点没有这个代理，
 * 届时服务层会自动退回「高德 JS API → 直线估算」，不会崩。
 */
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const restKey = env.AMAP_REST_KEY ?? '';

  return {
    plugins: [react()],
    server: {
      port: 5173,
      host: true,
      proxy: {
        '/amap': {
          target: 'https://restapi.amap.com',
          changeOrigin: true,
          secure: true,
          // 去掉 /amap 前缀，并把 Key 注入查询串
          rewrite: (p: string) => {
            const path = p.replace(/^\/amap/, '');
            if (!restKey) return path;
            return path + (path.includes('?') ? '&' : '?') + 'key=' + restKey;
          },
        },
      },
    },
  };
});
