const NS = 'food-checkin';
const VERSION = 1;

type Key = 'restaurants' | 'plan' | 'params' | 'checkins';

function fullKey(k: Key): string {
  return `${NS}:v${VERSION}:${k}`;
}

export const storage = {
  save<T>(key: Key, value: T): void {
    try {
      localStorage.setItem(fullKey(key), JSON.stringify(value));
    } catch (e) {
      console.warn('存储失败（可能是隐私模式或容量已满）', e);
    }
  },

  load<T>(key: Key, fallback: T): T {
    try {
      const raw = localStorage.getItem(fullKey(key));
      if (raw == null) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },

  remove(key: Key): void {
    localStorage.removeItem(fullKey(key));
  },

  clearAll(): void {
    (Object.keys(localStorage) as string[]).forEach((k) => {
      if (k.startsWith(`${NS}:`)) localStorage.removeItem(k);
    });
  },
};
