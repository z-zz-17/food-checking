/**
 * 路径规划 / POI 服务的统一入口（浏览器端）。
 *
 * 优先级（自动降级，无需配置）：
 *   1) **REST + Vite 代理**（`/amap`）：Key 由代理在服务端注入，前端产物里不含 Key；
 *      四种出行方式都返回真实折线与分段时间 —— 这是本项目的主路径。
 *   2) **高德 JS API**（配了 VITE_AMAP_JS_KEY 时）：静态部署（没有代理）时的备选。
 *   3) **直线估算**：兜底，如实标注 source:'estimate' / estimated:true，
 *      上层据此在反馈里显示「无任何参考价值！！！」。
 *
 * 性能注意（重要）
 *   第 2 步的 JS API 在脚本加载不出来时会等 10 秒超时。如果每一段通勤都去等一次，
 *   3 段就是 30 秒以上，界面看起来就是「卡住/无响应」。
 *   所以 rest/jsp 两条路径都记录「是否可用」：一旦确认不可用就不再重试，
 *   把失败代价从「每段一次」压到「整个会话一次」。
 *
 * 坐标系约定
 *   本文件只做转发与降级，不碰坐标：入参和返回值一律 WGS-84。
 */
import { estimateTravel, MODE_LABEL } from '../algorithms/travel';
import type { TravelMode } from '../types';
import type { PoiCheckResult, PoiInfo, RouteLeg } from '../types/planning';
import { AmapJsService } from './amapJs';
import { hasAmapKey } from './amapLoader';
import { RestRoutingService } from './restRouting';

type Point = { lat: number; lng: number };
type GeocodeResult = { lat: number; lng: number } | null;
type RegeocodeResult = { address: string; city: string | null } | null;
/** 城市提示：公交路径规划需要它（否则跨城公交/地铁拿不到数据，如广佛线） */
type RouteHint = { fromCity?: string | null; toCity?: string | null };

export type RoutingService = {
  /** 真实路径拿不到时会返回估算段（estimated:true）；返回 null 表示连估算都不可用。 */
  route(a: Point, b: Point, mode: TravelMode, hint?: RouteHint): Promise<RouteLeg | null>;
  geocode(address: string): Promise<GeocodeResult>;
  regeocode(p: Point): Promise<RegeocodeResult>;
  aroundRestaurants(center: Point, radiusM: number): Promise<PoiInfo[]>;
  checkPoi(center: Point, radiusM: number): Promise<PoiCheckResult>;
};

/** 开发环境下由 Vite 代理转发到 restapi.amap.com（见 vite.config.ts） */
const REST_BASE = '/amap';

/** 纯本地估算：没有 Key / 全部接口不可用时的最后兜底 */
class FallbackRoutingService implements RoutingService {
  async route(a: Point, b: Point, mode: TravelMode): Promise<RouteLeg | null> {
    // estimateTravel 内部已经乘过 1.3 的绕路系数，这里不要重复乘。
    const leg = estimateTravel(a, b, mode);
    const label =
      mode === 'walk' ? '步行' : mode === 'bike' ? '骑行' : mode === 'drive' ? '驾车' : '公共交通';
    return {
      mode,
      minutes: leg.minutes,
      km: leg.km,
      source: 'estimate',
      estimated: true,
      segments: [
        {
          kind: mode === 'transit' ? ('other' as const) : mode,
          label,
          minutes: leg.minutes,
          km: leg.km,
        },
      ],
      summary: `${MODE_LABEL[mode]} ${leg.km.toFixed(1)}km（估算）`,
    };
  }

  async geocode(_address: string): Promise<GeocodeResult> {
    return null;
  }

  async regeocode(_p: Point): Promise<RegeocodeResult> {
    return null;
  }

  async aroundRestaurants(_center: Point, _radiusM: number): Promise<PoiInfo[]> {
    return [];
  }

  async checkPoi(_center: Point, radiusM: number): Promise<PoiCheckResult> {
    return { isRestaurant: false, radiusM, source: 'estimate' };
  }
}

/**
 * 先 REST，失败则转 JS API，最后退回直线估算。
 * restUsable / jsUsable 各自只在第一次失败时置 false，避免每次请求都白等一遍超时。
 */
class HybridRoutingService implements RoutingService {
  private readonly rest = new RestRoutingService({ baseUrl: REST_BASE });
  private readonly js = new AmapJsService();
  private readonly fallback = new FallbackRoutingService();
  private restUsable: boolean | null = null;
  private jsUsable: boolean | null = null;

  private async viaRest<T>(fn: (s: RestRoutingService) => Promise<T | null>): Promise<T | null> {
    if (this.restUsable === false) return null;
    try {
      const r = await fn(this.rest);
      if (r !== null && r !== undefined) {
        this.restUsable = true;
        return r;
      }
      if (this.restUsable === null) this.restUsable = false;
      return null;
    } catch {
      if (this.restUsable === null) this.restUsable = false;
      return null;
    }
  }

  /** JS API 只在「配了 Key 且没被判定为不可用」时尝试，且失败一次后不再重试 */
  private async viaJs<T>(fn: (s: AmapJsService) => Promise<T | null>): Promise<T | null> {
    if (this.jsUsable === false || !hasAmapKey()) return null;
    try {
      const r = await fn(this.js);
      if (r !== null && r !== undefined) {
        this.jsUsable = true;
        return r;
      }
      if (this.jsUsable === null) this.jsUsable = false;
      return null;
    } catch {
      this.jsUsable = false;
      return null;
    }
  }

  async route(a: Point, b: Point, mode: TravelMode, hint?: RouteHint): Promise<RouteLeg | null> {
    const rest = await this.viaRest((s) => s.route(a, b, mode, hint));
    if (rest) return rest;
    const js = await this.viaJs((s) => s.route(a, b, mode));
    if (js) return js;
    // 最后兜底：给一条直线估算，保证调用方永远拿得到一段通勤
    return this.fallback.route(a, b, mode);
  }

  async geocode(address: string): Promise<GeocodeResult> {
    const rest = await this.viaRest((s) => s.geocode(address));
    if (rest) return rest;
    const js = await this.viaJs((s) => s.geocode(address));
    if (js) return js;
    return null;
  }

  async regeocode(p: Point): Promise<RegeocodeResult> {
    const rest = await this.viaRest((s) => s.regeocode(p));
    if (rest) return rest;
    return this.viaJs((s) => s.regeocode(p));
  }

  async aroundRestaurants(center: Point, radiusM: number): Promise<PoiInfo[]> {
    const rest = await this.viaRest((s) => s.aroundRestaurants(center, radiusM));
    if (rest && rest.length > 0) return rest;
    const js = await this.viaJs((s) => s.aroundRestaurants(center, radiusM));
    return js ?? [];
  }

  async checkPoi(center: Point, radiusM: number): Promise<PoiCheckResult> {
    const rest = await this.viaRest((s) => s.checkPoi(center, radiusM));
    if (rest) return rest;
    const js = await this.viaJs((s) => s.checkPoi(center, radiusM));
    if (js) return js;
    return this.fallback.checkPoi(center, radiusM);
  }
}

/** 单例缓存：服务是无状态的，重复创建只会白建一遍包装。 */
let cached: RoutingService | null = null;

export function getRoutingService(): RoutingService {
  if (!cached) cached = new HybridRoutingService();
  return cached;
}
