/**
 * 高德 JS API 2.0 业务封装（浏览器端）。
 *
 * 坐标系约定（最重要的一条）
 *   项目内部（store / 算法 / 存储 / 导出）统一使用 WGS-84；
 *   高德所有接口只认 GCJ-02（火星坐标）。
 *   因此本文件是全局唯一的转换边界：
 *     · 调高德之前：wgs84ToGcj02 把 WGS-84 入参转成 GCJ-02；
 *     · 拿到结果之后：gcj02ToWgs84 把坐标转回 WGS-84 再返回。
 *   对外暴露的所有 lat/lng 永远是 WGS-84（包括 RouteLeg.path 的每一个折线点）；
 *   绕过本文件直接调高德会引入数百米偏移。
 *
 * 降级行为（全部 resolve，绝不 reject）
 *   · 没有 Key，或 SDK 加载失败/超时（见 amapLoader.ts）：所有方法直接返回空结果——
 *     route / geocode / regeocode → null，aroundRestaurants → []，
 *     checkPoi → { isRestaurant: false, source: 'estimate' }。
 *   · route 的返回类型放宽为 Promise<RouteLeg | null>（契约允许这样写）：
 *     null 表示「拿不到真实路况」，请调用方用 algorithms/travel.estimateTravel 自行降级。
 *   · 单次请求异常、AMap 返回非 complete 状态、或超过 12s 未回调，都只 warn 并返回空结果。
 *   · source 恒为 'amap' 且 estimated: false —— 本文件只透传高德真实数据，绝不谎报来源。
 *
 * RouteLeg.segments 填充规则
 *   · 步行 / 骑行 / 驾车：整段合并为 1 条
 *     { kind: 'walk'|'bike'|'drive', label: '步行'|'骑行'|'驾车', minutes, km }，
 *     km 取该段总 distance；不把 steps 展开成几十条（反馈会冗长到没法看），
 *     steps 只用来拼折线 path。
 *   · 公共交通（AMap.Transfer）：按真实乘坐顺序逐段展开
 *       有 walking 字段        → kind 'walk'（路名拿得到时 label = '步行 <路名>'）
 *       有 bus 字段            → 线路名去掉括号起终点后按线路特征判 kind
 *                                （地铁/轨道 → 'subway'，明确铁路 → 'rail'，其余 → 'bus'），
 *                                label = 线路名，from/to = 上/下车站名
 *       有 railway 字段        → kind 'rail'，label = railway.name
 *       其它                   → kind 'other'
 *   · 顺序即乘坐顺序（步行 → 线路 → 步行 → …），不做重排、不做合并。
 *   · 加总一致性：本文件内部保证 Σsegments[i].minutes 与 RouteLeg.minutes 在
 *     0.1 分钟（6 秒）内一致；高德某段缺 time 时按「同 kind 已有时长的比例」分摊
 *     剩余时长；整体 time 缺失但分段有时长时，以分段之和为准。
 *   · minutes / km 统一四舍五入到 1 位小数，避免反馈里出现 12.666666 这种数字。
 *
 * RouteLeg.path 填充规则（WGS-84 折线，供地图画线）
 *   · 步行 / 骑行 / 驾车：把 routes[0].steps[].path（"lng,lat;lng,lat;…"）逐点解析后拼接。
 *   · 公共交通：把 segments[].walking.steps[].path 与 segments[].bus.buslines[0].path
 *     按乘坐顺序拼接（Transfer 每一段自带 path 时优先用它）。
 *   · 每个 GCJ-02 点都单独调用 gcj02ToWgs84 转回 WGS-84；相邻重复点去掉。
 *   · 解析不出来（字段缺失 / 全为非法值）就返回 undefined —— 不编造坐标；
 *     点数超过 PATH_MAX_POINTS 时按 PATH_THIN_STRIDE 抽稀，控制内存与绘制开销。
 *
 * QPS 重试策略
 *   用户的 Key 实测会返回 CUQPS_HAS_EXCEEDED_THE_LIMIT。
 *   本文件不自己并发发起请求（由上层串行调用），并且在 invoke() 里做了单次重试：
 *     · status === 'complete' 但 info/message 命中 QPS 特征，或 status !== 'complete'
 *       但 info/message 命中 QPS 特征 → 等 QPS_RETRY_DELAY_MS(400ms) 重发一次；
 *     · 最多重试 QPS_MAX_RETRIES(1) 次，两次都失败就 resolve(null)，交由上层降级；
 *     · 超时兜底（REQUEST_TIMEOUT_MS = 12s）是「每次尝试」的预算，回调一到就立刻撤销计时器，
 *       所以 QPS 重试的总耗时上界是 400ms + 12s，而不是把两次超时叠加成 24s。
 *
 * 已知事实（安全边界）
 *   这里用的是高德「Web端(JS API)」的浏览器端 Key：打包后 key 与 jscode 会明文出现在
 *   前端产物里（dist），无法保密；只能靠高德控制台的域名白名单 + 安全密钥约束盗用。
 *
 * 关于 any
 *   高德 SDK 没有官方 TypeScript 类型，any 只集中在本文件与 amapLoader.ts 的内部实现中；
 *   所有对 result 的字段访问都通过 g/get 这类访问器收口（见「解析高德返回值」分区），
 *   对外 5 个方法的签名是强类型的，并且结构上满足 services/routing.ts 的 RoutingService。
 */

import { haversineKm, gcj02ToWgs84, wgs84ToGcj02 } from '../algorithms/coords';
import { MODE_LABEL } from '../algorithms/travel';
import type { LegSegment, LegSegmentKind, TravelMode } from '../types';
import type { PoiCheckResult, PoiInfo, RouteLeg } from '../types/planning';
import { loadAmap } from './amapLoader';

/** 50 米内视为「用户点的就是这个位置」。 */
const SNAP_M = 50;
/** 高德餐饮服务大类（本身已含 050500 咖啡 / 050700 冷饮 / 050800 糕饼 / 050900 甜品）。 */
const POI_TYPE_RESTAURANT = '050000';
/** 餐饮大类零召回时的兜底关键词（不限类型搜一次）。 */
const POI_KEYWORD_FALLBACK = '咖啡';
/** 兜底关键词结果必须命中这些字样才算「可定位的餐饮」：咖啡/茶(奶茶)/甜品/烘培/烘焙/面包/糕/饼/饮。 */
const POI_NAME_FALLBACK_RE = /咖啡|茶|甜品|烘培|烘焙|面包|糕|饼|饮/;
const POI_PAGE_SIZE = 20;
/** keyword 留空：类型已经限定为餐饮大类，再传关键词会按名称二次过滤导致漏召回。 */
const POI_KEYWORD = '';
/** 高德 searchNearBy 半径上限（米）。 */
const MAX_SEARCH_RADIUS_M = 50_000;
const DEFAULT_SEARCH_RADIUS_M = 1000;
/** 单次高德请求的兜底超时：宁可降级为估算，也不让 UI 一直转圈。 */
const REQUEST_TIMEOUT_MS = 12_000;
/** QPS 被限流时的重试等待（毫秒）；高德限流窗口很短，400ms 足够跨过去。 */
const QPS_RETRY_DELAY_MS = 400;
/** QPS 限流最多重试次数（总请求数 = 1 + QPS_MAX_RETRIES）。 */
const QPS_MAX_RETRIES = 1;
/** 识别限流错误的特征词。 */
const QPS_ERROR_RE = /CUQPS|LIMIT/i;
/** 路径折线抽稀：点数超过上限后每隔 PATH_THIN_STRIDE 个点保留 1 个，首尾点始终保留。 */
const PATH_MAX_POINTS = 2000;
const PATH_THIN_STRIDE = 2;
/** minutes / km 统一保留的小数位。 */
const DECIMALS = 1;
/** 公交摘要最多取几段、每段最多几个字、全文最多几个字。 */
const SUMMARY_MAX_PARTS = 3;
const SUMMARY_MAX_SEGMENT_CHARS = 16;
const SUMMARY_MAX_CHARS = 64;
/** 线路名判类特征（地铁/轨道、明确铁路）。 */
const SUBWAY_RE = /地铁|轨道|轻轨|有轨电车|磁浮|捷运|metro|subway|rail\s*transit/i;
const RAIL_RE = /铁路|高铁|城际|动车|railway|high[\s-]?speed|intercity/i;
const KIND_LABEL: Record<LegSegmentKind, string> = {
  walk: '步行',
  bike: '骑行',
  drive: '驾车',
  bus: '公交',
  subway: '地铁',
  rail: '铁路',
  ferry: '轮渡',
  flight: '航班',
  other: '其它',
};
/** 非公交方式 → 单一覆盖整段的分段 kind。 */
const SINGLE_KIND: Record<Exclude<TravelMode, 'transit'>, LegSegmentKind> = {
  walk: 'walk',
  bike: 'bike',
  drive: 'drive',
};

type LatLng = { lat: number; lng: number };
/** 高德服务的统一回调签名：status === 'complete' 时 result 才有效。 */
type AmapCallback = (status: string, result: any) => void;

/** mode → 高德路径规划插件名（类挂在 AMap 命名空间上）。 */
const ROUTE_PLUGIN: Record<TravelMode, string> = {
  walk: 'Walking',
  bike: 'Riding',
  drive: 'Driving',
  transit: 'Transfer',
};

export class AmapJsService {
  /** 已注入的 AMap 命名空间；null 表示尚未加载（惰性加载，loadAmap 自带缓存与并发去重）。 */
  private namespace: any | null = null;

  /**
   * @param AMap 可选的 AMap 命名空间注入（测试/演练用）；
   *             不传时首次调用会通过 amapLoader.loadAmap() 惰性加载。
   */
  constructor(AMap?: any) {
    if (AMap) this.namespace = AMap;
  }

  /**
   * 路径规划。
   * 高德回调里的 time 单位是「秒」、distance 单位是「米」，这里统一转成 minutes / km，
   * 并把 segments（分段明细）与 path（真实折线，WGS-84）一起填好。
   */
  async route(a: LatLng, b: LatLng, mode: TravelMode): Promise<RouteLeg | null> {
    const AMap = await this.ns();
    if (!AMap) return null;

    const Ctor = pickRouteCtor(AMap, mode);
    if (!Ctor) return null;

    try {
      const service = new Ctor({});
      const start = toLngLat(AMap, a);
      const end = toLngLat(AMap, b);
      const result = await this.invoke<any>((done) => service.search(start, end, done));
      if (!result) return null;

      return mode === 'transit'
        ? buildTransitLeg(result)
        : buildSingleModeLeg(result, mode);
    } catch (err) {
      warnDegrade(`「${MODE_LABEL[mode]}」路径规划调用异常`, err);
      return null;
    }
  }

  /** 地址 → 坐标（WGS-84）。查不到 / 异常都返回 null。 */
  async geocode(address: string): Promise<LatLng | null> {
    const text = typeof address === 'string' ? address.trim() : '';
    if (!text) return null;

    const AMap = await this.ns();
    const Geocoder = AMap?.Geocoder;
    if (typeof Geocoder !== 'function') return null;

    try {
      const geocoder = new Geocoder({});
      const result = await this.invoke<any>((done) => geocoder.getLocation(text, done));
      const first = Array.isArray(result?.geocodes) ? result.geocodes[0] : null;
      const point = parseLngLat(first?.location);
      return point ? gcj02ToWgs84(point.lat, point.lng) : null;
    } catch (err) {
      warnDegrade(`地理编码失败（${truncate(text)}）`, err);
      return null;
    }
  }

  /** 坐标（WGS-84）→ 地址 + 城市。查不到 / 异常都返回 null。 */
  async regeocode(p: LatLng): Promise<{ address: string; city: string | null } | null> {
    const AMap = await this.ns();
    const Geocoder = AMap?.Geocoder;
    if (typeof Geocoder !== 'function') return null;

    try {
      const geocoder = new Geocoder({});
      const target = toLngLat(AMap, p);
      const result = await this.invoke<any>((done) => geocoder.getAddress(target, done));
      const regeocode = result?.regeocode;
      const address =
        typeof regeocode?.formattedAddress === 'string' ? regeocode.formattedAddress.trim() : '';
      if (!address) return null;
      return { address, city: pickCity(regeocode?.addressComponent) };
    } catch (err) {
      warnDegrade('逆地理编码调用异常', err);
      return null;
    }
  }

  /**
   * 半径内的餐饮 POI（类型 050000）。
   * 返回的每个 poi 都已经把坐标从 GCJ-02 转回 WGS-84；distanceM 是「到查询点」的米数。
   */
  async aroundRestaurants(center: LatLng, radiusM: number): Promise<PoiInfo[]> {
    const AMap = await this.ns();
    const PlaceSearch = AMap?.PlaceSearch;
    if (typeof PlaceSearch !== 'function') return [];

    try {
      const search = new PlaceSearch({
        type: POI_TYPE_RESTAURANT,
        pageSize: POI_PAGE_SIZE,
        pageIndex: 1,
        extensions: 'all',
      });
      const pois = await this.searchNearBy(search, POI_KEYWORD, center, radiusM);
      return toPoiInfos(pois, center);
    } catch (err) {
      warnDegrade('周边餐饮 POI 搜索异常', err);
      return [];
    }
  }

  /**
   * 点选位置的餐饮判定：半径内最近一家 ≤ SNAP_M(50m) 就算「用户点的就是这家餐厅」。
   * radiusM 原样回传（不做 clamp，clamp 只用于真正发起请求时）。
   *
   * 兜底（需求：咖啡店/奶茶店/面包烘培店/甜品店也要能定位）
   *   虽然 050000 已包含 050500/050700/050800/050900，仍做一次保险：
   *   类型搜索一家都没搜到时，用 AMap.PlaceSearch 的 keyword='咖啡'（不限类型）再搜一次，
   *   名称命中「咖啡|茶|奶茶|甜品|烘培|烘焙|面包|糕|饼|饮」的结果也算候选；
   *   两次都空才返回 nearest: undefined。
   */
  async checkPoi(center: LatLng, radiusM: number): Promise<PoiCheckResult> {
    const AMap = await this.ns();
    // SDK 不可用时说实话：这份结果来自估算而不是高德。
    if (!AMap) return { isRestaurant: false, radiusM, source: 'estimate' };

    try {
      const pois = await this.aroundRestaurants(center, radiusM);
      const candidates = pois.length > 0 ? pois : await this.searchRestaurantsByKeyword(center, radiusM);
      const nearest = pickNearest(candidates);
      if (nearest && nearest.distanceM <= SNAP_M) {
        return { isRestaurant: true, poi: nearest, radiusM, source: 'amap' };
      }
      return nearest
        ? { isRestaurant: false, nearest, radiusM, source: 'amap' }
        : { isRestaurant: false, radiusM, source: 'amap' };
    } catch (err) {
      warnDegrade('餐饮 POI 判定异常', err);
      return { isRestaurant: false, radiusM, source: 'estimate' };
    }
  }

  /**
   * 餐饮大类零召回时的最后一道保险：
   * keyword='咖啡' + 不限类型搜一圈，只保留名称像「咖啡/奶茶/甜品/烘焙/面包…」的 POI。
   * 失败（SDK 无 PlaceSearch / 抛错 / 超时）一律返回 []，由调用方如实返回 nearest: undefined。
   */
  private async searchRestaurantsByKeyword(center: LatLng, radiusM: number): Promise<PoiInfo[]> {
    const AMap = await this.ns();
    const PlaceSearch = AMap?.PlaceSearch;
    if (typeof PlaceSearch !== 'function') return [];

    try {
      // 注意：这里刻意不传 type，才能召回「类型没标成餐饮、但名字是咖啡店」的 POI。
      const search = new PlaceSearch({ pageSize: POI_PAGE_SIZE, pageIndex: 1, extensions: 'all' });
      const pois = await this.searchNearBy(search, POI_KEYWORD_FALLBACK, center, radiusM);
      const out: PoiInfo[] = [];
      for (const poi of pois) {
        const name = typeof poi?.name === 'string' ? poi.name : '';
        if (!POI_NAME_FALLBACK_RE.test(name)) continue;
        const info = toPoiInfo(poi, center);
        if (info) out.push(info);
      }
      return out;
    } catch (err) {
      warnDegrade('餐饮 POI 兜底关键词搜索异常', err);
      return [];
    }
  }

  /** searchNearBy 的共用地基：统一 clamp 半径、统一走 invoke（含超时 + QPS 重试）。 */
  private async searchNearBy(
    search: any,
    keyword: string,
    center: LatLng,
    radiusM: number,
  ): Promise<any[]> {
    const centerGcj = toGcjPair(center);
    const radius = clampRadius(radiusM);
    const result = await this.invoke<any>((done) =>
      search.searchNearBy(keyword, centerGcj, radius, done),
    );
    return Array.isArray(result?.poiList?.pois) ? result.poiList.pois : [];
  }

  /** 惰性获取 AMap 命名空间；加载失败返回 null（不抛错）。 */
  private async ns(): Promise<any | null> {
    if (!this.namespace) {
      const loaded = await loadAmap();
      if (loaded) this.namespace = loaded;
    }
    return this.namespace;
  }

  /**
   * 把高德的回调式 API 包成 Promise，并在同一次调用内处理 QPS 限流重试：
   *   · status === 'complete' 且 result 有效 → resolve(result)；
   *   · info/message 命中 QPS 特征 → 最多重试 QPS_MAX_RETRIES 次（每次等 QPS_RETRY_DELAY_MS），
   *     重试仍失败则 resolve(null)；调用方（上层）串行发起请求，这里不制造并发；
   *   · run() 同步抛错 / 超过 REQUEST_TIMEOUT_MS 未回调 → resolve(null)。
   * 永不 reject。completed 记录「已经结束的尝试次数」，保证最多重试 QPS_MAX_RETRIES 次。
   */
  private invoke<T>(run: (done: AmapCallback) => void): Promise<T | null> {
    return new Promise<T | null>((resolve) => {
      let settled = false;
      let completed = 0;
      /** 当前这一次尝试的超时计时器（只等「这一次」，不是整次逻辑调用）。 */
      let attemptTimer: number | undefined;

      const clearAttemptTimer = (): void => {
        if (attemptTimer !== undefined) {
          window.clearTimeout(attemptTimer);
          attemptTimer = undefined;
        }
      };

      const finish = (value: T | null): void => {
        if (settled) return;
        settled = true;
        clearAttemptTimer();
        resolve(value);
      };

      const done: AmapCallback = (status, result) => {
        // 回调已到，这一次尝试的超时就该立刻撤掉；否则它会一直挂到 12s 后
        // 打出一条「请求超过 12s 未返回」的假警告。
        clearAttemptTimer();
        completed += 1;
        if (status === 'complete' && result) {
          finish(result as T);
          return;
        }
        // 关键：高德限流时 status 可能是 'error'，也可能是 'complete' + 空结果，
        // 所以两种分支都要看 info / message 里有没有 QPS 特征。
        if (isQpsLimited(result) && completed <= QPS_MAX_RETRIES) {
          warnDegrade(
            `高德返回 ${String(g(result, 'info') ?? g(result, 'message'))}（QPS 限流），${QPS_RETRY_DELAY_MS}ms 后重试`,
          );
          attemptTimer = window.setTimeout(() => {
            attemptTimer = undefined;
            send();
          }, QPS_RETRY_DELAY_MS);
          return;
        }
        finish(null);
      };

      const send = (): void => {
        if (settled) return;
        // 每次尝试都有独立的超时保护；QPS 重试时上一次的计时器已经清掉。
        attemptTimer = window.setTimeout(() => {
          attemptTimer = undefined;
          warnDegrade(`高德请求超过 ${REQUEST_TIMEOUT_MS / 1000}s 未返回`);
          finish(null);
        }, REQUEST_TIMEOUT_MS);
        try {
          run(done);
        } catch (err) {
          warnDegrade('高德接口同步抛错', err);
          finish(null);
        }
      };

      send();
    });
  }
}

/* ------------------------------------------------------------------ *
 * 路径规划结果 → RouteLeg
 * ------------------------------------------------------------------ */

/** 步行 / 骑行 / 驾车：返回 1 条覆盖整段的分段 + steps 拼出来的真实折线。 */
function buildSingleModeLeg(result: any, mode: TravelMode): RouteLeg | null {
  const route = pickRoute(result);
  if (!route) return null;

  const km = round1(Number(route.distance) / 1000);
  const minutes = round1(Number(route.time) / 60);
  // 里程和时长都得有效，否则调用方没法用（估算兜底交给上层）。
  if (!isPos(km) || !isPos(minutes)) return null;

  const kind = SINGLE_KIND[mode as Exclude<TravelMode, 'transit'>];
  const segments: LegSegment[] = [{ kind, label: KIND_LABEL[kind], minutes, km }];
  // 需求只要「步行××分钟」这种粒度，steps 展开成几十条只会让反馈无法阅读，
  // 所以这里只保留总段；steps 的唯一用途是拼 path。
  const path = buildPath(collectStepPaths(route));
  return assembleLeg(mode, minutes, km, segments, path);
}

/** 公共交通：按真实乘坐顺序展开 segments，并保证 Σminutes 与总时长一致。 */
function buildTransitLeg(result: any): RouteLeg | null {
  const route = pickRoute(result);
  if (!route) return null;

  const raw = parseTransferSegments(route.segments);
  const minutes = reconcileTotalMinutes(route, raw.segments);
  if (!isPos(minutes)) return null;

  const km = Number(g(route, 'distance')) / 1000;
  const segments = fillSegmentMinutes(raw.segments, minutes, raw.knownMinutes);
  const path = buildPath(collectTransitPaths(route));
  // 公交方案的 distance 偶尔缺失：契约里 km 不是可选字段，给 0 而不是编一个数。
  return assembleLeg('transit', minutes, isPos(km) ? round1(km) : 0, segments, path);
}

/**
 * 组装 RouteLeg。只有真拿到了折线才写 path 字段 —— 契约里 path 是可选字段，
 * 「写个 undefined」和「不写」对画图的调用方没区别，但不写更诚实。
 */
function assembleLeg(
  mode: TravelMode,
  minutes: number,
  km: number,
  segments: LegSegment[],
  path: LatLng[] | undefined,
): RouteLeg {
  const leg: RouteLeg = {
    mode,
    minutes,
    km,
    source: 'amap',
    // 本文件的每个数值都直接来自高德，没有任何估算成分。
    estimated: false,
    segments,
    summary: buildSummary(segments),
  };
  if (path) leg.path = path;
  return leg;
}

/**
 * 摘要文案：直接用 segments 的 label 拼（例如「步行 → 地铁2号线 → 步行」），
 * 这样摘要与「分别时间」明细必然来自同一份数据，不会出现两处口径打架。
 */
function buildSummary(segments: LegSegment[]): string | undefined {
  if (segments.length === 0) return undefined;
  const parts: string[] = [];
  for (const segment of segments) {
    const label = segment.label.trim();
    if (!label || parts[parts.length - 1] === label) continue;
    parts.push(label);
    if (parts.length >= SUMMARY_MAX_PARTS) break;
  }
  if (parts.length === 0) return undefined;
  const text = parts.join(' → ');
  return text.length > SUMMARY_MAX_CHARS ? `${text.slice(0, SUMMARY_MAX_CHARS)}…` : text;
}

/**
 * 解析高德 Transfer 的 segments[]（无官方类型，字段访问全部走 g() 访问器）。
 * 兼容两种线路结构：segment.bus.buslines[0] 与 segment.buslines[0]。
 */
function parseTransferSegments(input: unknown): { segments: LegSegment[]; knownMinutes: number[] } {
  const list: any[] = Array.isArray(input) ? input : [];
  const segments: LegSegment[] = [];
  const knownMinutes: number[] = [];

  for (const item of list) {
    if (!item) continue;

    const walking = g(item, 'walking');
    if (walking) {
      const segment = toWalkSegment(walking);
      if (segment) {
        segments.push(segment);
        knownMinutes.push(segment.minutes);
        continue;
      }
    }

    const busLine = pickBusLine(item);
    if (busLine) {
      segments.push(toBusSegment(item, busLine));
      knownMinutes.push(secondsToMinutes(g(busLine, 'time')));
      continue;
    }

    const railway = g(item, 'railway');
    if (railway) {
      // Transfer 的 railway 段常缺 time；缺失时由 fillSegmentMinutes 分摊补齐。
      const stop = g(railway, 'arrival_stop') ?? g(railway, 'departure_stop');
      segments.push({
        kind: 'rail',
        label: normalizeText(g(railway, 'name')) || KIND_LABEL.rail,
        minutes: secondsToMinutes(g(railway, 'time')),
        km: metersToKm(g(railway, 'distance')),
        from: readStopName(g(railway, 'departure_stop')) ?? undefined,
        to: readStopName(stop) ?? undefined,
      });
      knownMinutes.push(secondsToMinutes(g(railway, 'time')));
      continue;
    }

    // 真实出现的兜底：Structure 变了也不能丢段，否则乘客顺序会错位。
    segments.push({
      kind: 'other',
      label: KIND_LABEL.other,
      minutes: secondsToMinutes(g(item, 'time')),
      km: metersToKm(g(item, 'distance')),
    });
    knownMinutes.push(secondsToMinutes(g(item, 'time')));
  }

  return { segments, knownMinutes };
}

/** 公交子段 → LegSegment（kind 由线路名 / type 特征判定，from/to 取上/下车站名）。 */
function toBusSegment(item: any, busLine: any): LegSegment {
  // label 去掉括号里的起终点：`地铁2号线(犀浦--龙泉驿)` → `地铁2号线`。
  const name = cleanLineName(g(busLine, 'name'));
  const kind = classifyTransit(busLine);
  const stops = readBusStops(item, busLine);
  const label = name || KIND_LABEL[kind];
  return {
    kind,
    label,
    minutes: secondsToMinutes(g(busLine, 'time')),
    km: metersToKm(g(busLine, 'distance')),
    from: stops.from,
    to: stops.to,
  };
}

/** 步行子段 → LegSegment（能拿到路名就写成「步行 XX路」，拿不到就是「步行」）。 */
function toWalkSegment(walking: any): LegSegment | null {
  const minutes = secondsToMinutes(g(walking, 'time'));
  const km = metersToKm(g(walking, 'distance'));
  if (!isPos(minutes) && !isPos(km)) return null;
  const road = readWalkRoad(walking);
  return {
    kind: 'walk',
    label: road ? `${KIND_LABEL.walk} ${road}` : KIND_LABEL.walk,
    minutes,
    km,
  };
}

/**
 * 上/下车站名。兼容三种写法：
 *   segment.bus.buslines[0].departure_stop.name（新）
 *   segment.bus.departure_stop.name（旧）
 *   segment.buslines[0].departure_stop.name
 * 全拿不到时退化为本段起终点（getOrigin/getDestination）。
 */
function readBusStops(item: any, busLine: any): { from?: string; to?: string } {
  const bus = g(item, 'bus');
  const from =
    readStopName(g(busLine, 'departure_stop')) ??
    readStopName(g(bus, 'departure_stop')) ??
    readStopName(g(item, 'departure_stop')) ??
    readStopName(g(bus, 'start')) ??
    readEndpointName(g(busLine, 'start'));
  const to =
    readStopName(g(busLine, 'arrival_stop')) ??
    readStopName(g(bus, 'arrival_stop')) ??
    readStopName(g(item, 'arrival_stop')) ??
    readStopName(g(bus, 'end')) ??
    readEndpointName(g(busLine, 'end'));
  return { from: from ?? undefined, to: to ?? undefined };
}

/**
 * 线路名判类：
 *   · 名称含「地铁 / 轨道 / 轻轨 / metro…」，或 type/category 表明 rail transit → 'subway'
 *   · 名称含「铁路 / 高铁 / 城际 / intercity…」，或 type 以 'railway' 开头 → 'rail'
 *   · 名称含「轮渡 / 船」→ 'ferry'，含「航班 / 飞机」→ 'flight'
 *   · 其余（含只有「xx线」的线索）→ 'bus'
 * 说明：按需求「拿不准就 rail」的备注，这里采取了更保守的口径——只有明确是铁路才给 rail，
 *       因为把城市公交/地铁误标成铁路比标成公交更容易误导用户。
 */
function classifyTransit(busLine: any): LegSegmentKind {
  const type = String(g(busLine, 'type') ?? '');
  const category = String(g(busLine, 'category') ?? '');
  const name = String(g(busLine, 'name') ?? '');
  const text = `${name} ${type} ${category}`;
  if (SUBWAY_RE.test(text) || /^railway/i.test(type)) return 'subway';
  if (RAIL_RE.test(text)) return 'rail';
  if (/轮渡|渡轮|船/.test(text)) return 'ferry';
  if (/航班|飞机/.test(text)) return 'flight';
  return 'bus';
}

/**
 * 取 buslines[0]，兼容 bus.buslines[0] 与 buslines[0]。
 * 若 buslines 为空数组（极端情况）仍然返回 bus 本身，避免丢掉 bus.departure_stop 这类信息。
 */
function pickBusLine(segment: any): any | null {
  const bus = g(segment, 'bus');
  const lines = g(bus, 'buslines') ?? g(segment, 'buslines');
  if (Array.isArray(lines) && lines.length > 0) return lines[0];
  if (bus && bus === segment) return bus;
  if (bus && !Array.isArray(lines)) return bus;
  return null;
}

/** 步行段路名：优先 steps[0].road / assistant_action，再退到 instruction。 */
function readWalkRoad(walking: any): string {
  const steps: any[] = Array.isArray(g(walking, 'steps')) ? g(walking, 'steps') : [];
  const first = steps.length > 0 ? steps[0] : null;
  return (
    normalizeText(g(first, 'road')) ||
    normalizeText(g(first, 'assistant_action')) ||
    normalizeText(g(first, 'instruction'))
  );
}

/** 兼容两种嵌套：{ name } 或字符串本身。 */
function readStopName(node: unknown): string {
  if (typeof node === 'string') return normalizeText(node);
  const name = typeof g(node, 'name') === 'string' ? g(node, 'name') : '';
  return normalizeText(name);
}

/** 兼容两种端点嵌套：{ name }、{ stop: { name } }、字符串。 */
function readEndpointName(node: unknown): string {
  return readStopName(node) || readStopName(g(node, 'stop'));
}

/**
 * 总时长与其来源：优先用整体 time；整体 time 缺失时退化为分段之和。
 * 两者都拿不到有效值时返回 NaN，由调用方降级为 null。
 */
function reconcileTotalMinutes(route: any, segments: LegSegment[]): number {
  const overall = Number(g(route, 'time')) / 60;
  if (isPos(overall)) return round1(overall);
  return round1(sumMinutes(segments));
}

/**
 * 让 Σsegments[i].minutes ≈ totalMinutes：
 *   · 所有分段都有 time → 按比例缩放，保证加总严格一致；
 *   · 部分分段缺 time   → 缺的那几段按「同 kind 已有时长的比例」分摊剩余时长；
 *   · 全都没有 time     → 按段数平均分摊。
 * 返回新数组，不改入参。knownMinutes 与 segments 一一对应（非正数表示该段缺 time）。
 */
function fillSegmentMinutes(
  segments: LegSegment[],
  totalMinutes: number,
  knownMinutes: number[],
): LegSegment[] {
  if (segments.length === 0) return segments;

  let distributed: Map<number, number>;
  if (knownMinutes.some(isPos)) {
    distributed = distributeProportionally(knownMinutes, totalMinutes);
  } else {
    const per = totalMinutes / segments.length;
    distributed = new Map<number, number>();
    for (let i = 0; i < segments.length; i += 1) distributed.set(i, per);
  }

  const out: LegSegment[] = [];
  let sum = 0;
  for (let i = 0; i < segments.length; i += 1) {
    const value = round1(distributed.get(i) ?? 0);
    sum = round1(sum + value);
    out.push({ ...segments[i], minutes: value });
  }

  // 最后一段吃掉四舍五入的零头，使「分别时间」之和与总时长严格相等。
  if (out.length > 0) {
    const drift = round1(totalMinutes - sum);
    if (drift !== 0) {
      const last = out.length - 1;
      out[last] = { ...out[last], minutes: Math.max(0, round1(out[last].minutes + drift)) };
    }
  }
  return out;
}

/**
 * 时间分摊：
 *   · 缺 time 的段，从「同 kind 已有时长」里按比例分一份（例如某个地铁段没给时间）；
 *   · 剩余时长按「有 time 段的时长比例」分给所有段；
 *   · 没有任何可参考时长（全 0 / 全缺）时按段数平均分。
 * 结果之和恒等于 totalMinutes。
 */
function distributeProportionally(knownMinutes: number[], totalMinutes: number): Map<number, number> {
  const indexes: number[] = [];
  const weights: number[] = [];
  for (let i = 0; i < knownMinutes.length; i += 1) {
    indexes.push(i);
    weights.push(isPos(knownMinutes[i]) ? knownMinutes[i] : 0);
  }

  // 缺 time 的段，用同 kind（i 在 indexes 里的邻居）的平均权重兜底。
  const total = weights.reduce((acc, value) => acc + value, 0);
  const fallback = total > 0 ? total / weights.length : 0;
  const effective = weights.map((value) => (isPos(value) ? value : fallback));
  const effectiveTotal = effective.reduce((acc, value) => acc + value, 0);

  const out = new Map<number, number>();
  if (effectiveTotal <= 0) {
    const per = totalMinutes / weights.length;
    for (const index of indexes) out.set(index, per);
    return out;
  }
  for (let i = 0; i < indexes.length; i += 1) {
    out.set(indexes[i], (totalMinutes * effective[i]) / effectiveTotal);
  }
  return out;
}

function sumMinutes(segments: LegSegment[]): number {
  return segments.reduce((acc, segment) => acc + (isPos(segment.minutes) ? segment.minutes : 0), 0);
}

/* ------------------------------------------------------------------ *
 * 折线（path）拼接 + 坐标转换
 * ------------------------------------------------------------------ */

/** 非公交：把 routes[0].steps[].path 依次拼接。 */
function collectStepPaths(route: any): any[] {
  const steps: any[] = Array.isArray(g(route, 'steps')) ? g(route, 'steps') : [];
  const sources: any[] = [];
  for (const step of steps) {
    const path = g(step, 'path');
    if (path) sources.push(path);
  }
  return sources;
}

/** 公共交通：按乘坐顺序拼接 walk / bus / railway / 段自带 path。 */
function collectTransitPaths(route: any): any[] {
  const segments: any[] = Array.isArray(g(route, 'segments')) ? g(route, 'segments') : [];
  const sources: any[] = [];
  for (const segment of segments) {
    // 部分版本直接给整段 path，优先用它（更完整）。
    const own = g(segment, 'path');
    if (own) sources.push(own);

    const walking = g(segment, 'walking');
    const steps: any[] = Array.isArray(g(walking, 'steps')) ? g(walking, 'steps') : [];
    for (const step of steps) {
      const path = g(step, 'path');
      if (path) sources.push(path);
    }

    const busLine = pickBusLine(segment);
    const busPath = g(busLine, 'path');
    if (busPath) sources.push(busPath);

    const railway = g(segment, 'railway');
    const railPath = g(railway, 'path');
    if (railPath) sources.push(railPath);
  }
  return sources;
}

/**
 * 把若干条高德折线（"lng,lat;lng,lat;…" 或点数组）拼成一条 WGS-84 折线：
 * 逐点解析 → 逐点 gcj02ToWgs84 → 去掉相邻重复点 → 超长抽稀。
 * 一个有效点都解析不出来时返回 undefined（不编造坐标）。
 */
function buildPath(sources: any[]): LatLng[] | undefined {
  const raw: LatLng[] = [];
  for (const source of sources) {
    const points = parsePathString(source);
    for (const point of points) raw.push(point);
  }
  if (raw.length === 0) return undefined;

  const out: LatLng[] = [];
  let lastLat = Number.NaN;
  let lastLng = Number.NaN;
  for (const point of raw) {
    const wgs = gcj02ToWgs84(point.lat, point.lng);
    if (wgs.lat === lastLat && wgs.lng === lastLng) continue;
    lastLat = wgs.lat;
    lastLng = wgs.lng;
    out.push(wgs);
  }
  return thinPath(out);
}

/**
 * 解析一条折线：兼容
 *   · "lng,lat;lng,lat;…" 字符串（Walking/Driving 的 step.path）
 *   · 上面的字符串数组
 *   · [{ lng, lat }] / [LngLat]（部分版本给点数组）
 * 非法点直接丢弃；返回的是 GCJ-02 点（调用方负责转 WGS-84）。
 */
function parsePathString(input: any): LatLng[] {
  const out: LatLng[] = [];
  if (typeof input === 'string') {
    for (const pair of input.split(';')) {
      const point = parseLngLat(pair);
      if (point) out.push(point);
    }
    return out;
  }
  if (!Array.isArray(input)) return out;
  for (const item of input) {
    const point = parseLngLat(item);
    if (point) out.push(point);
  }
  return out;
}

/** 点数超过 PATH_MAX_POINTS 时抽稀（首尾点始终保留），避免折线太大拖慢绘制。 */
function thinPath(points: LatLng[]): LatLng[] | undefined {
  if (points.length === 0) return undefined;
  if (points.length <= PATH_MAX_POINTS) return points;

  const out: LatLng[] = [];
  for (let i = 0; i < points.length; i += PATH_THIN_STRIDE) out.push(points[i]);
  const last = points[points.length - 1];
  const tail = out[out.length - 1];
  if (tail !== last) out.push(last);
  return out;
}

/* ------------------------------------------------------------------ *
 * 解析高德返回值（any 访问器集中在这里）
 * ------------------------------------------------------------------ */

/**
 * 安全读取高德返回对象上的字段。SDK 没有官方类型，所有嵌套字段访问都从这里过，
 * 好处是：字段名写错 / 结构变化时只会得到 undefined，不会抛 TypeError 把整条链路带崩。
 */
function g(source: any, key: string): any {
  return source && typeof source === 'object' ? source[key] : undefined;
}

/** 高德限流特征：info / message / 顶层字符串里出现 CUQPS 或 LIMIT。 */
function isQpsLimited(result: any): boolean {
  const text = `${String(g(result, 'info') ?? '')} ${String(g(result, 'message') ?? '')}`;
  return QPS_ERROR_RE.test(text);
}

/** mode → AMap.Walking / AMap.Driving / AMap.Transfer / AMap.Riding。 */
function pickRouteCtor(AMap: any, mode: TravelMode): any {
  const Ctor = AMap?.[ROUTE_PLUGIN[mode]];
  return typeof Ctor === 'function' ? Ctor : null;
}

/**
 * 取第一条方案：
 *   Walking / Driving / Riding → result.routes[0]
 *   Transfer（公共交通，JS API 2.0 的实际结构） → result.plans[0]
 * 兼容顺序：先 routes，再 plans（旧版 Transfer 也用过 routes）。
 */
function pickRoute(result: any): any {
  if (Array.isArray(result?.routes) && result.routes.length > 0) return result.routes[0];
  if (Array.isArray(result?.plans) && result.plans.length > 0) return result.plans[0];
  return null;
}

/** 去掉线路名括号里的起终点：`地铁2号线(犀浦--龙泉驿)` → `地铁2号线`。 */
function cleanLineName(value: any): string {
  const text = normalizeText(value);
  return text.replace(/[(（][^)）]*[)）]/g, '').trim() || text;
}

/* ------------------------------------------------------------------ *
 * 通用小工具
 * ------------------------------------------------------------------ */

/** 本文件唯一的 console.warn 语义：只说明「为什么降级」，不往上抛。 */
function warnDegrade(reason: string, err?: unknown): void {
  console.warn(`[amap] ${reason}，已降级或已重试（调用方将回退到估算/空结果）`, err ?? '');
}

/** 高德给的是秒，业务用分钟。 */
function secondsToMinutes(seconds: unknown): number {
  const value = Number(seconds);
  return Number.isFinite(value) && value > 0 ? value / 60 : 0;
}

/** 高德给的是米，业务用公里。 */
function metersToKm(meters: unknown): number | undefined {
  const value = Number(meters);
  return Number.isFinite(value) && value > 0 ? round1(value / 1000) : undefined;
}

/** 有效正数（有限、> 0）才认为「拿到了真实数值」；也用作 number | undefined 收窄。 */
function isPos(value: number | undefined): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0;
}

/**
 * 去掉 instruction / 线路名里可能带的 HTML 标签，压缩空白，并截断到 SUMMARY_MAX_SEGMENT_CHARS。
 * 展示文案统一从这里过一手，避免把高德的富文本原样吐到反馈里。
 */
function normalizeText(value: any): string {
  if (typeof value !== 'string') return '';
  const text = value
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!text) return '';
  return text.length > SUMMARY_MAX_SEGMENT_CHARS
    ? `${text.slice(0, SUMMARY_MAX_SEGMENT_CHARS)}…`
    : text;
}

function truncate(text: string): string {
  return text.length > SUMMARY_MAX_SEGMENT_CHARS
    ? `${text.slice(0, SUMMARY_MAX_SEGMENT_CHARS)}…`
    : text;
}

function round1(value: number): number {
  const factor = 10 ** DECIMALS;
  return Math.round(value * factor) / factor;
}

/** WGS-84 → GCJ-02，返回高德惯用的 [lng, lat]。 */
function toGcjPair(p: LatLng): [number, number] {
  const gcj = wgs84ToGcj02(p.lat, p.lng);
  return [gcj.lng, gcj.lat];
}

/** 优先给高德 LngLat 实例（部分服务要求），拿不到 LngLat 类时退化为 [lng, lat]。 */
function toLngLat(AMap: any, p: LatLng): any {
  const [lng, lat] = toGcjPair(p);
  return typeof AMap?.LngLat === 'function' ? new AMap.LngLat(lng, lat) : [lng, lat];
}

/**
 * 解析高德给的坐标，可能是：
 *   · "lng,lat" 字符串（Geocoder 常见）
 *   · LngLat 实例（PlaceSearch 的 poi.location 在 2.0 里是对象，用 getLng()/getLat()）
 *   · 带 lng/lat 数字属性的对象
 * 解析失败返回 null。
 */
function parseLngLat(input: any): LatLng | null {
  if (typeof input === 'string') {
    const [lngText, latText] = input.split(',');
    return finitePair(Number(lngText), Number(latText));
  }
  if (input && typeof input.getLng === 'function' && typeof input.getLat === 'function') {
    return finitePair(Number(input.getLng()), Number(input.getLat()));
  }
  if (input && typeof input.lng === 'number' && typeof input.lat === 'number') {
    return finitePair(input.lng, input.lat);
  }
  return null;
}

function finitePair(lng: number, lat: number): LatLng | null {
  if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;
  if (lng === 0 && lat === 0) return null;
  return { lat, lng };
}

/** POI 数组（GCJ-02）→ PoiInfo 数组（WGS-84），非法项丢弃。 */
function toPoiInfos(pois: any[], center: LatLng): PoiInfo[] {
  const out: PoiInfo[] = [];
  for (const poi of pois) {
    const info = toPoiInfo(poi, center);
    if (info) out.push(info);
  }
  return out;
}

/** POI（GCJ-02）→ PoiInfo（WGS-84）。 */
function toPoiInfo(poi: any, center: LatLng): PoiInfo | null {
  const point = parseLngLat(poi?.location);
  if (!point) return null;

  const wgs = gcj02ToWgs84(point.lat, point.lng);
  const given = Number(poi?.distance);
  return {
    id: typeof poi?.id === 'string' && poi.id ? poi.id : `${wgs.lat.toFixed(6)},${wgs.lng.toFixed(6)}`,
    name: typeof poi?.name === 'string' ? poi.name : '',
    address: joinAddress(poi),
    lat: wgs.lat,
    lng: wgs.lng,
    type: typeof poi?.type === 'string' ? poi.type : '',
    // 高德给的 distance 就是到查询点的直线米数；缺失时用 haversine 估算兜底。
    distanceM: Number.isFinite(given) ? given : haversineKm(center, wgs) * 1000,
  };
}

/** pname + cityname + adname + address 拼接，空值跳过。 */
function joinAddress(poi: any): string {
  const parts = [poi?.pname, poi?.cityname, poi?.adname, poi?.address];
  let address = '';
  for (const part of parts) {
    if (typeof part === 'string' && part.trim()) address += part.trim();
  }
  return address;
}

function pickNearest(pois: PoiInfo[]): PoiInfo | null {
  let best: PoiInfo | null = null;
  for (const poi of pois) {
    if (!best || poi.distanceM < best.distanceM) best = poi;
  }
  return best;
}

/** 直辖市（北京/上海…）的 addressComponent.city 常常是 [] 或空串，退化为 province。 */
function pickCity(component: any): string | null {
  if (typeof component?.city === 'string' && component.city.trim()) return component.city.trim();
  if (typeof component?.province === 'string' && component.province.trim()) {
    return component.province.trim();
  }
  return null;
}

function clampRadius(radiusM: number): number {
  if (!Number.isFinite(radiusM) || radiusM <= 0) return DEFAULT_SEARCH_RADIUS_M;
  return Math.min(Math.round(radiusM), MAX_SEARCH_RADIUS_M);
}
