/**
 * 高德 Web服务(REST) 版的路径规划 / POI / 地理编码实现。
 *
 * ── 为什么是 REST 而不是 JS API ──
 * 1) REST 的响应用 Node 就能完整验证（只需把 baseUrl 换成 https://restapi.amap.com），
 *    实测过四种方式都返回真实折线：步行/驾车/骑行在 `steps[].polyline`，
 *    公交在 `segments[].walking.steps[].polyline` 与 `segments[].bus.buslines[].polyline`。
 * 2) 浏览器直连 REST 会被 CORS 拦，所以经 Vite 开发代理 `/amap` 转发；
 *    **Key 由代理在服务端注入**，前端产物里不含 Key（比 JS API 更安全）。
 *
 * ── 坐标系 ──
 * 项目内部统一 WGS-84；高德只认 GCJ-02。本文件是唯一转换边界：
 * 入参先 wgs84ToGcj02，出参（坐标与折线）统一 gcj02ToWgs84。
 *
 * ── 降级 ──
 * 任何一次调用失败/超时都 resolve null 或空结果，绝不 reject；由上层回退到估算。
 *
 * 注意：本文件**不使用 import.meta**（baseUrl / key 全部由构造参数注入），
 * 这样才能编译成 CommonJS 在 Node 里跑真实验证。
 */
import { gcj02ToWgs84, haversineKm, wgs84ToGcj02 } from '../algorithms/coords';
import { segmentColor } from '../data/lineColors';
import type { LegSegment, LegSegmentKind, TravelMode } from '../types';
import type { PoiCheckResult, PoiInfo, RouteLeg } from '../types/planning';

type Point = { lat: number; lng: number };

export type RestOptions = {
  /** 例：'/amap'（浏览器经代理）或 'https://restapi.amap.com'（Node 直连验证） */
  baseUrl: string;
  /** 为空表示 Key 由代理注入 */
  key?: string;
};

/** 请求超时（毫秒） */
const TIMEOUT_MS = 12000;
/** 命中 QPS 限流后的重试等待 */
const CUQPS_RETRY_MS = 400;
/** POI 搜索半径（米）：先按餐饮大类找，找不到再按关键词兜底 */
export const POI_RADIUS_M = 500;
/** 认为「用户点的就是这个 POI」的吸附距离（米） */
const SNAP_M = 50;

/**
 * 「具体餐厅」判定（用户要求：双击必须落在具体餐厅上，不能是美食街 / 理发店之类）。
 *
 * 高德的 type 形如 `餐饮服务;中餐厅;川菜`、`餐饮服务;咖啡厅;星巴克咖啡`：
 * 只有**二级分类属于具体餐饮子类**才算餐厅。
 * 「餐饮服务;餐饮相关场所;餐饮相关」（美食街、餐饮广场）以及非餐饮类（理发店等）
 * 一律不算 —— 用户实测反馈：双击会选中"太古里美食街"这种非具体餐厅。
 */
const RESTAURANT_SUBTYPES = [
  '中餐厅',
  '外国餐厅',
  '快餐厅',
  '休闲餐饮场所',
  '咖啡厅',
  '茶艺馆',
  '冷饮店',
  '糕饼店',
  '甜品店',
];

function isConcreteRestaurant(poi: PoiInfo): boolean {
  const parts = String(poi.type ?? '')
    .split(';')
    .map((s) => s.trim());
  return parts[0] === '餐饮服务' && RESTAURANT_SUBTYPES.includes(parts[1] ?? '');
}
/** 折线抽稀阈值（点数超过则隔点取样），控制内存 */
const MAX_PATH_POINTS = 2000;

/** 毫秒 → 分钟（保留一位小数，避免 0 分钟这种失真） */
function toMinutes(seconds: number): number {
  return Math.round((seconds / 60) * 10) / 10;
}

/** "lng,lat;lng,lat" → WGS-84 点数组 */
function parsePolyline(polyline: unknown): Point[] {
  if (typeof polyline !== 'string' || polyline.length === 0) return [];
  const out: Point[] = [];
  for (const pair of polyline.split(';')) {
    const [lngStr, latStr] = pair.split(',');
    const lng = Number(lngStr);
    const lat = Number(latStr);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) continue;
    const w = gcj02ToWgs84(lat, lng);
    out.push({ lat: w.lat, lng: w.lng });
  }
  return out;
}

/** 拼接多段折线并去重、抽稀 */
function joinPaths(parts: Point[][]): Point[] | undefined {
  const flat: Point[] = [];
  for (const part of parts) {
    for (const p of part) {
      const last = flat[flat.length - 1];
      if (last && Math.abs(last.lat - p.lat) < 1e-7 && Math.abs(last.lng - p.lng) < 1e-7) continue;
      flat.push(p);
    }
  }
  if (flat.length < 2) return undefined;
  if (flat.length <= MAX_PATH_POINTS) return flat;
  const step = Math.ceil(flat.length / MAX_PATH_POINTS);
  const thin = flat.filter((_, i) => i % step === 0);
  const lastPoint = flat[flat.length - 1];
  if (thin[thin.length - 1] !== lastPoint) thin.push(lastPoint);
  return thin;
}

/** 由线路名/类型判断段种类 */
function kindOfLine(name: string, type: string): LegSegmentKind {
  if (/地铁|轨道|捷运/.test(name) || /地铁/.test(type)) return 'subway';
  if (/高铁|动车|城际|铁路/.test(name)) return 'rail';
  if (/轮渡|船/.test(name)) return 'ferry';
  if (/机场|航班/.test(name)) return 'flight';
  if (/公交|路|快线|专线/.test(name)) return 'bus';
  return 'bus';
}

/** 线路名去掉括号里的起终点：`地铁2号线(犀浦--龙泉驿)` → `地铁2号线` */
function cleanLineName(name: string): string {
  return name.replace(/\(.*?\)/g, '').trim() || name;
}

export class RestRoutingService {
  constructor(private readonly opts: RestOptions) {}

  private url(path: string, params: Record<string, string>): string {
    const qs = new URLSearchParams(params);
    if (this.opts.key) qs.set('key', this.opts.key);
    return `${this.opts.baseUrl}${path}?${qs.toString()}`;
  }

  /** 统一的 GET：超时 + 限流重试一次；任何异常都返回 null */
  private async get(path: string, params: Record<string, string>): Promise<any | null> {
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
      try {
        const res = await fetch(this.url(path, params), { signal: controller.signal });
        clearTimeout(timer);
        const json: any = await res.json();
        // v3 用 status/info，v4 用 errcode/errmsg
        if (typeof json?.errcode !== 'undefined') {
          if (json.errcode === 0) return json;
          if (json.errcode !== 0 && attempt === 0) continue;
          return null;
        }
        if (json?.status === '1') return json;
        const info = String(json?.info ?? '');
        if (/CUQPS|LIMIT/i.test(info) && attempt === 0) {
          await new Promise((r) => setTimeout(r, CUQPS_RETRY_MS));
          continue;
        }
        return null;
      } catch {
        clearTimeout(timer);
        if (attempt === 0) {
          await new Promise((r) => setTimeout(r, CUQPS_RETRY_MS));
          continue;
        }
        return null;
      }
    }
    return null;
  }

  /** 四种出行方式 → REST 端点与解析 */
  async route(
    a: Point,
    b: Point,
    mode: TravelMode,
    hint?: { fromCity?: string | null; toCity?: string | null },
  ): Promise<RouteLeg | null> {
    const A = wgs84ToGcj02(a.lat, a.lng);
    const B = wgs84ToGcj02(b.lat, b.lng);
    const origin = `${A.lng.toFixed(6)},${A.lat.toFixed(6)}`;
    const destination = `${B.lng.toFixed(6)},${B.lat.toFixed(6)}`;

    if (mode === 'transit') {
      // 实测：不传 city 也能拿到同城方案；但**跨城公交必须传 city/cityd**
      // （例如广州→佛山的「广佛线」，不传就查不到）。所以只在拿到城市提示时才带上。
      const params: Record<string, string> = {
        origin,
        destination,
        extensions: 'all',
      };
      if (hint?.fromCity) params.city = hint.fromCity;
      if (hint?.toCity) params.cityd = hint.toCity;
      const json = await this.get('/v3/direction/transit/integrated', params);
      const transit = json?.route?.transits?.[0];
      if (!transit) return null;

      const parts: Point[][] = [];
      const segments: LegSegment[] = [];
      let sum = 0;
      for (const seg of transit.segments ?? []) {
        // 接驳步行段（站点↔出发点 / 站点↔餐厅 都是它），单独保留折线用于分段着色
        const walkParts: Point[][] = [];
        for (const st of seg.walking?.steps ?? []) {
          const pts = parsePolyline(st.polyline);
          if (pts.length > 0) walkParts.push(pts);
        }
        const walkPath = joinPaths(walkParts);
        if (walkPath) parts.push(walkPath);
        if (seg.walking) {
          const m = toMinutes(Number(seg.walking.duration ?? 0));
          const km = Number(seg.walking.distance ?? 0) / 1000;
          if (m > 0 || km > 0) {
            segments.push({
              kind: 'walk',
              label: '步行',
              minutes: m,
              km,
              path: walkPath,
              color: segmentColor('walk'),
            });
            sum += m;
          }
        }
        // 乘车段：公交/地铁/铁路都走 buslines 结构
        const line = seg.bus?.buslines?.[0] ?? seg.railway;
        if (line) {
          const linePath = joinPaths([parsePolyline(line.polyline)]);
          if (linePath) parts.push(linePath);
          const name = String(line.name ?? '公共交通');
          const m = toMinutes(Number(line.duration ?? seg.duration ?? 0));
          // 零时长的占位段（高德偶尔会返回无名无耗时的段）不展示，否则反馈里会出现「公共交通 0分钟」
          if (m > 0 || line.name) {
            const kind = kindOfLine(name, String(line.type ?? ''));
            segments.push({
              kind,
              label: cleanLineName(name),
              minutes: m,
              km: Number(line.distance ?? 0) / 1000,
              from: line.departure_stop?.name ? String(line.departure_stop.name) : undefined,
              to: line.arrival_stop?.name ? String(line.arrival_stop.name) : undefined,
              path: linePath,
              color: segmentColor(kind, name),
            });
            sum += m;
          }
        }
      }
      if (segments.length === 0) return null;

      const total = toMinutes(Number(transit.duration ?? 0)) || sum;
      // 让分段加总严格等于总时长，否则反馈里数字对不上
      const diff = Math.round((total - sum) * 10) / 10;
      if (Math.abs(diff) >= 0.1) {
        const last = segments[segments.length - 1];
        last.minutes = Math.round((last.minutes + diff) * 10) / 10;
      }
      const km = Number(transit.distance ?? 0) / 1000;
      return {
        mode,
        minutes: total,
        km,
        source: 'amap',
        estimated: false,
        segments,
        path: joinPaths(parts),
        summary: segments.map((s) => `${s.label} ${Math.round(s.minutes)}分钟`).join(' → '),
      };
    }

    const endpoint =
      mode === 'walk'
        ? '/v3/direction/walking'
        : mode === 'drive'
          ? '/v3/direction/driving'
          : '/v4/direction/bicycling';
    const json = await this.get(endpoint, { origin, destination, extensions: 'all' });
    const node = mode === 'bike' ? json?.data?.paths?.[0] : json?.route?.paths?.[0];
    if (!node) return null;

    const parts: Point[][] = [];
    for (const st of node.steps ?? []) {
      const pts = parsePolyline(st.polyline);
      if (pts.length > 0) parts.push(pts);
    }
    const minutes = toMinutes(Number(node.duration ?? 0));
    const km = Number(node.distance ?? 0) / 1000;
    const label = mode === 'walk' ? '步行' : mode === 'drive' ? '驾车' : '骑行';
    const path = joinPaths(parts);
    return {
      mode,
      minutes,
      km,
      source: 'amap',
      estimated: false,
      segments: [{ kind: mode, label, minutes, km, path, color: segmentColor(mode) }],
      path,
      summary: `${label} ${km.toFixed(1)}km`,
    };
  }

  async geocode(address: string): Promise<{ lat: number; lng: number } | null> {
    const json = await this.get('/v3/geocode/geo', { address });
    const loc = json?.geocodes?.[0]?.location;
    if (typeof loc !== 'string') return null;
    const [lng, lat] = loc.split(',').map(Number);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    const w = gcj02ToWgs84(lat, lng);
    return { lat: w.lat, lng: w.lng };
  }

  async regeocode(p: Point): Promise<{ address: string; city: string | null } | null> {
    const g = wgs84ToGcj02(p.lat, p.lng);
    const json = await this.get('/v3/geocode/regeo', {
      location: `${g.lng.toFixed(6)},${g.lat.toFixed(6)}`,
      extensions: 'base',
    });
    const rc = json?.regeocode;
    if (!rc) return null;
    const city = typeof rc.addressComponent?.city === 'string' && rc.addressComponent.city
      ? rc.addressComponent.city
      : (rc.addressComponent?.province ?? null);
    return { address: String(rc.formatted_address ?? ''), city: city ? String(city) : null };
  }

  private toPoi(poi: any, center: Point): PoiInfo | null {
    const loc = typeof poi?.location === 'string' ? poi.location.split(',').map(Number) : [];
    const lng = loc[0];
    const lat = loc[1];
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    const w = gcj02ToWgs84(lat, lng);
    const addr = [poi.pname, poi.cityname, poi.adname, poi.address]
      .filter((x) => typeof x === 'string' && x.length > 0)
      .join('');
    const d = Number(poi.distance);
    return {
      id: String(poi.id ?? `${lat},${lng}`),
      name: String(poi.name ?? ''),
      address: addr,
      lat: w.lat,
      lng: w.lng,
      type: String(poi.type ?? ''),
      distanceM: Number.isFinite(d) && d > 0 ? d : haversineKm(center, w) * 1000,
    };
  }

  async aroundRestaurants(center: Point, radiusM: number): Promise<PoiInfo[]> {
    const g = wgs84ToGcj02(center.lat, center.lng);
    const json = await this.get('/v3/place/around', {
      location: `${g.lng.toFixed(6)},${g.lat.toFixed(6)}`,
      types: '050000',
      radius: String(radiusM),
      offset: '20',
      page: '1',
      extensions: 'base',
    });
    return (json?.pois ?? [])
      .map((p: any) => this.toPoi(p, center))
      .filter((p: PoiInfo | null): p is PoiInfo => p !== null);
  }

  /**
   * 判定「这个点是不是餐厅」。
   *
   * 两条路径，判定口径**故意不同**：
   *   ① 主路径 `types=050000`（餐饮服务大类）→ **必须过「具体餐厅子类」过滤**：
   *      子类里出现"餐饮相关场所"（美食街/餐饮广场）就不算，非餐饮类更不算。
   *   ② 兜底路径（关键词 + 名称正则）→ **不加类型过滤**：
   *      它存在的意义正是捞回"被高德归错类、但确实是餐厅"的店
   *      （例如鲍师傅糕点被归到"生活服务"）。名称已经过 咖啡|茶|甜品|烘焙|面包|糕|饼|饮 过滤，
   *      "美食街""理发店"这类名字匹配不上，所以不会因此混进来。
   *
   * 两条路径都找不到时返回 nearest = undefined，由界面提示"这里不是餐厅"，
   * 并**保留用户点的位置**让他自己填地址（用户已确认要这个行为）。
   */
  async checkPoi(center: Point, radiusM: number): Promise<PoiCheckResult> {
    let list = (await this.aroundRestaurants(center, radiusM)).filter(isConcreteRestaurant);
    if (list.length === 0) {
      const g = wgs84ToGcj02(center.lat, center.lng);
      const json = await this.get('/v3/place/around', {
        location: `${g.lng.toFixed(6)},${g.lat.toFixed(6)}`,
        keywords: '咖啡',
        radius: String(Math.max(radiusM, 2000)),
        offset: '20',
        page: '1',
        extensions: 'base',
      });
      list = (json?.pois ?? [])
        .map((p: any) => this.toPoi(p, center))
        .filter((p: PoiInfo | null): p is PoiInfo => p !== null)
        .filter((p: PoiInfo) => /咖啡|茶|甜品|烘培|烘焙|面包|糕|饼|饮/.test(p.name));
    }
    if (list.length === 0) {
      return { isRestaurant: false, radiusM, source: 'amap' };
    }
    const nearest = [...list].sort((x, y) => x.distanceM - y.distanceM)[0];
    if (nearest.distanceM <= SNAP_M) {
      return { isRestaurant: true, poi: nearest, radiusM, source: 'amap' };
    }
    return { isRestaurant: false, nearest, radiusM, source: 'amap' };
  }
}
