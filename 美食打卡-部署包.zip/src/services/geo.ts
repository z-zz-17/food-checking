import { AmapGeoService } from './amapGeo';
import { MockGeoService } from './mockGeo';
import type { GeoService } from './geoService';

export const geoService: GeoService = createService();

function createService(): GeoService {
  const key = import.meta.env.VITE_AMAP_KEY as string | undefined;
  return key && key.trim() ? new AmapGeoService() : new MockGeoService();
}
