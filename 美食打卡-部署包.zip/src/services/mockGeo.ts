import type { GeoSearchResult } from '../types';
import type { GeoService } from './geoService';
import { MOCK_PLACES } from '../data/mockPlaces';
import { CITY_CENTERS, DISTRICT_CENTERS, type CenterPoint } from '../data/cityCenters';

/** 近似定位的偏移幅度：约 ±2.8km，让不同地址落在不同位置 */
const OFFSET_DEG = 0.05;

/**
 * 稳定哈希（FNV-1a）：同一地址每次定位结果一致，
 * 避免刷新页面后 Marker 位置跳动。
 */
function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** 在基准点附近生成确定性偏移（演示模式的近似定位） */
function nearCenter(center: CenterPoint, address: string): { lat: number; lng: number } {
  const h = hashString(address);
  const dx = ((h % 1000) / 1000 - 0.5) * OFFSET_DEG;
  const dy = (((h >>> 10) % 1000) / 1000 - 0.5) * OFFSET_DEG;
  return { lat: center.lat + dy, lng: center.lng + dx };
}

/** 命中列表里「在地址中出现位置最靠前」的那一项（处理「上海市南京路」这类歧义） */
function firstMatch(list: CenterPoint[], q: string): CenterPoint | null {
  let best: CenterPoint | null = null;
  let bestIdx = Infinity;
  for (const item of list) {
    const i = q.indexOf(item.name);
    if (i >= 0 && i < bestIdx) {
      bestIdx = i;
      best = item;
    }
  }
  return best;
}

export class MockGeoService implements GeoService {
  async searchPlaces(keyword: string): Promise<GeoSearchResult[]> {
    const kw = keyword.trim().toLowerCase();
    await delay(300);
    if (!kw) return MOCK_PLACES.slice(0, 10);
    return MOCK_PLACES.filter(
      (p) =>
        p.name.toLowerCase().includes(kw) ||
        p.cuisine.toLowerCase().includes(kw) ||
        p.address.toLowerCase().includes(kw),
    ).slice(0, 10);
  }

  async geocode(address: string): Promise<{ lat: number; lng: number } | null> {
    await delay(250);
    const q = address.trim();
    if (!q) return null;

    // 1) 精确命中内置示例餐厅 / 地址（最准）
    const hit = MOCK_PLACES.find(
      (p) => p.address.includes(q) || p.name.includes(q) || q.includes(p.name),
    );
    if (hit) return { lat: hit.lat, lng: hit.lng };

    // 2) 命中城区（比城市更精确，优先）
    const district = firstMatch(DISTRICT_CENTERS, q);
    if (district) return nearCenter(district, q);

    // 3) 命中城市
    const city = firstMatch(CITY_CENTERS, q);
    if (city) return nearCenter(city, q);

    // 4) 识别不了：返回 null，由调用方提示用户写得更具体或改用地图点选
    return null;
  }
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
