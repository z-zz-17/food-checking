/**
 * 高德 JS API 2.0 动态加载器（仅浏览器端）。
 *
 * 坐标系约定
 *   本文件只负责「把 SDK 拿进来」，不碰任何坐标；项目内部统一用 WGS-84，
 *   与高德之间唯一的 GCJ-02 转换边界在 services/amapJs.ts（高德只认 GCJ-02）。
 *
 * 无 Key / 加载失败时的降级行为
 *   hasAmapKey() === false 时 loadAmap() 立即 resolve(null)；
 *   脚本加载失败或超过 10s 超时同样 resolve(null)，永不 reject。
 *   调用方（services/routing.ts）据此切到纯估算的 FallbackRoutingService，
 *   所以「没有任何网络 / 没有 Key」都不会把异常抛到 UI。
 *
 * 已知事实（安全边界）
 *   这里用的是高德「Web端(JS API)」类型的 Key，属于浏览器端 Key：
 *   打包后 key 与 jscode 一定会明文出现在前端产物（dist）里，无法保密。
 *   只能依赖高德控制台的域名白名单 + 安全密钥（jscode）来限制盗用，
 *   不要把它当成服务端密钥，也不要在其上挂任何机密信息。
 *
 * 关于 any
 *   高德 SDK 没有官方 TypeScript 类型，any 只允许集中在
 *   services/amapLoader.ts 与 services/amapJs.ts 的内部实现里，
 *   对外暴露的签名（见 services/routing.ts 的 RoutingService）始终是强类型的。
 */

const SCRIPT_ID = 'amap-js-api-2-0';
const SCRIPT_MARKER = 'data-amap-js';
const LOAD_TIMEOUT_MS = 10_000;
const PLUGIN_LIST =
  'AMap.Walking,AMap.Driving,AMap.Transfer,AMap.Riding,AMap.PlaceSearch,AMap.Geocoder';

declare global {
  interface Window {
    /** AMap 命名空间：SDK 无官方类型，只在本文件与 amapJs.ts 内部使用。 */
    AMap?: any;
    /** JS API 2.0 强制要求：必须在 SDK 脚本注入「之前」赋值，否则部分能力会被拒绝。 */
    _AMapSecurityConfig?: { securityJsCode: string };
  }
}

/**
 * 约定好的两个环境变量。
 * · Vite 会把 `import.meta.env.VITE_*` 在构建时静态替换成字面量，未配置时得到 undefined，所以按 string | undefined 处理；
 * · 类型上不用改任何既有声明文件：vite/client 的 ImportMetaEnv 带 `[key: string]: any` 索引签名，
 *   这里只是把这个 any 收窄成 string | undefined（即便将来 vite-env.d.ts 补上这两个变量的声明，也不会冲突）。
 */
const JS_KEY = import.meta.env.VITE_AMAP_JS_KEY as string | undefined;
const JS_SECURITY = import.meta.env.VITE_AMAP_JS_SECURITY as string | undefined;

function readEnv(value: string | undefined): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

/** 是否配置了高德 JS API Key（空串 / undefined 都算没配）。 */
export function hasAmapKey(): boolean {
  return readEnv(JS_KEY) !== null;
}

/** 并发去重用的模块级 Promise 缓存：同时多次调用只会注入一次脚本。 */
let pendingLoad: Promise<any | null> | null = null;

/**
 * 加载并返回 window.AMap；失败 / 超时 / 无 Key 一律 resolve(null)。
 */
export async function loadAmap(): Promise<any | null> {
  if (typeof window === 'undefined' || typeof document === 'undefined') return null;
  // 已经加载过（或被页面里其他脚本先加载过）就直接复用。
  if (window.AMap) return window.AMap;

  const key = readEnv(JS_KEY);
  if (!key) return null;

  if (!pendingLoad) {
    pendingLoad = injectScript(key).then(
      (amap) => {
        // 失败后清掉缓存，给下一次调用一个重试的机会（成功则一直复用）。
        if (!amap) pendingLoad = null;
        return amap;
      },
      () => {
        pendingLoad = null;
        return null;
      },
    );
  }
  return pendingLoad;
}

function injectScript(key: string): Promise<any | null> {
  return new Promise<any | null>((resolve) => {
    // 必须在注入脚本之前设置安全密钥，这是 JS API 2.0 的强制要求。
    const security = readEnv(JS_SECURITY);
    if (security) {
      window._AMapSecurityConfig = { securityJsCode: security };
    }

    // 清掉上一次失败残留的节点，避免复用已经被 abort / error 掉的 script。
    document.querySelectorAll(`script[${SCRIPT_MARKER}]`).forEach((node) => node.remove());

    const script = document.createElement('script');
    let settled = false;
    let timer: number | undefined;

    const finish = (amap: any | null): void => {
      if (settled) return;
      settled = true;
      if (timer !== undefined) window.clearTimeout(timer);
      script.onload = null;
      script.onerror = null;
      // 失败时不要把坏节点留在 DOM 里。
      if (!amap) script.remove();
      resolve(amap);
    };

    script.id = SCRIPT_ID;
    script.async = true;
    script.setAttribute(SCRIPT_MARKER, '1');
    script.src = `https://webapi.amap.com/maps?v=2.0&key=${encodeURIComponent(key)}&plugin=${PLUGIN_LIST}`;
    script.onload = () => finish(window.AMap ?? null);
    script.onerror = () => {
      warnDegrade('高德 JS API 脚本加载失败（Key 无效 / 域名白名单未生效 / 网络不可用）');
      finish(null);
    };

    timer = window.setTimeout(() => {
      warnDegrade(`高德 JS API 加载超过 ${LOAD_TIMEOUT_MS / 1000}s`);
      finish(null);
    }, LOAD_TIMEOUT_MS);

    document.head.appendChild(script);
  });
}

/** 本文件唯一的 console.warn：只说明「为什么降级」，不往上抛。 */
function warnDegrade(reason: string): void {
  console.warn(`[amap] ${reason}，已降级为估算模式`);
}
