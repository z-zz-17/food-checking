import type { GeoSearchResult } from '../types';
import type { GeoService } from './geoService';
import { MockGeoService } from './mockGeo';

const KEY = import.meta.env.VITE_AMAP_KEY as string | undefined;

export class AmapGeoService implements GeoService {
  private fallback = new MockGeoService();

  private get key(): string | null {
    return KEY && KEY.trim() ? KEY.trim() : null;
  }

  async searchPlaces(keyword: string): Promise<GeoSearchResult[]> {
    if (!this.key) return this.fallback.searchPlaces(keyword);
    const url = new URL('https://restapi.amap.com/v3/place/text');
    url.searchParams.set('key', this.key);
    url.searchParams.set('keywords', keyword);
    url.searchParams.set('types', '050000');
    url.searchParams.set('offset', '20');
    const res = await fetch(url.toString());
    const json = await res.json();
    if (json.status !== '1') return this.fallback.searchPlaces(keyword);
    return json.pois.map((p: any): GeoSearchResult => {
      const [lng, lat] = (p.location as string).split(',').map(Number);
      return {
        id: p.id,
        name: p.name,
        address: p.address ?? p.pname + p.cityname + p.adname,
        lat,
        lng,
        cuisine: p.type?.split(';')[0] ?? '餐饮',
        avgPrice: 0,
      };
    });
  }

  async geocode(address: string): Promise<{ lat: number; lng: number } | null> {
    if (!this.key) return this.fallback.geocode(address);
    const url = new URL('https://restapi.amap.com/v3/geocode/geo');
    url.searchParams.set('key', this.key);
    url.searchParams.set('address', address);
    const res = await fetch(url.toString());
    const json = await res.json();
    if (json.status !== '1' || !json.geocodes?.length) return null;
    const [lng, lat] = (json.geocodes[0].location as string).split(',').map(Number);
    return { lat, lng };
  }
}
