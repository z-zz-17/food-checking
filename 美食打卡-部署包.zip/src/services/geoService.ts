import type { GeoSearchResult } from '../types';

export interface GeoService {
  searchPlaces(keyword: string): Promise<GeoSearchResult[]>;
  geocode(address: string): Promise<{ lat: number; lng: number } | null>;
}
