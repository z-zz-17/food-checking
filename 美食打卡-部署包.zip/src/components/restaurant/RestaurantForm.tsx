import { useEffect, useRef, useState } from 'react';
import type { Priority } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { geoService } from '../../services/geo';
import { getRoutingService } from '../../services/routing';

import { CuisinePicker } from './CuisinePicker';

/** 在多大半径内去找「最近的餐厅」（米） */
const POI_RADIUS_M = 500;

type LatLng = { lat: number; lng: number };

type InitialPatch = Partial<{
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  cuisine: string;
  avgPrice: number;
  hours: { open: string; close: string }[];
  stayMinutes: number;
  priority: Priority;
  emoji: string;
}>;

export function RestaurantForm({
  initial,
  onClose,
}: {
  initial?: InitialPatch;
  onClose: () => void;
}) {
  const addRestaurant = useRestaurantStore((s) => s.addRestaurant);
  const updateRestaurant = useRestaurantStore((s) => s.updateRestaurant);

  const [name, setName] = useState(initial?.name ?? '');
  const [address, setAddress] = useState(initial?.address ?? '');
  const [cuisine, setCuisine] = useState(initial?.cuisine ?? '川菜');
  const [avgPrice, setAvgPrice] = useState(
    initial?.avgPrice != null ? String(initial.avgPrice) : '',
  );
  const [open, setOpen] = useState(initial?.hours?.[0]?.open ?? '10:00');
  const [close, setClose] = useState(initial?.hours?.[0]?.close ?? '21:00');
  const [stayMinutes, setStayMinutes] = useState(
    initial?.stayMinutes != null ? String(initial.stayMinutes) : '60',
  );
  const [priority, setPriority] = useState<Priority>(initial?.priority ?? 'want');
  const [emoji, setEmoji] = useState(initial?.emoji ?? '🍜');

  // 坐标来源：地图点选（initial 带 lat/lng）或按地址自动定位
  const initLat = initial?.lat;
  const initLng = initial?.lng;
  const [fromMap, setFromMap] = useState(
    initLat != null && initLng != null && (initLat !== 0 || initLng !== 0),
  );
  const [coord, setCoord] = useState<LatLng | null>(
    initLat != null && initLng != null && (initLat !== 0 || initLng !== 0)
      ? { lat: initLat, lng: initLng }
      : null,
  );
  const [locating, setLocating] = useState(false);
  const [hint, setHint] = useState('');
  const [poiBusy, setPoiBusy] = useState(false);
  const [poiHint, setPoiHint] = useState('');
  /** 第 7 条：均价为 0 时要二次确认 */
  const [askZeroPrice, setAskZeroPrice] = useState(false);
  /** 同一个坐标只向高德问一次 */
  const checkedKey = useRef('');

  /**
   * 坐标确定后问高德：这个点本身是不是餐厅？
   *  - 是餐厅  → 回填精确地址/店名
   *  - 不是餐厅 → 自动吸附到最近的餐饮 POI，并回填它
   *  - 没配 Key / 查询失败 → 保留原位置，只提示，绝不阻断保存
   *
   * @param replace  true = 用识别结果**覆盖**店名/地址（换选点位置时必须覆盖）；
   *                 false = 仅在字段为空时回填（用户手填过内容时不要冲掉）
   *
   * ⚠️ 为什么必须用参数而不是"先 setAddress('') 再识别"：
   *    React 的 setState 是异步的，紧接着调用本函数读到的仍是**旧值**，
   *    于是"再次双击换位置后地址不变"——用户就是这样反馈的。
   */
  const resolvePoi = async (pos: LatLng, replace = false): Promise<LatLng> => {
    const key = `${pos.lat.toFixed(5)},${pos.lng.toFixed(5)}`;
    if (checkedKey.current === key) return pos;
    checkedKey.current = key;

    setPoiBusy(true);
    setPoiHint('');
    try {
      const r = await getRoutingService().checkPoi(pos, POI_RADIUS_M);
      if (r.source === 'estimate') {
        setPoiHint('未配置高德 Key：无法判断该位置是否为餐厅（演示模式，保留你选的位置）');
        return pos;
      }
      if (r.isRestaurant && r.poi) {
        setAddress((a) => (replace || !a.trim() ? r.poi!.address || a : a));
        setName((n) => (replace || !n.trim() ? r.poi!.name : n));
        setPoiHint(`✓ 已识别为餐厅：${r.poi.name}（距离 ${Math.round(r.poi.distanceM)}m）`);
        return { lat: r.poi.lat, lng: r.poi.lng };
      }
      if (r.nearest) {
        setAddress((a) => (replace || !a.trim() ? r.nearest!.address || a : a));
        setName((n) => (replace || !n.trim() ? r.nearest!.name : n));
        setPoiHint(
          `该位置不是餐厅，已自动定位到最近的「${r.nearest.name}」（距离 ${Math.round(r.nearest.distanceM)}m）`,
        );
        return { lat: r.nearest.lat, lng: r.nearest.lng };
      }
      setPoiHint(`${POI_RADIUS_M}m 内没有找到餐厅，保留你选择的位置，请手动填写店名与地址`);
      return pos;
    } catch {
      setPoiHint('餐厅识别失败（网络或接口异常），已保留你选择的位置');
      return pos;
    } finally {
      setPoiBusy(false);
    }
  };

  // 地图双击带来的坐标：打开表单时就做一次餐厅识别
  useEffect(() => {
    if (!fromMap || !coord) return;
    const start = coord;
    void resolvePoi(start).then((p) => {
      if (p.lat !== start.lat || p.lng !== start.lng) setCoord(p);
    });
    // 只在挂载时对「地图点选坐标」检查一次
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * 地图待确认点变化（拖动微调，或**再次双击换位置**）→ 同步到表单。
   *
   * 用户要求：再次双击别处时，左侧表单的定位**与地址**都要跟着变。
   * 做法：更新坐标 → 清掉识别缓存与旧地址 → 重新做一次餐厅识别，由识别结果回填新地址。
   * （首次挂载保持原逻辑，交给上面那个 mount effect 处理，避免重复识别。）
   */
  const firstSync = useRef(true);
  useEffect(() => {
    if (initLat == null || initLng == null || (initLat === 0 && initLng === 0)) return;
    const pos = { lat: initLat, lng: initLng };
    setCoord(pos);
    setFromMap(true);
    if (firstSync.current) {
      firstSync.current = false;
      return;
    }
    checkedKey.current = '';
    setPoiHint('');
    // 关键：replace=true，用新地点的识别结果**覆盖**店名与地址
    //（不能靠先 setAddress('') —— setState 异步，读到的还是旧值）
    void resolvePoi(pos, true);
    // resolvePoi 是稳定引用（每次渲染重建但只在这里调用一次）
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initLat, initLng]);

  const locate = async (q: string) => {
    setLocating(true);
    setHint('');
    const pos = await geoService.geocode(q);
    setLocating(false);
    if (!pos) {
      setHint('没能识别这个地址，请写得更具体（例如「成都市武侯区玉林南路」），或改用「📍 地图点选」直接在地图上选位置。');
      return null;
    }
    const finalPos = await resolvePoi(pos);
    setCoord(finalPos);
    setFromMap(false);
    return finalPos;
  };

  /** 真正落库 */
  const persist = (pos: LatLng, price: number) => {
    const data = {
      name: name.trim(),
      address: address.trim(),
      lat: pos.lat,
      lng: pos.lng,
      cuisine,
      avgPrice: price,
      hours: [{ open, close }],
      stayMinutes: parseInt(stayMinutes, 10) || 60,
      priority,
      emoji,
    };
    if (initial?.id) updateRestaurant(initial.id, data);
    else addRestaurant(data);
    onClose();
  };

  const submit = async () => {
    if (!name.trim()) return;

    let pos = coord;
    if (!pos) {
      const q = address.trim();
      if (!q) {
        setHint('请填写地址（建议带上城市名），或点「📍 地图点选」直接在地图上选位置。');
        return;
      }
      pos = await locate(q);
      if (!pos) return;
    }

    const price = parseFloat(avgPrice) || 0;
    // 第 7 条：均价为 0 → 先问一句，不直接保存
    if (price === 0) {
      setAskZeroPrice(true);
      return;
    }
    persist(pos, price);
  };

  const busy = locating || poiBusy;

  return (
    <div className="space-y-2">
      <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="店名（必填）" />

      <div className="space-y-1">
        <Input
          value={address}
          onChange={(e) => {
            setAddress(e.target.value);
            if (!fromMap) setCoord(null); // 地址改了，此前的定位与餐厅识别都作废
            setHint('');
          }}
          placeholder="地址（建议带城市，如：成都市武侯区玉林南路）"
        />
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px]">
          <span className={coord ? 'text-mint' : 'text-black/40'}>
            {busy && (locating ? '正在根据地址定位…' : '正在识别该位置是否为餐厅…')}
            {!busy &&
              coord &&
              `已定位 ${coord.lat.toFixed(5)}, ${coord.lng.toFixed(5)}${
                fromMap ? '（来自地图点选）' : '（按地址解析）'
              }`}
            {!busy && !coord && '未定位：填写地址后会自动定位，或点「📍 地图点选」'}
          </span>
          {address.trim() !== '' && (
            <button
              type="button"
              disabled={busy}
              onClick={() => void locate(address.trim())}
              className="text-brand hover:underline disabled:opacity-40"
            >
              按地址重新定位
            </button>
          )}
        </div>
        {poiHint !== '' && <div className="text-[11px] text-brand">{poiHint}</div>}
        {hint !== '' && <div className="text-[11px] text-amber">{hint}</div>}
      </div>

      <div className="flex gap-2">
        {/* 类别：**始终只有一个框**，点开是「大类 + 悬浮出小类」的两级菜单 */}
        <div className="w-1/2 space-y-1">
          <div className="text-[11px] text-black/45">类别</div>
          <CuisinePicker value={cuisine} onChange={setCuisine} />
        </div>
        <div className="w-1/2 space-y-1">
          <div className="text-[11px] text-black/45">优先级</div>
          <Select value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
            <option value="must">必去</option>
            <option value="want">想去</option>
            <option value="optional">可选</option>
          </Select>
        </div>
      </div>

      <div className="flex gap-2">
        <Input
          value={avgPrice}
          onChange={(e) => {
            setAvgPrice(e.target.value);
            setAskZeroPrice(false);
          }}
          placeholder="人均 ¥"
          inputMode="numeric"
        />
        <Input
          value={stayMinutes}
          onChange={(e) => setStayMinutes(e.target.value)}
          placeholder="停留分钟"
          inputMode="numeric"
        />
      </div>

      {askZeroPrice && (
        <div className="rounded-xl bg-amber/10 p-3">
          <div className="text-xs font-medium text-amber">均价是否为 0 元？</div>
          <div className="mt-2 flex gap-2">
            <button
              type="button"
              className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs text-ink hover:border-brand hover:text-brand"
              onClick={() => {
                setAskZeroPrice(false);
                const pos = coord;
                if (pos) persist(pos, 0);
                else setHint('坐标还没确定，请先填写地址或在地图上点选。');
              }}
            >
              是，按 0 元保存
            </button>
            <button
              type="button"
              className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs text-ink/60 hover:border-black/30"
              onClick={() => setAskZeroPrice(false)}
            >
              否，不保存
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        <span className="text-xs text-black/50">营业</span>
        <Input type="time" value={open} onChange={(e) => setOpen(e.target.value)} />
        <span className="text-xs text-black/50">至</span>
        <Input type="time" value={close} onChange={(e) => setClose(e.target.value)} />
      </div>

      <Input value={emoji} onChange={(e) => setEmoji(e.target.value)} placeholder="Emoji 图标" />

      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" onClick={onClose}>
          取消
        </Button>
        <Button onClick={() => void submit()} disabled={!name.trim() || busy}>
          {busy ? '处理中…' : initial?.id ? '保存' : '添加'}
        </Button>
      </div>
    </div>
  );
}
