import { useEffect, useRef } from 'react';
import type { Restaurant } from '../../types';
import { PriorityBadge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { formatRatingText } from '../ui/StarRating';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useMapStore } from '../../store/useMapStore';
import { usePlanStore } from '../../store/usePlanStore';
import { useUiStore } from '../../store/useUiStore';
import { cityInitial, UNKNOWN_CITY } from '../../utils/citySort';

/**
 * 卡片右上角的城市角标文案：
 *   - 手动归类的卡片 → 「手动归类 · 成都 C」（与自动判定区分，用户一眼能看出不是自动分的）
 *   - 自动判定的卡片 → 「成都 C」；认不出城市时不显示角标。
 */
function cityLabel(city: string): string {
  if (city === UNKNOWN_CITY) return '城市未识别';
  return `${city} · ${cityInitial(city)}`;
}

/**
 * 清单页的餐厅卡片。
 *
 * 拖动归类（与项目其它地方——计划页 DragSortableList / OrderEditor——同一套 HTML5 拖放风格）：
 *   本组件只负责「把卡片做成可拖的」以及拖动期间自己的视觉反馈（半透明 + 拖拽光标），
 *   **真正的落点判定与写库在 RestaurantList 的城市分组上**（那里才知道目标城市是谁）：
 *     - 拖到某个城市分组标题 / 分组区域 → updateRestaurant(id, { city: 目标城市 })
 *     - 拖到分组标题右侧的「自动」虚线落点 → updateRestaurant(id, { city: undefined })
 *     - 卡片上还有「恢复自动」小按钮（与上面的落点二选一即可，这里两种都提供了）
 */
export function RestaurantCard({
  restaurant,
  selected,
  onEdit,
  onDragStartRestaurant,
  onDragEndRestaurant,
  onPointerDragStart,
  onPointerDragMove,
  onPointerDragEnd,
  dragging = false,
}: {
  restaurant: Restaurant;
  selected: boolean;
  onEdit: (r: Restaurant) => void;
  /** 开始拖拽（清单页据此高亮可落点、记录被拖的卡片） */
  onDragStartRestaurant?: (r: Restaurant) => void;
  onDragEndRestaurant?: () => void;
  /** 指针拖拽（触屏 + 鼠标通用）：把手按下 / 移动 / 松开 */
  onPointerDragStart?: (r: Restaurant, x: number, y: number) => void;
  onPointerDragMove?: (x: number, y: number) => void;
  onPointerDragEnd?: () => void;
  /** 这张卡片正在被拖动 */
  dragging?: boolean;
}) {
  const toggleSelect = useRestaurantStore((s) => s.toggleSelect);
  const removeRestaurant = useRestaurantStore((s) => s.removeRestaurant);
  const updateRestaurant = useRestaurantStore((s) => s.updateRestaurant);
  const setHovered = useMapStore((s) => s.setHovered);
  const focusRestaurant = useMapStore((s) => s.focusRestaurant);
  const selectedRestaurantId = useMapStore((s) => s.selectedRestaurantId);
  const openCheckIn = useUiStore((s) => s.openCheckIn);
  const checkIn = usePlanStore((s) => s.checkIns[restaurant.id]);
  const cardRef = useRef<HTMLDivElement>(null);
  const isMapSelected = selectedRestaurantId === restaurant.id;

  /**
   * 「手动归类」= 这张卡片被用户拖进过某个城市分组（restaurant.city 有值）。
   * 显示小字标识 + 「恢复自动」按钮，让用户知道这个城市不是自动判定的，
   * 并且能一键改回「地址 → 坐标 → 未识别」的自动判定。
   */
  const manualCity =
    typeof restaurant.city === 'string' && restaurant.city.trim() !== ''
      ? restaurant.city.trim()
      : null;

  // 地图 → 列表联动：点击 Marker 后把对应卡片滚入视野
  useEffect(() => {
    if (isMapSelected && cardRef.current) {
      cardRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [isMapSelected]);

  return (
    <div
      ref={cardRef}
      draggable
      onDragStart={(e) => {
        // dataTransfer 同时写纯文本与自定义 MIME：拖到别的分组时列表读 id 用
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', restaurant.id);
        e.dataTransfer.setData('application/x-dsh-restaurant', restaurant.id);
        onDragStartRestaurant?.(restaurant);
      }}
      onDragEnd={() => onDragEndRestaurant?.()}
      className={`list-item cursor-grab rounded-2xl border bg-white p-3 shadow-soft transition-all active:cursor-grabbing ${
        dragging ? 'opacity-50' : ''
      } ${
        isMapSelected
          ? 'border-brand ring-2 ring-brand/40'
          : selected
            ? 'border-brand'
            : 'border-transparent'
      }`}
      onMouseEnter={() => setHovered(restaurant.id)}
      onMouseLeave={() => setHovered(null)}
      onClick={() => focusRestaurant(restaurant.id)}
    >
      <div className="flex items-start gap-2">
        {/*
          拖拽把手。
          【为什么需要它】HTML5 拖放（draggable）在触屏上完全不工作，手机用户根本拖不动卡片。
          这里改用**指针事件**（pointerdown/move/up，鼠标与手指通用），并单独给把手
          `touch-none`（touch-action:none）——手指从把手开始移动时不会带动列表滚动，
          而列表其它区域照常可以上下滑动（如果把 touch-none 加在整张卡片上，列表就滑不动了）。
        */}
        <button
          type="button"
          aria-label="按住拖动，把这家店归到别的城市"
          title="按住拖动＝归类到别的城市（手机、电脑都可用）"
          draggable={false}
          onPointerDown={(e) => {
            if (e.button !== 0 && e.pointerType === 'mouse') return;
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            onPointerDragStart?.(restaurant, e.clientX, e.clientY);
          }}
          onPointerMove={(e) => {
            if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
            onPointerDragMove?.(e.clientX, e.clientY);
          }}
          onPointerUp={(e) => {
            if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
            e.currentTarget.releasePointerCapture(e.pointerId);
            onPointerDragEnd?.();
          }}
          onPointerCancel={() => onPointerDragEnd?.()}
          className="mt-0.5 shrink-0 cursor-grab touch-none rounded px-1 py-1 text-black/30 transition-colors hover:bg-black/5 hover:text-black/60 active:cursor-grabbing"
        >
          ⠿
        </button>
        <input
          type="checkbox"
          checked={selected}
          // 勾选框自己不是拖拽起点，否则用户想勾选却会拖起整张卡片
          draggable={false}
          onChange={() => toggleSelect(restaurant.id)}
          onClick={(e) => e.stopPropagation()}
          className="mt-1 accent-brand"
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-base leading-none">{restaurant.emoji ?? '🍴'}</span>
            <span className="truncate font-medium">{restaurant.name}</span>
            <PriorityBadge priority={restaurant.priority} />
          </div>
          <div className="mt-1 text-xs text-black/50">
            <div className="truncate">{restaurant.address || '未填写地址'}</div>
            <div className="mt-0.5">
              {restaurant.cuisine} · ¥{restaurant.avgPrice}/人 · 停留{restaurant.stayMinutes}分钟
            </div>
            {checkIn && (
              <div className="mt-0.5 font-medium text-mint">
                已打卡 · {formatRatingText(checkIn.rating)}
              </div>
            )}
            <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5">
              {manualCity && (
                <>
                  {/* 手动归类的可见标识：告诉用户这张卡片被拖动指定过城市 */}
                  <span className="rounded bg-brand-light px-1.5 py-0.5 font-medium text-brand">
                    手动归类 · {cityLabel(manualCity)}
                  </span>
                  <button
                    type="button"
                    draggable={false}
                    onClick={(e) => {
                      e.stopPropagation();
                      // 清除手动指定 → 回到「地址 → 坐标 → 未识别」的自动判定
                      updateRestaurant(restaurant.id, { city: undefined });
                    }}
                    className="rounded border border-dashed border-black/20 px-1.5 py-0.5 text-black/50 hover:border-brand hover:text-brand"
                  >
                    恢复自动
                  </button>
                </>
              )}
              {!manualCity && restaurant.city === undefined && (
                <span className="text-black/30">按住 ⠿ 可拖动归类城市</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex shrink-0 flex-col gap-1">
          {/* 打卡入口放在清单卡片上：以前只有「时间轴卡片」和「地图 Marker 弹窗」有，
              用户在清单页根本找不到打卡按钮，反馈"打卡功能无法使用"。 */}
          <Button
            size="sm"
            variant={checkIn ? 'ghost' : 'secondary'}
            draggable={false}
            onClick={(e) => {
              e.stopPropagation();
              openCheckIn(restaurant.id);
            }}
          >
            {checkIn ? '已打卡' : '打卡'}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            draggable={false}
            onClick={(e) => {
              e.stopPropagation();
              onEdit(restaurant);
            }}
          >
            编辑
          </Button>
          <Button
            size="sm"
            variant="ghost"
            draggable={false}
            onClick={(e) => {
              e.stopPropagation();
              removeRestaurant(restaurant.id);
            }}
          >
            删除
          </Button>
        </div>
      </div>
    </div>
  );
}
