import { useEffect, useMemo, useRef, useState } from 'react';
import type { DragEvent } from 'react';
import type { Restaurant } from '../../types';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useMapStore } from '../../store/useMapStore';
import { usePlanStore } from '../../store/usePlanStore';
import { RestaurantCard } from './RestaurantCard';
import { RestaurantForm } from './RestaurantForm';
import { SearchBox } from './SearchBox';
import { SampleTrips } from '../plan/SampleTrips';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { guessCity } from '../../algorithms/intercity';
import { cityByCoords } from '../../algorithms/cityLookup';
import { cityInitial, compareCity, UNKNOWN_CITY } from '../../utils/citySort';

/**
 * 四级城市判定（顺序是硬要求，前一级命中就不再往后看）。
 *
 * ```
 * ① restaurant.city                     // 用户手动拖动归类的城市，优先
 *   ?? guessCity(restaurant.address)    // ② 地址里的城市名（最长匹配 / 最靠前出现位置）
 *   ?? cityByCoords(lat, lng)           // ③ 坐标就近推断（150km 内最近的 158 城之一）
 *   ?? UNKNOWN_CITY                     // ④ 都认不出 → 归入「未识别城市」，永远排最后
 * ```
 *
 * 为什么要抽成函数：分组（未打卡段 / 已打卡段各分一次）与卡片角标都用同一套判定，
 * 抽出来就不会出现「分组说是成都、角标写着重庆」这种两处逻辑不一致的问题。
 *
 * 注意 ② 是 `??` 而不是 `||`：guessCity 返回的是 `string | null`，null 才继续往下走；
 * 而 ④ 的 UNKNOWN_CITY 是兜底，保证返回值永远是 string（分组键因此可以直接当 Map 键用）。
 */
export function resolveCity(r: Restaurant): string {
  return r.city ?? guessCity(r.address) ?? cityByCoords(r.lat, r.lng) ?? UNKNOWN_CITY;
}

/** 取「手动指定的城市」；没有手动指定则返回 null（用于判断是否显示「恢复自动」） */
function manualCityOf(r: Restaurant): string | null {
  return typeof r.city === 'string' && r.city.trim() !== '' ? r.city.trim() : null;
}

/** 一个城市分组：城市名 + 该组里的餐厅（已按「自动判定的在前、手动拖进来的在后」排好） */
type CityGroup = {
  city: string;
  /** 组内手动归类的餐厅数量（> 0 才显示「自动」落点） */
  manualCount: number;
  items: Restaurant[];
};

/**
 * 一个「大段」（未打卡段 / 已打卡段）的数据：段内按城市分组，城市用 compareCity 排序。
 *
 * 为什么分组只在渲染时做、**绝不重排 restaurants 数组本身**：
 *   1. restaurants 是 store 里的唯一数据源，写回 localStorage 的也是它；
 *      一旦为了「显示分组」而把数组按城市重排，就等于用视图需求篡改了持久化数据；
 *   2. 其它地方（地图 Marker、规划算法、按 id 查找）都依赖数组顺序稳定，
 *      视图重排会导致「同一个操作前后两次跑出不同结果」这类难查的问题；
 *   3. 分组是纯粹的派生数据，用 useMemo 在渲染时算一遍最划算，也最安全。
 */
type CitySegment = {
  checked: boolean;
  total: number;
  groups: CityGroup[];
};

/**
 * 把一段餐厅按城市分组。
 *
 * 段内顺序：先「自动判定城市」的餐厅，再「手动拖进来」的餐厅 —— 这样用户刚拖过去的卡片
 * 会出现在该城市分组的**末尾**（一放下就能看到，符合「放下＝压栈到组尾」的直觉）。
 * 两组内部都保持 restaurants 数组里的原始相对顺序（稳定）。
 */
function buildSegment(items: Restaurant[], isChecked: boolean): CitySegment {
  const groupMap = new Map<string, CityGroup>();
  for (const r of items) {
    const city = resolveCity(r);
    const group = groupMap.get(city) ?? { city, manualCount: 0, items: [] };
    if (manualCityOf(r) !== null) group.manualCount += 1;
    group.items.push(r);
    groupMap.set(city, group);
  }

  const groups = [...groupMap.values()];
  for (const group of groups) {
    // 自动判定的排前面（false < true），手动归类的排后面；同组内保持原始顺序
    const rank = (r: Restaurant): number => (manualCityOf(r) === null ? 0 : 1);
    group.items = group.items
      .map((r, index) => ({ r, index }))
      .sort((a, b) => rank(a.r) - rank(b.r) || a.index - b.index)
      .map((x) => x.r);
  }
  groups.sort((a, b) => compareCity(a.city, b.city));

  return { checked: isChecked, total: items.length, groups };
}

/** 拖拽时在 dataTransfer 里放的 MIME 键（纯文本键作跨浏览器兜底） */
const DRAG_MIME = 'application/x-dsh-restaurant';

/**
 * 拖动悬停目标的一个「哨兵前缀」：`${AUTO_DROP_CITY}${城市名}` 表示鼠标正停在某个分组的「自动」落点上。
 * 真实城市名不会以这个字符串开头（它们来自城市表或「未识别城市」），
 * 于是 dragOverCity 一个 state 就能同时表达「悬停在城市 X」和「悬停在 X 的自动落点」，
 * 且能保证只有真正被悬停的那一个落点高亮。
 */
const AUTO_DROP_CITY = '__dsh_auto__';

export function RestaurantList() {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const selectedIds = useRestaurantStore((s) => s.selectedIds);
  const selectAll = useRestaurantStore((s) => s.selectAll);
  const clearSelection = useRestaurantStore((s) => s.clearSelection);
  const updateRestaurant = useRestaurantStore((s) => s.updateRestaurant);
  const checkIns = usePlanStore((s) => s.checkIns);
  const [editing, setEditing] = useState<Restaurant | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const pickMode = useMapStore((s) => s.pickMode);
  const startPick = useMapStore((s) => s.startPick);
  const cancelPick = useMapStore((s) => s.cancelPick);
  const clearPicked = useMapStore((s) => s.clearPicked);
  const pickedCoord = useMapStore((s) => s.pickedCoord);

  /** 拖动归类状态：被拖的餐厅 id、当前悬停的城市（键）、被拖卡片的名字（提示文案用） */
  const [dragId, setDragId] = useState<string | null>(null);
  const [dragOverCity, setDragOverCity] = useState<string | null>(null);
  const [dragName, setDragName] = useState('');
  /** 指针拖拽的实时位置：跟着手指（鼠标）走的提示气泡用 */
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);

  const formRef = useRef<HTMLDivElement>(null);

  // 地图上双击确定位置后：打开表单，并把它滚进视野（否则表单可能在面板下方看不见）
  useEffect(() => {
    if (!pickedCoord) return;
    setFormOpen(true);
    const t = setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 0);
    return () => clearTimeout(t);
  }, [pickedCoord]);

  // 渲染时分组：把「未打卡」「已打卡」分开，各自按城市分组、城市按 compareCity 排序。
  // restaurants 数组本身绝不被重排（原因见 CitySegment 上的注释）。
  const { unchecked, checked } = useMemo(() => {
    const pending: Restaurant[] = [];
    const done: Restaurant[] = [];
    for (const r of restaurants) {
      if (checkIns[r.id]) done.push(r);
      else pending.push(r);
    }
    return {
      unchecked: buildSegment(pending, false),
      checked: buildSegment(done, true),
    };
  }, [restaurants, checkIns]);

  const allSelected = restaurants.length > 0 && selectedIds.length === restaurants.length;

  /** 开始拖动某张卡片：记录 id 与名字（用于拖动中的提示条） */
  const handleDragStart = (r: Restaurant) => {
    setDragId(r.id);
    setDragName(r.name);
    setDragOverCity(null);
  };

  /** 拖动结束（放下 / 取消 / 拖出窗口）：无论哪种都要清干净，避免分组一直高亮 */
  const handleDragEnd = () => {
    setDragId(null);
    setDragOverCity(null);
    setDragName('');
  };

  /**
   * 触屏拖拽：用**指针事件**实现 —— HTML5 拖放在触屏上完全不工作，
   * 手机上以前根本拖不动卡片（用户反馈「写程序使其有效」）。
   *
   * 落点判定用 `document.elementFromPoint` 找最近的带 `data-city` 的元素，
   * 所以分组标题、分组卡片区、以及每组的「自动」按钮都要挂 data-city。
   * 跟随手指的气泡必须 `pointer-events-none`，否则 elementFromPoint 只会命中气泡自己。
   */
  const targetCityAt = (x: number, y: number): string | null => {
    const el = document.elementFromPoint(x, y) as HTMLElement | null;
    const holder = el?.closest('[data-city]') as HTMLElement | null;
    return holder?.dataset.city ?? null;
  };

  const handlePointerDragStart = (r: Restaurant, x: number, y: number) => {
    setDragId(r.id);
    setDragName(r.name);
    setDragPos({ x, y });
    setDragOverCity(targetCityAt(x, y));
  };

  const handlePointerDragMove = (x: number, y: number) => {
    setDragPos({ x, y });
    setDragOverCity(targetCityAt(x, y));
  };

  /** 松手落点：命中某组的「自动」落点 → 恢复自动判定；命中城市分组 → 指定该城市 */
  const handlePointerDragEnd = () => {
    const id = dragId;
    const target = dragOverCity;
    if (id && target) {
      if (target.startsWith(AUTO_DROP_CITY)) {
        updateRestaurant(id, { city: undefined });
      } else {
        const r = restaurants.find((x) => x.id === id);
        if (r && manualCityOf(r) !== target) updateRestaurant(id, { city: target });
      }
    }
    handleDragEnd();
    setDragPos(null);
  };

  /**
   * 放下卡片 → 手动指定城市（写入 restaurant.city）。
   * dataTransfer 里的 id 优先，读不到时回退到 state 里的 dragId（某些浏览器不给读自定义 MIME）。
   */
  const handleDropToCity = (city: string, e: DragEvent<HTMLElement>) => {
    e.preventDefault();
    const id = e.dataTransfer.getData(DRAG_MIME) || e.dataTransfer.getData('text/plain') || dragId;
    if (id) {
      const target = restaurants.find((r) => r.id === id);
      // 已经在目标城市里就不重复写库（但「恢复自动」落点除外，见下）
      if (target && manualCityOf(target) !== city) {
        updateRestaurant(id, { city });
      }
    }
    handleDragEnd();
  };

  /** 放到「自动」落点：清除手动指定，回到四级判定的自动结果 */
  const handleDropToAuto = (e: DragEvent<HTMLElement>) => {
    e.preventDefault();
    const id = e.dataTransfer.getData(DRAG_MIME) || e.dataTransfer.getData('text/plain') || dragId;
    if (id) updateRestaurant(id, { city: undefined });
    handleDragEnd();
  };

  const renderCard = (r: Restaurant) => (
    <RestaurantCard
      key={r.id}
      restaurant={r}
      selected={selectedIds.includes(r.id)}
      onEdit={setEditing}
      onDragStartRestaurant={handleDragStart}
      onDragEndRestaurant={handleDragEnd}
      onPointerDragStart={handlePointerDragStart}
      onPointerDragMove={handlePointerDragMove}
      onPointerDragEnd={handlePointerDragEnd}
      dragging={dragId === r.id}
    />
  );

  /**
   * 渲染一个城市分组：标题行（城市名 · 首字母 · 数量）+ 右侧「自动」落点 + 卡片区域。
   * 标题行与卡片区域都是落点：拖到其中任意一处都算「归到这个城市」。
   */
  const renderGroup = (group: CityGroup, size: 'sm' | 'md') => {
    const isDragOver = dragId !== null && dragOverCity === group.city;
    // 「自动」落点的高亮：只有真正悬停的那一个分组高亮（要靠 group.city 限定，
    // 否则所有分组的自动落点会一起亮起来，用户就不知道会落到哪个组）
    const isAutoOver = dragId !== null && dragOverCity === `${AUTO_DROP_CITY}${group.city}`;
    return (
      <div key={group.city} className="mt-2 space-y-1.5">
        {/* data-city：指针拖拽的落点标记（elementFromPoint 靠它判定目标城市） */}
        <div
          data-city={group.city}
          onDragOver={(e) => {
            e.preventDefault(); // 不 preventDefault 就不会触发 drop
            e.dataTransfer.dropEffect = 'move';
            if (dragOverCity !== group.city) setDragOverCity(group.city);
          }}
          onDrop={(e) => handleDropToCity(group.city, e)}
          className={`flex items-center gap-2 rounded-lg border border-transparent px-2 py-1 transition-colors ${
            isDragOver ? 'border-brand bg-brand-light' : ''
          }`}
        >
          <span className={`font-semibold text-ink ${size === 'sm' ? 'text-xs' : 'text-sm'}`}>
            {group.city}
            {/* 首字母：UNKNOWN_CITY 的首字母是 '#'，直接展示 */}
            <span className="ml-1 rounded bg-black/5 px-1 text-black/50">
              {cityInitial(group.city)}
            </span>
          </span>
          <span className="text-xs text-black/40">
            {group.items.length} 家
            {group.manualCount > 0 && ` · 手动 ${group.manualCount}`}
          </span>
          {/* 「自动」落点：拖上去＝这一步只恢复这一张卡片；
              点一下＝整组手动归类的卡片都恢复自动判定。
              dragover 必须拦下来（preventDefault），否则浏览器不认它是落点。 */}
          <button
            type="button"
            draggable={false}
            data-city={`${AUTO_DROP_CITY}${group.city}`}
            onDragOver={(e) => {
              e.preventDefault();
              e.stopPropagation();
              e.dataTransfer.dropEffect = 'move';
              if (dragOverCity !== `${AUTO_DROP_CITY}${group.city}`) {
                setDragOverCity(`${AUTO_DROP_CITY}${group.city}`);
              }
            }}
            onDrop={(e) => {
              e.stopPropagation();
              handleDropToAuto(e);
            }}
            onClick={(e) => {
              e.stopPropagation();
              // 组内所有手动归类的卡片一起恢复自动判定
              for (const r of group.items) {
                if (manualCityOf(r) !== null) updateRestaurant(r.id, { city: undefined });
              }
            }}
            className={`ml-auto rounded border border-dashed px-1.5 py-0.5 text-[11px] transition-colors ${
              isAutoOver
                ? 'border-brand bg-brand text-white'
                : 'border-black/20 text-black/40 hover:border-brand hover:text-brand'
            }`}
            title="把卡片拖到这里＝恢复自动分类（按地址 / 坐标判定）；点一下＝整组恢复自动"
          >
            {group.manualCount > 0 ? '自动（点一下整组恢复）' : '自动'}
          </button>
        </div>
        {/* 组内所有卡片也是落点：放到卡片之间的空隙同样算「归到这个城市」 */}
        <div
          data-city={group.city}
          onDragOver={(e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            if (dragOverCity !== group.city) setDragOverCity(group.city);
          }}
          onDrop={(e) => handleDropToCity(group.city, e)}
          className={`space-y-2 rounded-xl px-1 py-1 transition-colors ${
            isDragOver ? 'bg-brand-light ring-2 ring-brand/40' : ''
          }`}
        >
          {group.items.map(renderCard)}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3" onDragEnd={handleDragEnd}>
      {/* 指针拖拽时跟随手指/鼠标的提示气泡：必须 pointer-events-none，
          否则 elementFromPoint 只会命中它自己，落点判定全部失效 */}
      {dragId && dragPos && (
        <div
          className="pointer-events-none fixed z-[2500] -translate-x-1/2 -translate-y-[130%] whitespace-nowrap rounded-full bg-ink/90 px-3 py-1.5 text-[11px] text-white shadow-soft"
          style={{ left: dragPos.x, top: dragPos.y }}
        >
          {dragName} → {dragOverCity ? (dragOverCity.startsWith(AUTO_DROP_CITY) ? '恢复自动分类' : `归到「${dragOverCity}」`) : '拖动到城市分组上松手'}
        </div>
      )}
      <SearchBox />

      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" variant="secondary" onClick={() => setFormOpen(true)}>
          + 手动添加
        </Button>
        <Button size="sm" variant="ghost" onClick={pickMode ? cancelPick : startPick}>
          {pickMode ? '取消选址' : '📍 地图点选'}
        </Button>
        <div className="ml-auto flex gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => selectAll(restaurants.map((r) => r.id))}
            disabled={allSelected}
          >
            全选
          </Button>
          <Button size="sm" variant="ghost" onClick={clearSelection} disabled={selectedIds.length === 0}>
            取消全选
          </Button>
        </div>
      </div>

      {pickMode && (
        <div className="rounded-xl bg-brand-light px-3 py-2 text-xs text-brand">
          点选模式已开启：在地图上<b>双击左键</b>确定位置，确定后<b>仍留在点选模式</b>，可连续添加多家；
          <b>右键点标记</b>可微调或删除。点「取消选址」退出。
        </div>
      )}

      {pickedCoord && (
        <div className="rounded-xl bg-mint/10 px-3 py-2 text-xs text-mint">
          已确定坐标 {pickedCoord.lat.toFixed(5)}, {pickedCoord.lng.toFixed(5)}
          ，请填写下方信息后点「添加」；保存后再双击地图即可继续添加下一家。
        </div>
      )}

      {formOpen && (
        <div ref={formRef}>
          <Card>
            <RestaurantForm
              initial={pickedCoord ? { lat: pickedCoord.lat, lng: pickedCoord.lng } : undefined}
              onClose={() => {
                setFormOpen(false);
                // 只清掉待确认坐标，不退出点选模式（便于连续添加）
                clearPicked();
              }}
            />
          </Card>
        </div>
      )}

      {editing && (
        <Card>
          <RestaurantForm initial={editing} onClose={() => setEditing(null)} />
        </Card>
      )}

      {restaurants.length === 0 ? (
        <div className="flex flex-col items-center gap-3 py-8 text-center">
          <div className="text-4xl">🍽️</div>
          <p className="text-sm text-black/50">还没有餐厅，搜索或手动添加你的第一家吧</p>
          <Button size="sm" variant="secondary" onClick={startPick}>
            从地图点选一家
          </Button>
        </div>
      ) : (
        <>
          {/* 拖动中的全局提示：让人知道「往哪放」「怎么放」 */}
          {dragId !== null && (
            <div className="rounded-xl border-2 border-dashed border-brand/50 bg-brand-light px-3 py-2 text-xs text-brand">
              正在拖动「{dragName}」：放到某个<b>城市分组</b>（标题行或卡片区域）＝手动归到这个城市；
              放到分组标题右侧的<b>虚线「自动」</b>上＝恢复自动分类。
            </div>
          )}

          {/* ===== 上段：未打卡 ===== */}
          {unchecked.total > 0 && (
            <section className="space-y-2">
              <h3 className="text-base font-semibold text-ink">
                未打卡（{unchecked.total}）
                <span className="ml-2 text-xs font-normal text-black/40">
                  共 {unchecked.groups.length} 个城市
                </span>
              </h3>
              {unchecked.groups.map((g) => renderGroup(g, 'md'))}
            </section>
          )}

          {/* ===== 下段：已打卡（一律排在未打卡之后，同样按城市分组） ===== */}
          {checked.total > 0 && (
            <section className="space-y-2 rounded-2xl bg-mint/5 p-2 ring-1 ring-mint/20">
              <h3 className="text-base font-semibold text-mint">
                已打卡（{checked.total}）
                <span className="ml-2 text-xs font-normal text-black/40">
                  共 {checked.groups.length} 个城市
                </span>
              </h3>
              {checked.groups.map((g) => renderGroup(g, 'sm'))}
            </section>
          )}
        </>
      )}

      <div className="pt-2">
        <SampleTrips />
      </div>
    </div>
  );
}
