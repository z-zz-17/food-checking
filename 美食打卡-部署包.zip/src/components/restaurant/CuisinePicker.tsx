import { useEffect, useRef, useState } from 'react';
import {
  CUISINE_GROUP_LIST,
  FALLBACK_GROUP,
  groupByLabel,
  groupOfCuisine,
  isKnownCuisine,
} from '../../data/cuisines';

/**
 * 类别悬浮菜单（纯展示组件，便于无浏览器环境下断言结构）。
 *
 * 布局：左边一列**大类**，鼠标悬浮（onMouseEnter）某一大类时，
 * 右边自动出现它所属的**小类**；只有小类可以被点选。
 */
export function CuisineMenu({
  activeGroup,
  onHoverGroup,
  onPick,
  extraItem,
}: {
  /** 当前悬浮中的大类名 */
  activeGroup: string;
  onHoverGroup: (label: string) => void;
  onPick: (cuisine: string) => void;
  /** 清单外的现有类别（如搜索带来的"私房菜"），只有在大类是「其他」时才出现 */
  extraItem?: string;
}) {
  const group = groupByLabel(activeGroup);
  const items =
    group.label === FALLBACK_GROUP.label && extraItem !== undefined && extraItem.trim() !== ''
      ? [extraItem, ...group.items]
      : group.items;

  return (
    <div className="flex overflow-hidden rounded-xl border border-black/10 bg-white shadow-soft">
      {/* 左列：大类（悬浮即切换右侧小类，本身不可选） */}
      <div className="w-28 shrink-0 border-r border-black/5 bg-cream/60 py-1">
        {CUISINE_GROUP_LIST.map((g) => {
          const active = g.label === group.label;
          return (
            <div
              key={g.label}
              onMouseEnter={() => onHoverGroup(g.label)}
              /*
               * 触屏没有 hover：手指点大类也要能展开右侧小类。
               * 桌面端 hover 与 click 同时存在不冲突（点一下只是把右侧切到该组）。
               */
              onClick={() => onHoverGroup(g.label)}
              aria-current={active ? 'true' : undefined}
              className={`cursor-default px-3 py-1.5 text-sm transition-colors ${
                active ? 'bg-white font-medium text-brand' : 'text-ink/70 hover:bg-white/70'
              }`}
            >
              {g.label}
            </div>
          );
        })}
      </div>

      {/* 右列：当前大类的小类 —— 只有这里能被点选 */}
      <div className="max-h-64 w-40 overflow-y-auto py-1">
        {items.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => onPick(c)}
            className="block w-full px-3 py-1.5 text-left text-sm text-ink/80 transition-colors hover:bg-brand-light hover:text-brand"
          >
            {c}
            {c === extraItem && <span className="ml-1 text-[11px] text-black/35">（当前）</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

/**
 * 类别选择器：**始终只显示一个框**（显示当前类别），
 * 点开后在框下方弹出「大类 + 悬浮小类」的两级菜单，选中小类即回填并收起。
 *
 * 关闭方式：选中任意小类 / 按 Esc / 点击组件外部。
 */
export function CuisinePicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (cuisine: string) => void;
}) {
  const [open, setOpen] = useState(false);
  /** 悬浮中的大类：每次打开都按当前值重新定位，保证"改川菜时左边就停在各地菜系" */
  const [activeGroup, setActiveGroup] = useState(() => groupOfCuisine(value).label);
  const rootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    const onDown = (e: MouseEvent) => {
      const root = rootRef.current;
      if (root && e.target instanceof Node && root.contains(e.target)) return;
      setOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onDown);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onDown);
    };
  }, [open]);

  return (
    <div ref={rootRef} className="relative">
      {/* 唯一的一个类别框 */}
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => {
          setActiveGroup(groupOfCuisine(value).label);
          setOpen((v) => !v);
        }}
        className="flex w-full items-center justify-between rounded-xl border border-black/10 bg-white px-3 py-2 text-left text-sm text-ink outline-none hover:border-brand/40 focus:border-brand"
      >
        <span className="truncate">
          {value.trim() === '' ? '选择类别' : value}
          {!isKnownCuisine(value) && value.trim() !== '' && (
            <span className="ml-1 text-[11px] text-black/35">（清单外）</span>
          )}
        </span>
        <span className="ml-2 shrink-0 text-black/30">▾</span>
      </button>

      {open && (
        <div className="absolute left-0 top-full z-[2000] mt-1">
          <CuisineMenu
            activeGroup={activeGroup}
            onHoverGroup={setActiveGroup}
            onPick={(c) => {
              onChange(c);
              setOpen(false);
            }}
            extraItem={!isKnownCuisine(value) ? value : undefined}
          />
        </div>
      )}
    </div>
  );
}
