import { useEffect, useRef, useState } from 'react';
import { geoService } from '../../services/geo';
import type { GeoSearchResult } from '../../types';
import { Input } from '../ui/Input';
import { useRestaurantStore } from '../../store/useRestaurantStore';

export function SearchBox() {
  const [kw, setKw] = useState('');
  const [results, setResults] = useState<GeoSearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const addRestaurant = useRestaurantStore((s) => s.addRestaurant);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  useEffect(() => {
    if (!kw.trim()) {
      setResults([]);
      setOpen(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    geoService.searchPlaces(kw).then((r) => {
      if (cancelled) return;
      setResults(r);
      setOpen(true);
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [kw]);

  const pick = (r: GeoSearchResult) => {
    addRestaurant({
      name: r.name,
      address: r.address,
      lat: r.lat,
      lng: r.lng,
      cuisine: r.cuisine || '其他',
      avgPrice: r.avgPrice || 50,
      hours: [{ open: '10:00', close: '21:00' }],
      stayMinutes: 60,
      priority: 'want',
      emoji: '🍜',
    });
    setKw('');
    setOpen(false);
  };

  return (
    <div ref={boxRef} className="relative">
      <Input
        value={kw}
        onChange={(e) => setKw(e.target.value)}
        placeholder="搜索餐厅名称 / 菜系 / 地址…"
      />
      {open && (
        <div className="absolute z-20 mt-1 max-h-72 w-full overflow-auto rounded-xl border border-black/10 bg-white shadow-soft">
          {loading && <div className="p-3 text-sm text-black/40">搜索中…</div>}
          {!loading && results.length === 0 && (
            <div className="p-3 text-sm text-black/40">未找到结果，试试手动添加</div>
          )}
          {results.map((r) => (
            <button
              key={r.id}
              onClick={() => pick(r)}
              className="flex w-full items-start gap-2 px-3 py-2 text-left transition-colors hover:bg-brand-light"
            >
              <span className="text-lg leading-none">🍜</span>
              <span className="flex-1 text-sm">
                <span className="font-medium">{r.name}</span>
                <span className="block text-xs text-black/50">{r.address}</span>
              </span>
              <span className="text-xs text-black/40">{r.cuisine}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
