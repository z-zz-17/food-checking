import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, Tooltip, useMap } from 'react-leaflet';
import L from 'leaflet';
import { DEFAULT_TILE_SOURCE, TILE_SOURCES } from '../../config/map';
import { DAY_COLORS } from '../../config/palette';
import type { MapPoint, MapRoute } from './MapView';

/** 选点模式第 2 条：进入微调后地图放大 50% */
const TUNE_ZOOM_FACTOR = 1.5;
/** 缩放级别与比例是对数关系，故步长为 log2(1.5) ≈ 0.585 */
const TUNE_ZOOM_STEP = Math.log2(TUNE_ZOOM_FACTOR);
/** 配合 zoomSnap，实际落在 0.5 级别（≈ 放大 41%） */
const ZOOM_SNAP = 0.25;

/** 右键菜单里代表「待确认位置」的哨兵 id（它还不是一家餐厅） */
const PENDING_ID = '__pending__';

function numberedIcon(number: number, color: string, checkedIn?: boolean, highlight = false) {
  const size = checkedIn ? 30 : highlight ? 44 : 34;
  const bg = checkedIn ? '#9CA3AF' : color;
  const ring = highlight ? `stroke="#2B2B2B" stroke-width="2"` : '';
  const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
        <circle cx="${size / 2}" cy="${size / 2}" r="${size / 2 - 2}" fill="${bg}" ${ring} />
        ${
          checkedIn
            ? `<path d="M${size * 0.3} ${size * 0.55} l${size * 0.15} ${size * 0.15} l${size * 0.3} -${size * 0.35}" stroke="white" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`
            : `<text x="${size / 2}" y="${size / 2 + 1}" text-anchor="middle" dominant-baseline="middle" font-size="${size * 0.5}" font-weight="bold" fill="white">${number}</text>`
        }
      </svg>`;
  const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  return L.divIcon({
    html: `<img src="${url}" style="width:${size}px;height:${size}px;transform:translate(-50%,-100%);position:absolute;" />`,
    className: '',
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
  });
}

/** 已双击确定、尚未提交表单的位置：画一个醒目的准星 */
function pendingIcon() {
  const s = 36;
  const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">
        <circle cx="${s / 2}" cy="${s / 2}" r="${s / 2 - 2}" fill="#FF6B4A" fill-opacity="0.22" stroke="#FF6B4A" stroke-width="2.5"/>
        <circle cx="${s / 2}" cy="${s / 2}" r="4" fill="#FF6B4A"/>
      </svg>`;
  const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  return L.divIcon({
    html: `<img src="${url}" style="width:${s}px;height:${s}px;" />`,
    className: '',
    iconSize: [s, s],
    iconAnchor: [s / 2, s / 2],
  });
}

/** 把 map 实例交给父组件使用（useMap 只能在 MapContainer 内部调用） */
function MapBridge({ onReady }: { onReady: (m: L.Map) => void }) {
  const map = useMap();
  useEffect(() => {
    onReady(map);
  }, [map, onReady]);
  return null;
}

function FitBounds({ points }: { points: MapPoint[] }) {
  const map = useMap();
  // 只在「点位集合」发生变化时重新适配视野
  const idKey = points
    .map((p) => p.id)
    .sort()
    .join(',');
  useEffect(() => {
    if (points.length === 0) return;
    map.fitBounds(
      L.latLngBounds(points.map((p) => [p.lat, p.lng] as [number, number])),
      {
        padding: [40, 40],
        maxZoom: 16,
      },
    );
    // 依赖 idKey 而非 points：见上方注释
  }, [idKey, map]);
  return null;
}

/**
 * 是否触摸设备（决定「双击」的含义）。
 *
 * 用户指定的手机手势：
 *   · 单击 = 确定位置（落点）
 *   · 双指滑动 = 缩放、单指滑动 = 平移（Leaflet 原生，无需改）
 *   · 双击 = 相当于**鼠标右键**（弹出该点的微调 / 删除菜单）
 * 桌面端保持原样：双击左键 = 确定位置。
 *
 * 触屏还必须关掉 Leaflet 的双击缩放，否则双击会顺带把地图放大一倍。
 */
function isTouchDevice(): boolean {
  if (typeof window === 'undefined') return false;
  const coarse =
    typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches;
  return coarse || 'ontouchstart' in window || (typeof navigator !== 'undefined' && (navigator.maxTouchPoints ?? 0) > 0);
}

/**
 * 容器尺寸变化后 Leaflet 必须重新测量，否则瓦片与折线可能整体不显示。
 * 这里用 **ResizeObserver** 覆盖所有情况：切换标签页、手机底部抽屉展开/收起、
 * 横竖屏切换、窗口缩放 —— 比只监听 window.resize 可靠得多（手机端尤其重要）。
 */
function KeepMapSized() {
  const map = useMap();
  useEffect(() => {
    const fix = () => map.invalidateSize();
    fix();
    const timer = window.setTimeout(fix, 200);
    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver === 'function') {
      observer = new ResizeObserver(fix);
      observer.observe(map.getContainer());
    }
    window.addEventListener('resize', fix);
    window.addEventListener('orientationchange', fix);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('resize', fix);
      window.removeEventListener('orientationchange', fix);
      observer?.disconnect();
    };
  }, [map]);
  return null;
}

/** 左键点地图任意处 → 关闭右键菜单 */
function MenuDismiss({ onDismiss }: { onDismiss: () => void }) {
  const map = useMap();
  useEffect(() => {
    map.on('click', onDismiss);
    map.on('movestart', onDismiss);
    return () => {
      map.off('click', onDismiss);
      map.off('movestart', onDismiss);
    };
  }, [map, onDismiss]);
  return null;
}

function FocusHandler({
  focus,
  onDone,
}: {
  focus: { lat: number; lng: number } | null;
  onDone: () => void;
}) {
  const map = useMap();
  useEffect(() => {
    if (!focus) return;
    map.flyTo([focus.lat, focus.lng], Math.max(map.getZoom(), 15), { duration: 0.6 });
    const t = setTimeout(onDone, 800);
    return () => clearTimeout(t);
  }, [focus, map, onDone]);
  return null;
}

/** 双击确定后，把地图移到该点，让用户立刻看到准星 */
function PanToPending({ point }: { point: { lat: number; lng: number } | null }) {
  const map = useMap();
  useEffect(() => {
    if (!point) return;
    map.panTo([point.lat, point.lng], { animate: true });
  }, [point, map]);
  return null;
}

export default function LeafletMap({
  center,
  zoom,
  points,
  routes,
  pending,
  onMoveMarker,
  onMovePending,
  onClearPending,
  onMapClick,
  onDelete,
  pickMode,
  hoveredId,
  selectedRestaurantId,
  onMarkerClick,
  focusId,
  onFocusDone,
  onCheckIn,
}: {
  center: { lat: number; lng: number };
  zoom: number;
  points: MapPoint[];
  routes: MapRoute[];
  pending: { lat: number; lng: number } | null;
  onMoveMarker: (id: string, gcj: { lat: number; lng: number }) => void;
  onMovePending: (gcj: { lat: number; lng: number }) => void;
  onClearPending: () => void;
  onMapClick: (p: { lat: number; lng: number }) => void;
  onDelete: (id: string) => void;
  pickMode: boolean;
  hoveredId: string | null;
  selectedRestaurantId: string | null;
  onMarkerClick: (id: string) => void;
  focusId: string | null;
  onFocusDone: () => void;
  onCheckIn: (id: string) => void;
}) {
  const src = TILE_SOURCES[DEFAULT_TILE_SOURCE.id] ?? DEFAULT_TILE_SOURCE;
  const focusPoint = focusId ? points.find((p) => p.id === focusId) : null;

  const [map, setMap] = useState<L.Map | null>(null);
  const [menu, setMenu] = useState<{ id: string; name: string; x: number; y: number } | null>(null);
  const [tuningId, setTuningId] = useState<string | null>(null);
  /** 选点模式第 3 条：待确认的位置也能进入微调（拖动准星） */
  const [tuningPending, setTuningPending] = useState(false);

  /** 触摸设备：决定单击/双击的含义（见 isTouchDevice 注释） */
  const touch = useMemo(isTouchDevice, []);
  /**
   * 「刚刚点过标记」的时间戳。
   * Leaflet 里点击标记也会冒泡出地图 click —— 触屏上如果不拦一下，
   * 用户想看某家店的信息，就会顺带把待确认点挪到那家店的位置。
   */
  const markerHitRef = useRef(0);

  // 点选模式：关掉双击缩放（触屏上任何时候都要关，因为双击被定义为"右键菜单"）
  useEffect(() => {
    if (!map) return;
    if (pickMode || touch) map.doubleClickZoom.disable();
    else map.doubleClickZoom.enable();
  }, [map, pickMode, touch]);

  // 手势：鼠标双击落点；触屏单击落点、双击＝右键菜单（用户指定）
  useEffect(() => {
    if (!map || !pickMode) return;
    const toPoint = (e: L.LeafletMouseEvent) => ({ lat: e.latlng.lat, lng: e.latlng.lng });
    const onClick = (e: L.LeafletMouseEvent) => {
      if (!touch) return; // 鼠标仍然只认双击
      if (Date.now() - markerHitRef.current < 400) return; // 刚点过标记，不当作落点
      onMapClick(toPoint(e));
    };
    const onDbl = (e: L.LeafletMouseEvent) => {
      if (!touch) {
        onMapClick(toPoint(e));
        return;
      }
      // 触屏双击 = 鼠标右键：对待确认点弹出微调 / 删除菜单
      if (pending) openMenuAt(PENDING_ID, '待确认的位置', pending);
    };
    map.on('click', onClick);
    map.on('dblclick', onDbl);
    return () => {
      map.off('click', onClick);
      map.off('dblclick', onDbl);
    };
  }, [map, pickMode, touch, onMapClick, pending]);

  // 进入点选模式时，退出微调并收起菜单
  useEffect(() => {
    if (!pickMode) return;
    setTuningId(null);
    setTuningPending(false);
    setMenu(null);
  }, [pickMode]);

  // 待确认位置被提交/清除后，微调状态要跟着复位
  useEffect(() => {
    if (!pending) setTuningPending(false);
  }, [pending]);

  const closeMenu = useCallback(() => setMenu(null), []);

  /** 在指定坐标上弹出右键菜单（把坐标显式传入，待确认点没有 MapPoint） */
  const openMenuAt = (id: string, name: string, at: { lat: number; lng: number }) => {
    if (!map) return;
    const pt = map.latLngToContainerPoint([at.lat, at.lng]);
    const size = map.getSize();
    setMenu({
      id,
      name,
      x: Math.max(8, Math.min(pt.x, size.x - 158)),
      y: Math.max(8, Math.min(pt.y, size.y - 96)),
    });
  };

  /** 微调：可拖动 + 地图放大 50%（并居中到它） */
  const startTune = (id: string) => {
    setMenu(null);
    const at =
      id === PENDING_ID
        ? pending
        : (() => {
            const p = points.find((x) => x.id === id);
            return p ? { lat: p.lat, lng: p.lng } : null;
          })();
    if (!at) return;

    if (id === PENDING_ID) {
      setTuningPending(true);
      setTuningId(null);
    } else {
      setTuningId(id);
      setTuningPending(false);
    }
    if (map) {
      map.setView([at.lat, at.lng], map.getZoom() + TUNE_ZOOM_STEP, { animate: true });
    }
  };

  /** 删除：餐厅走 onDelete；待确认点走 onClearPending。两者都不动 pickMode */
  const doDelete = (id: string) => {
    setMenu(null);
    if (id === PENDING_ID) {
      setTuningPending(false);
      onClearPending();
      return;
    }
    if (tuningId === id) setTuningId(null);
    onDelete(id);
  };

  return (
    <div className="relative h-full w-full" onContextMenu={(e) => e.preventDefault()}>
      <MapContainer
        center={[center.lat, center.lng]}
        zoom={zoom}
        zoomSnap={ZOOM_SNAP}
        doubleClickZoom={!pickMode}
        scrollWheelZoom
        className="h-full w-full"
        style={pickMode ? { cursor: 'crosshair' } : undefined}
      >
        <TileLayer
          url={src.url}
          subdomains={src.subdomains}
          attribution={src.attribution}
          maxZoom={18}
        />

        <MapBridge onReady={setMap} />
        <KeepMapSized />
        <FitBounds points={points} />
        <MenuDismiss onDismiss={closeMenu} />
        <PanToPending point={pending} />
        <FocusHandler
          focus={focusPoint ? { lat: focusPoint.lat, lng: focusPoint.lng } : null}
          onDone={onFocusDone}
        />

        {/* 真实路径折线：按小段着色（步行/骑行/各条地铁线路各有其色），线更粗 */}
        {routes.map((route, ri) => (
          <Polyline
            key={`route-${route.dayIndex}-${ri}`}
            positions={route.points.map((p) => [p.lat, p.lng] as [number, number])}
            pathOptions={{
              color: route.color ?? DAY_COLORS[route.dayIndex % DAY_COLORS.length],
              weight: route.weight ?? 6,
              opacity: 0.9,
              lineCap: 'round',
              lineJoin: 'round',
              dashArray: route.dashed ? '6 8' : undefined,
            }}
          />
        ))}

        {points.map((p) => {
          const color = p.dayIndex != null ? DAY_COLORS[p.dayIndex % DAY_COLORS.length] : '#FF6B4A';
          const isHover = hoveredId === p.id;
          const isSelected = selectedRestaurantId === p.id;
          const icon = numberedIcon(p.order ?? 0, color, p.checkedIn, isHover || isSelected);
          /**
           * 只有进入「微调」的标记可以拖动。
           * 用户指定的触屏手势是「启动微调后单指滑动微调」；以前点选模式下
           * **所有**标记都可拖，导致手机上想平移地图时手指落在标记上就把标记拖走了。
           */
          const draggable = tuningId === p.id;
          return (
            <Marker
              key={p.id}
              position={[p.lat, p.lng]}
              icon={icon}
              draggable={draggable}
              eventHandlers={{
                dragend: (e) => {
                  if (!draggable) return;
                  const pos = (e.target as L.Marker).getLatLng();
                  onMoveMarker(p.id, { lat: pos.lat, lng: pos.lng });
                },
                click: () => {
                  // 记下"刚点过标记"，避免这次点击又被当成地图落点（见 markerHitRef 注释）
                  markerHitRef.current = Date.now();
                  onMarkerClick(p.id);
                },
                contextmenu: () => openMenuAt(p.id, p.name, p),
              }}
            >
              {/* Marker 上的「打卡」标签 —— 直接就是一个打卡入口（用户要求），
                  不必先点开弹窗；已打卡则显示星数。interactive 让标签可点。 */}
              <Tooltip direction="top" offset={[0, -2]} permanent interactive opacity={1}>
                <button
                  type="button"
                  onClick={() => onCheckIn(p.id)}
                  className="whitespace-nowrap text-[11px] font-medium text-brand hover:underline"
                >
                  {p.checkedIn ? `已打卡${p.rating ? ` ★${p.rating}` : ''}` : '打卡'}
                </button>
              </Tooltip>
              <Popup>
                <div className="min-w-[160px]">
                  <div className="font-medium">
                    {p.emoji} {p.name}
                  </div>
                  <div className="text-xs text-black/60">
                    {p.cuisine} · ¥{p.avgPrice}/人
                  </div>
                  {p.dayIndex != null && (
                    <div className="mt-1 text-xs">
                      第{p.dayIndex + 1}天第{p.order}站 · 到店 {p.arriveAt}
                    </div>
                  )}
                  <div className="mt-1 text-xs text-black/45">右键点标记可微调 / 删除</div>
                  <div className="mt-2">
                    <button
                      onClick={() => onCheckIn(p.id)}
                      className={`rounded-lg px-2 py-1 text-xs ${
                        p.checkedIn ? 'bg-black/10 text-black/50' : 'bg-brand text-white'
                      }`}
                    >
                      {p.checkedIn ? '已打卡' : '标记已打卡'}
                    </button>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {/* 待确认位置：可直接右键微调 / 删除，不必先保存成餐厅 */}
        {pending && (
          <Marker
            position={[pending.lat, pending.lng]}
            icon={pendingIcon()}
            draggable={tuningPending}
            eventHandlers={{
              dragend: (e) => {
                if (!tuningPending) return;
                const pos = (e.target as L.Marker).getLatLng();
                onMovePending({ lat: pos.lat, lng: pos.lng });
              },
              contextmenu: () => openMenuAt(PENDING_ID, '待确认的位置', pending),
            }}
          />
        )}
      </MapContainer>

      {/* 顶部手势提示条：微调中 > 待填表单 > 普通点选 */}
      {tuningId || tuningPending ? (
        <div className="absolute left-1/2 top-3 z-[1000] flex -translate-x-1/2 items-center gap-3 whitespace-nowrap rounded-full bg-mint px-4 py-2 text-[11px] text-white shadow-soft">
          <span>微调中：拖动标记到准确位置（地图已放大 50%）</span>
          <button
            type="button"
            className="rounded-full bg-white/25 px-2 py-0.5 text-white"
            onClick={() => {
              setTuningId(null);
              setTuningPending(false);
            }}
          >
            完成
          </button>
        </div>
      ) : pickMode ? (
        <div
          className={`pointer-events-none absolute left-1/2 top-3 z-[1000] -translate-x-1/2 whitespace-nowrap rounded-full px-4 py-2 text-[11px] text-white shadow-soft ${
            pending ? 'bg-amber' : 'bg-ink/85'
          }`}
        >
          {pending ? (
            touch ? (
              <>
                已选定位置：<b>双击它</b>可微调 / 删除，或<b>单击别处换位置</b>
              </>
            ) : (
              <>已选定一个位置：可拖动准星微调、右键微调/删除，或<b>再次双击别处换位置</b></>
            )
          ) : touch ? (
            <>
              点选模式：<b>单击</b>确定位置 · <b>双击</b>＝微调/删除 · 单指平移、双指缩放
            </>
          ) : (
            <>
              点选模式：<b>双击左键</b>确定位置 · <b>右键点标记</b>可微调 / 删除
            </>
          )}
        </div>
      ) : null}

      {/* 右键菜单 */}
      {menu && (
        <div
          className="absolute z-[1000] w-[150px] overflow-hidden rounded-xl border border-black/10 bg-white shadow-soft"
          style={{ left: menu.x, top: menu.y }}
        >
          <div className="truncate border-b border-black/5 px-3 py-1.5 text-[11px] text-black/40">
            {menu.name}
          </div>
          <button
            type="button"
            className="block w-full px-3 py-2 text-left text-xs text-ink transition-colors hover:bg-brand-light"
            onClick={() => startTune(menu.id)}
          >
            🎯 微调位置
          </button>
          <button
            type="button"
            className="block w-full px-3 py-2 text-left text-xs text-red-600 transition-colors hover:bg-red-50"
            onClick={() => doDelete(menu.id)}
          >
            🗑 删除{menu.id === PENDING_ID ? '这个点' : '这家'}
          </button>
        </div>
      )}
    </div>
  );
}
