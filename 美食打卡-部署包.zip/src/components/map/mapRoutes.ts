/**
 * 由行程方案推导「地图折线」的纯函数。
 *
 * 为什么单独成文件：这段逻辑原先内联在 MapView 里，而 LeafletMap 是 React.lazy 懒加载，
 * 服务端渲染只能渲染出 fallback —— 于是"线条颜色/粗细/虚线/跨城不画线"这些规则
 * 在无浏览器环境下无法断言。抽成纯函数后即可直接单测（见 .selfcheck/ssr-check.js）。
 *
 * 画线规则（对应用户需求）：
 *   ① 有真实分段折线 → **按小段着色**（步行灰、骑行蓝、地铁按线路色），线更粗（7）；
 *   ② 只有整段折线 → 用当天主题色，线稍细（5）；
 *   ③ 都没有折线时：
 *        · 城际（带 intercitySummary，即铁路/航班估算）→ **不画线**（避免直线横跨两座城市）；
 *        · 同城（估算或取数失败）→ 用**虚线**直连上一站，保证"同城段都要显示"；
 *        · 通勤 0 分钟（出发点就是这一家）→ 不画。
 */
import { wgs84ToGcj02 } from '../../algorithms/coords';
import { DAY_COLORS } from '../../config/palette';
import type { Restaurant, TripPlan } from '../../types';

export type MapRoute = {
  dayIndex: number;
  points: { lat: number; lng: number }[];
  /** 线条颜色（按小段的线路色，或当天主题色） */
  color?: string;
  /** 线宽：分段实线更粗，整段路径稍细 */
  weight?: number;
  /** 虚线（用于"同城但没拿到真实路径"的兜底连线） */
  dashed?: boolean;
};

export function buildMapRoutes(
  plan: TripPlan | null,
  restaurants: Restaurant[],
  origin: { lat: number; lng: number },
): MapRoute[] {
  if (!plan) return [];

  const out: MapRoute[] = [];
  const toGcj = (p: { lat: number; lng: number }) => {
    const c = wgs84ToGcj02(p.lat, p.lng);
    return { lat: c.lat, lng: c.lng };
  };
  const originGcj = toGcj(origin);

  plan.days.forEach((day, di) => {
    const dayColor = DAY_COLORS[di % DAY_COLORS.length];
    let prev = originGcj;

    for (const st of day.stops) {
      const leg = st.travelFromPrev;
      const rest = restaurants.find((x) => x.id === st.restaurantId);
      const target = rest && rest.lat && rest.lng ? toGcj({ lat: rest.lat, lng: rest.lng }) : null;

      // ① 分段真实路径（公共交通会拆成 步行 / 地铁 / 步行）
      let drew = false;
      for (const sg of leg.segments ?? []) {
        if (sg.path && sg.path.length > 1) {
          out.push({
            dayIndex: di,
            points: sg.path.map(toGcj),
            color: sg.color ?? dayColor,
            weight: 7,
          });
          drew = true;
        }
      }

      // ② 整段真实路径（步行/骑行/驾车通常只有一个总段）
      if (!drew && leg.path && leg.path.length > 1) {
        out.push({ dayIndex: di, points: leg.path.map(toGcj), color: dayColor, weight: 5 });
        drew = true;
      }

      // ③ 兜底
      if (!drew) {
        const isIntercity = !leg.path && !!leg.intercitySummary;
        if (!isIntercity && target && leg.minutes > 0) {
          out.push({
            dayIndex: di,
            points: [prev, target],
            color: dayColor,
            weight: 4,
            dashed: true,
          });
        }
        // 跨城铁路/航班：什么都不画
      }

      if (target) prev = target;
    }
  });

  return out.filter((r) => r.points.length > 1);
}
