import { lazy, Suspense, useCallback, useMemo } from 'react';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { usePlanStore } from '../../store/usePlanStore';
import { useMapStore } from '../../store/useMapStore';
import { useUiStore } from '../../store/useUiStore';
import { MAP_CENTER, MAP_ZOOM } from '../../config/map';
import { wgs84ToGcj02, gcj02ToWgs84 } from '../../algorithms/coords';
import { buildMapRoutes, type MapRoute } from './mapRoutes';

const LeafletMap = lazy(() => import('./LeafletMap'));

export type MapPoint = {
  id: string;
  name: string;
  emoji: string;
  cuisine: string;
  avgPrice: number;
  lat: number;
  lng: number;
  selected: boolean;
  checkedIn?: boolean;
  /** 已打卡时的星数（Marker 上的打卡标签要显示 ★4.5） */
  rating?: number;
  dayIndex?: number;
  order?: number;
  arriveAt?: string;
};

/** 折线类型定义在 mapRoutes.ts（纯函数模块），这里重新导出供 LeafletMap 使用 */
export type { MapRoute };

export function MapView() {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const selectedIds = useRestaurantStore((s) => s.selectedIds);
  const updateRestaurant = useRestaurantStore((s) => s.updateRestaurant);
  const removeRestaurant = useRestaurantStore((s) => s.removeRestaurant);
  const plan = usePlanStore((s) => s.plan);
  const checkIns = usePlanStore((s) => s.checkIns);
  const params = usePlanStore((s) => s.params);
  const pickMode = useMapStore((s) => s.pickMode);
  const pickedCoord = useMapStore((s) => s.pickedCoord);
  const finishPick = useMapStore((s) => s.finishPick);
  const clearPicked = useMapStore((s) => s.clearPicked);
  const hoveredId = useMapStore((s) => s.hoveredId);
  const selectedRestaurantId = useMapStore((s) => s.selectedRestaurantId);
  const setSelected = useMapStore((s) => s.setSelected);
  const focusId = useMapStore((s) => s.focusId);
  const clearFocus = useMapStore((s) => s.clearFocus);
  const openCheckIn = useUiStore((s) => s.openCheckIn);

  const stopMap = useMemo(() => {
    const m = new Map<string, { dayIndex: number; order: number; arriveAt: string }>();
    plan?.days.forEach((d, di) => {
      d.stops.forEach((st) => {
        m.set(st.restaurantId, { dayIndex: di, order: st.order, arriveAt: st.arriveAt });
      });
    });
    return m;
  }, [plan]);

  const points: MapPoint[] = useMemo(
    () =>
      restaurants
        .filter((r) => r.lat && r.lng)
        .map((r) => {
          const c = wgs84ToGcj02(r.lat, r.lng);
          const stop = stopMap.get(r.id);
          return {
            id: r.id,
            name: r.name,
            emoji: r.emoji ?? '🍴',
            cuisine: r.cuisine,
            avgPrice: r.avgPrice,
            lat: c.lat,
            lng: c.lng,
            selected: selectedIds.includes(r.id),
            checkedIn: !!checkIns[r.id],
            rating: checkIns[r.id]?.rating,
            dayIndex: stop?.dayIndex,
            order: stop?.order,
            arriveAt: stop?.arriveAt,
          };
        }),
    [restaurants, selectedIds, checkIns, stopMap],
  );

  const pending = useMemo(() => {
    if (!pickedCoord) return null;
    const c = wgs84ToGcj02(pickedCoord.lat, pickedCoord.lng);
    return { lat: c.lat, lng: c.lng };
  }, [pickedCoord]);

  /**
   * 路线只在「规划」标签页显示（用户明确的期望效果）：
   *   · 切到清单 / 统计时，地图不画路线；
   *   · 切回规划且勾选没有变化时，上一轮生成的路线会重新显示
   *     （行程本身一直留在 store 里，不会被标签切换清掉）。
   */
  const activeTab = useUiStore((s) => s.activeTab);
  const routes: MapRoute[] = useMemo(
    () => (activeTab === 'plan' ? buildMapRoutes(plan, restaurants, params.origin) : []),
    [activeTab, plan, restaurants, params.origin],
  );

  const handleMoveMarker = useCallback(
    (id: string, gcj: { lat: number; lng: number }) => {
      const w = gcj02ToWgs84(gcj.lat, gcj.lng);
      updateRestaurant(id, { lat: w.lat, lng: w.lng });
    },
    [updateRestaurant],
  );

  /** 选点模式第 3 条：拖动待确认的准星 → 更新 pickedCoord（表单会同步这个坐标） */
  const handleMovePending = useCallback(
    (gcj: { lat: number; lng: number }) => {
      const w = gcj02ToWgs84(gcj.lat, gcj.lng);
      finishPick({ lat: w.lat, lng: w.lng });
    },
    [finishPick],
  );

  const handleMapConfirm = useCallback(
    (gcj: { lat: number; lng: number }) => {
      if (!pickMode) return;
      // 用户要求：已有一个待确认坐标时，再次双击**直接改到新位置**，
      // 并且左侧表单的坐标与地址都要跟着变（以前这里会忽略第二次双击）。
      const w = gcj02ToWgs84(gcj.lat, gcj.lng);
      finishPick({ lat: w.lat, lng: w.lng });
    },
    [pickMode, finishPick],
  );

  return (
    <Suspense
      fallback={
        <div className="flex h-full w-full items-center justify-center bg-cream text-sm text-black/40">
          地图加载中…
        </div>
      }
    >
      <LeafletMap
        center={{ lat: MAP_CENTER.lat, lng: MAP_CENTER.lng }}
        zoom={MAP_ZOOM}
        points={points}
        routes={routes}
        pending={pending}
        onMoveMarker={handleMoveMarker}
        onMovePending={handleMovePending}
        onClearPending={clearPicked}
        onMapClick={handleMapConfirm}
        onDelete={removeRestaurant}
        pickMode={pickMode}
        hoveredId={hoveredId}
        selectedRestaurantId={selectedRestaurantId}
        onMarkerClick={setSelected}
        focusId={focusId}
        onFocusDone={clearFocus}
        onCheckIn={openCheckIn}
      />
    </Suspense>
  );
}
