import { Component, type ReactNode } from 'react';

export class MapErrorBoundary extends Component<
  { children: ReactNode },
  { hasError: boolean }
> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex h-full w-full items-center justify-center bg-cream text-sm text-black/40">
          地图加载失败，请刷新重试
        </div>
      );
    }
    return this.props.children;
  }
}
