import { useEffect, useRef, useState } from 'react';
import { usePlanStore } from '../../store/usePlanStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useUiStore } from '../../store/useUiStore';
import { Button } from '../ui/Button';

/**
 * 设置弹窗。
 *
 * 目前只有一件事：**清空所有数据**（餐厅清单 / 行程 / 规划参数 / 打卡记录）。
 *
 * 三个必须遵守的约定：
 *  1. **z-index 用 z-[2000]**：Leaflet 自带面板是 400~1000，Tailwind 的 z-50 会被地图盖住
 *     （打卡弹窗就踩过这个坑，表现为"点了没反应"）；
 *  2. 遮罩 `pointer-events-none`：事件穿透到底层，不会锁住整页；交互只发生在卡片上；
 *  3. 清空要**二次确认**，并说明"不可恢复"。
 */
export function SettingsDialog() {
  const open = useUiStore((s) => s.settingsOpen);
  const close = useUiStore((s) => s.closeSettings);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const checkIns = usePlanStore((s) => s.checkIns);
  const plan = usePlanStore((s) => s.plan);

  const [confirming, setConfirming] = useState(false);
  const [cleared, setCleared] = useState(false);
  const cardRef = useRef<HTMLDivElement | null>(null);

  // Esc 关闭 + 点卡片以外（＝点遮罩）关闭
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    const onDown = (e: MouseEvent) => {
      const card = cardRef.current;
      if (card && e.target instanceof Node && card.contains(e.target)) return;
      close();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onDown);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onDown);
    };
  }, [open, close]);

  // 每次打开都回到初始态，不要留着上次的「已清空」提示或待确认状态
  useEffect(() => {
    if (open) {
      setConfirming(false);
      setCleared(false);
    }
  }, [open]);

  if (!open) return null;

  const checkInCount = Object.keys(checkIns).length;

  const clearAll = () => {
    /*
     * 顺序很重要：
     *   ① plan store 的 resetAll() 会调用 storage.clearAll()，删掉全部 food-checkin: 键；
     *   ② 餐厅 store 的 resetAll() 再写入**空数组**。
     * 如果反过来，① 会把 ② 刚写好的空数组一起删掉 —— 下次加载
     * loadInitial() 见"存档不存在"就会自动装回内置样例行程，用户会以为没清干净。
     */
    usePlanStore.getState().resetAll();
    useRestaurantStore.getState().resetAll();
    setConfirming(false);
    setCleared(true);
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-[2000] flex items-center justify-center p-4">
      {/* 压暗层：只做视觉，不吃事件 */}
      <div className="pointer-events-none absolute inset-0 bg-black/30" />

      <div
        ref={cardRef}
        className="pointer-events-auto w-full max-w-md rounded-2xl bg-white p-4 shadow-soft"
      >
        <div className="mb-3 flex items-center justify-between">
          <div className="font-medium">⚙️ 设置</div>
          <button
            type="button"
            aria-label="关闭设置"
            className="text-black/40 hover:text-black/70"
            onClick={close}
          >
            ✕
          </button>
        </div>

        {/* 当前数据概览 */}
        <div className="rounded-xl bg-cream p-3 text-xs text-black/60">
          <div className="mb-1 font-medium text-ink">当前暂存数据</div>
          <div className="space-y-0.5">
            <div>餐厅清单：{restaurants.length} 家</div>
            <div>已打卡：{checkInCount} 家</div>
            <div>上一轮行程：{plan ? `${plan.days.length} 天` : '无'}</div>
          </div>
          <div className="mt-1.5 text-black/35">数据保存在本浏览器（localStorage），换浏览器或清缓存会丢。</div>
        </div>

        {/* 清空数据 */}
        <div className="mt-3 rounded-xl border border-[#F44336]/30 p-3">
          <div className="text-sm font-medium text-[#F44336]">清空所有数据</div>
          <div className="mt-1 text-xs text-black/50">
            会删除餐厅清单、行程、规划参数与打卡记录，且**不可恢复**。清空后清单为空（不会自动装回样例）。
          </div>

          {cleared ? (
            <div className="mt-2 rounded-lg bg-mint/10 px-3 py-2 text-xs text-mint">
              ✓ 已清空。列表、行程与打卡记录都已重置，无需刷新页面。
            </div>
          ) : confirming ? (
            <div className="mt-2 space-y-2">
              <div className="rounded-lg bg-[#F44336]/10 px-3 py-2 text-xs text-[#F44336]">
                确认清空？此操作不可撤销。
              </div>
              <div className="flex gap-2">
                <Button
                  variant="primary"
                  size="sm"
                  className="!bg-[#F44336] hover:!bg-[#e03a2e]"
                  onClick={clearAll}
                >
                  确认清空
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setConfirming(false)}>
                  取消
                </Button>
              </div>
            </div>
          ) : (
            <Button
              variant="secondary"
              size="sm"
              className="mt-2 !border-[#F44336]/40 !text-[#F44336]"
              onClick={() => setConfirming(true)}
            >
              清空所有数据
            </Button>
          )}
        </div>

        <div className="mt-3 flex justify-end">
          <Button variant="ghost" onClick={close}>
            关闭
          </Button>
        </div>
      </div>
    </div>
  );
}
