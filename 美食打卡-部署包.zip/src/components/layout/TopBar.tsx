import { usePlanStore } from '../../store/usePlanStore';
import { useUiStore } from '../../store/useUiStore';
import { fmtMoney } from '../../utils/format';

export function TopBar() {
  const plan = usePlanStore((s) => s.plan);
  const checkIns = usePlanStore((s) => s.checkIns);
  const openSettings = useUiStore((s) => s.openSettings);
  const totalCost = plan?.days.reduce((s, d) => s + d.totalCost, 0) ?? 0;
  const budget = plan?.totalBudget ?? 0;
  const ratio = budget > 0 ? totalCost / budget : 0;
  const color = ratio > 1 ? '#F44336' : ratio > 0.8 ? '#F5A623' : '#3DBE8B';

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-black/5 bg-white px-4">
      <div className="flex items-center gap-2">
        <span className="text-xl">🍜</span>
        <span className="font-semibold">美食打卡</span>
      </div>
      <div className="flex items-center gap-3">
        {Object.keys(checkIns).length > 0 && (
          // 窄屏（手机）先不显示这行文字，避免和预算条、设置按钮挤在一起
          <span className="hidden text-xs text-black/50 sm:inline">
            已打卡 {Object.keys(checkIns).length} 家
          </span>
        )}
        {plan && budget > 0 && (
          <div className="flex items-center gap-2">
            <div className="h-2 w-16 overflow-hidden rounded-full bg-black/10 sm:w-28">
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${Math.min(ratio * 100, 100)}%`, background: color }}
              />
            </div>
            <span className="text-xs font-medium" style={{ color }}>
              {fmtMoney(totalCost)} / {fmtMoney(budget)}
            </span>
          </div>
        )}
        <button
          type="button"
          onClick={openSettings}
          title="设置（清空所有数据）"
          aria-label="设置"
          className="rounded-xl px-2 py-1 text-sm text-black/50 transition-colors hover:bg-black/5 hover:text-ink"
        >
          ⚙️ 设置
        </button>
      </div>
    </header>
  );
}
