import { Component, type ErrorInfo, type ReactNode } from 'react';

type Props = { children: ReactNode; label?: string };
type State = { error: Error | null };

/**
 * 兜底错误边界。
 *
 * 为什么必须有它：React 18 里任何一处渲染抛错，都会把整棵组件树卸载 ——
 * 页面变成**全白**，用户看到的只有"打不开 / 无法运行"，既没有报错也没有线索，
 * 只能反复猜测。有了错误边界，出错时会在页面上直接显示错误原文与调用栈，
 * 截图发出来就能定位。
 *
 * 注意：错误边界只能捕获**渲染期**的错误（含子组件），
 * 事件回调里的异步错误要靠 try/catch（生成行程那段已经加了）。
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    // 同时打到控制台，便于 F12 里复制
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render(): ReactNode {
    const { error } = this.state;
    if (!error) return this.props.children;

    return (
      <div className="m-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
        <div className="font-medium">
          {this.props.label ?? '界面'}出错了 —— 这是程序 bug，不是你的数据问题
        </div>
        <pre className="mt-2 max-h-48 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-white/80 p-2 text-[11px] leading-relaxed">
          {error.message}
          {'\n'}
          {String(error.stack ?? '')
            .split('\n')
            .slice(0, 8)
            .join('\n')}
        </pre>
        <div className="mt-2 flex items-center gap-2">
          <button
            type="button"
            className="rounded-lg bg-white px-3 py-1 text-xs text-red-700 ring-1 ring-red-200 hover:bg-red-100"
            onClick={() => this.setState({ error: null })}
          >
            重试渲染
          </button>
          <span className="text-[11px] text-red-500/80">
            请把上面这段文字截图或复制发给助手
          </span>
        </div>
      </div>
    );
  }
}
