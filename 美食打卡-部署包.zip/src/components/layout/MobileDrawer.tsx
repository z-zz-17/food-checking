import { useState } from 'react';
import { ControlPanel } from './ControlPanel';

/**
 * 手机端底部抽屉（桌面端隐藏）。
 *
 * 布局约定：地图始终铺满剩余的整块区域，抽屉只占底部一条；
 * 展开后最多 60vh，并且：
 *   · 点按区域加大（手机上手指比鼠标难精准）；
 *   · 底部留出 iPhone 安全区（配合 index.html 的 viewport-fit=cover）；
 *   · overscroll-contain 防止滚到底后继续带动整页。
 * 抽屉开合会改变地图容器高度 —— 地图那边用 ResizeObserver 自动重测，不会白屏。
 */
export function MobileDrawer() {
  const [open, setOpen] = useState(false);

  return (
    <div className="md:hidden">
      <div className="border-t border-black/10 bg-white px-4 pt-1 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
        <button
          type="button"
          className="mx-auto flex w-full items-center justify-center gap-1 py-2.5 text-xs text-black/60"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
        >
          <span className="text-base leading-none">{open ? '▾' : '▴'}</span>
          {open ? '收起' : '展开清单 / 规划'}
        </button>
      </div>
      {open && (
        <div className="max-h-[60vh] overflow-y-auto overscroll-contain bg-white p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
          <ControlPanel />
        </div>
      )}
    </div>
  );
}
