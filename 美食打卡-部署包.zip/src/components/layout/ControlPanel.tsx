import { useEffect } from 'react';
import { RestaurantList } from '../restaurant/RestaurantList';
import { PlanView } from '../plan/PlanView';
import { StatsPanel } from '../stats/StatsPanel';
import { Button } from '../ui/Button';
import { useMapStore } from '../../store/useMapStore';
import { useUiStore, type UiTab } from '../../store/useUiStore';

const TABS: { key: UiTab; label: string }[] = [
  { key: 'list', label: '清单' },
  { key: 'plan', label: '规划' },
  { key: 'stats', label: '统计' },
];

export function ControlPanel() {
  // 标签页放在 store 里：地图（MapView）需要据此决定是否绘制路线
  const tab = useUiStore((s) => s.activeTab);
  const setTab = useUiStore((s) => s.setActiveTab);
  const selectedRestaurantId = useMapStore((s) => s.selectedRestaurantId);
  const pickMode = useMapStore((s) => s.pickMode);
  const cancelPick = useMapStore((s) => s.cancelPick);

  // 地图 → 列表联动：点击 Marker 时切回「清单」页，保证目标卡片已挂载可滚动
  useEffect(() => {
    if (selectedRestaurantId) setTab('list');
  }, [selectedRestaurantId, setTab]);

  /**
   * 选点模式第 1 条：切换页签时自动关闭选点模式，并清除未保存的选点。
   * cancelPick 会同时清掉 pickMode 与 pickedCoord；
   * 至于已填一半的表单——它挂在被切换掉的页签里，卸载即随之丢弃。
   */
  const switchTab = (next: UiTab) => {
    if (pickMode) cancelPick();
    setTab(next);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex gap-1 border-b border-black/5 p-2">
        {TABS.map((t) => (
          <Button
            key={t.key}
            size="sm"
            variant={tab === t.key ? 'primary' : 'ghost'}
            onClick={() => switchTab(t.key)}
            className="flex-1"
          >
            {t.label}
          </Button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {tab === 'list' && <RestaurantList />}
        {tab === 'plan' && <PlanView />}
        {tab === 'stats' && <StatsPanel />}
      </div>
    </div>
  );
}
