import { useMemo } from 'react';
import type { TripPlan } from '../../types';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { segmentColor } from '../../data/lineColors';
import { DAY_COLORS } from '../../config/palette';
import { fmtKm, fmtMoney } from '../../utils/format';
import { DragSortableList } from './DragSortableList';

export function Timeline({ plan }: { plan: TripPlan }) {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const byId = new Map(restaurants.map((r) => [r.id, r]));

  /** 指令 6(4)：只要有任意一段走了估算模型，免责声明就要换成"无任何参考价值" */
  const hasEstimate = plan.days.some((d) =>
    d.stops.some((s) => s.travelFromPrev.estimated === true),
  );

  /** 本次路线实际用到的线条颜色 → 生成图例（按出现顺序去重） */
  const legend = useMemo(() => {
    const seen = new Map<string, string>();
    for (const d of plan.days) {
      for (const st of d.stops) {
        for (const sg of st.travelFromPrev.segments ?? []) {
          if (!seen.has(sg.label)) {
            seen.set(sg.label, sg.color ?? segmentColor(sg.kind, sg.label));
          }
        }
      }
    }
    return [...seen.entries()].map(([label, color]) => ({ label, color }));
  }, [plan]);

  /** 有多少段走了真实路网（用于让"到底有没有用上高德"一眼可见） */
  const stats = useMemo(() => {
    let real = 0;
    let est = 0;
    for (const d of plan.days) {
      for (const st of d.stops) {
        if (st.travelFromPrev.minutes <= 0) continue;
        if (st.travelFromPrev.estimated) est += 1;
        else real += 1;
      }
    }
    return { real, est };
  }, [plan]);

  if (plan.days.length === 0) {
    return (
      <div className="py-10 text-center text-sm text-black/50">
        <div className="text-4xl">🗺️</div>
        <p className="mt-2">还没有行程，勾选餐厅后点击「生成行程」</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {plan.warnings.length > 0 && (
        <div className="space-y-1 rounded-xl bg-amber/5 p-3">
          <div className="mb-1 text-xs font-medium text-amber">提示</div>
          {plan.warnings.map((w, i) => (
            <div key={i} className="flex items-start gap-1 text-xs">
              <span
                className={
                  w.level === 'danger'
                    ? 'text-red-500'
                    : w.level === 'warning'
                      ? 'text-amber'
                      : 'text-black/50'
                }
              >
                {w.level === 'danger' ? '⚠' : w.level === 'warning' ? '!' : '·'}
              </span>
              <span className="text-ink/70">{w.message}</span>
            </div>
          ))}
        </div>
      )}

      {plan.days.map((day, di) => {
        const color = DAY_COLORS[di % DAY_COLORS.length];
        return (
          <div key={day.date}>
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full" style={{ background: color }} />
                <span className="font-medium">{day.date}</span>
              </div>
              <span className="text-xs text-black/50">
                {day.stops.length} 站 · {fmtMoney(day.totalCost)} · {fmtKm(day.totalDistanceKm)}
              </span>
            </div>
            <DragSortableList dayIndex={di} byId={byId} />
          </div>
        );
      })}

      {/* 需求：在行程反馈下生成图例（图标） */}
      {legend.length > 0 && (
        <div className="rounded-xl bg-cream p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-ink">地图线路图例</span>
            <span className="text-[11px] text-black/40">
              真实路网 {stats.real} 段
              {stats.est > 0 && <span className="text-amber"> · 估算 {stats.est} 段</span>}
            </span>
          </div>
          <div className="flex flex-wrap gap-x-3 gap-y-1.5">
            {legend.map((l) => (
              <span key={l.label} className="flex items-center gap-1.5 text-[11px] text-ink/70">
                <span className="h-1.5 w-5 rounded-full" style={{ background: l.color }} />
                {l.label}
              </span>
            ))}
          </div>
          <div className="mt-2 text-[11px] text-black/35">
            线色用于区分交通方式与线路，非官方标志色。
          </div>
        </div>
      )}

      {/* 指令 6(2)(4)：通勤线路免责声明 */}
      <div
        className={`rounded-xl px-3 py-2 text-center text-[11px] ${
          hasEstimate ? 'bg-red-50 font-medium text-red-600' : 'bg-black/5 text-black/45'
        }`}
      >
        {hasEstimate
          ? '无任何参考价值！！！'
          : '此通勤方式和线路，仅供参考，请以导航APP推荐为最佳选择'}
      </div>
    </div>
  );
}
