import { usePlanStore } from '../../store/usePlanStore';
import { PlanParamsPanel } from './PlanParamsPanel';
import { Timeline } from './Timeline';
import { ErrorBoundary } from '../layout/ErrorBoundary';
import { BudgetBar } from './BudgetBar';
import { SavingsSuggestions } from './SavingsSuggestions';
import { BudgetBreakdown } from './BudgetBreakdown';
import { ImportExport } from './ImportExport';

export function PlanView() {
  const plan = usePlanStore((s) => s.plan);
  return (
    <div className="space-y-4">
      <PlanParamsPanel />
      {plan && (
        <>
          {/* 行程反馈放最前面：这是点「生成行程」后最该先看到的内容，
              放在预算卡片后面容易被忽略（用户反馈过"反馈卡片里没有交通方式"） */}
          <ErrorBoundary label="行程反馈">
            <Timeline plan={plan} />
          </ErrorBoundary>
          <BudgetBar />
          <SavingsSuggestions plan={plan} />
          <BudgetBreakdown plan={plan} />
          <ImportExport />
        </>
      )}
    </div>
  );
}
