import { usePlanStore } from '../../store/usePlanStore';

const PRESETS = [
  { label: '人均 200', total: 1000, people: 5 },
  { label: '人均 100', total: 400, people: 4 },
  { label: '情侣套餐', total: 300, people: 2 },
  { label: '单人轻食', total: 150, people: 1 },
];

export function BudgetPresets() {
  const setParams = usePlanStore((s) => s.setParams);
  return (
    <div className="flex flex-wrap gap-2">
      {PRESETS.map((p) => (
        <button
          key={p.label}
          onClick={() => setParams({ totalBudget: p.total, peopleCount: p.people })}
          className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs text-ink/70 transition-colors hover:border-brand hover:text-brand"
        >
          {p.label}
        </button>
      ))}
    </div>
  );
}
