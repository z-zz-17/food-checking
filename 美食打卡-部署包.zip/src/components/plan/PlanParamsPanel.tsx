import { useEffect, useMemo, useRef, useState } from 'react';
import type { PlanParams, Restaurant, TravelMode } from '../../types';
import type { FeasibilityAction, FeasibilityReport, RouteLeg } from '../../types/planning';
import { usePlanStore } from '../../store/usePlanStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { assessFeasibility } from '../../algorithms/feasibility';
import { guessCity } from '../../algorithms/intercity';
import { getRoutingService } from '../../services/routing';
import { buildDefaultRoute, clearRouteCache, fetchLegsInOrder } from '../../algorithms/routePlan';
import { buildPlan, makeEstimateMatrix, ORIGIN_KEY, type LegMatrix } from '../../algorithms/planner';
import { MODE_LABEL } from '../../algorithms/travel';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { BudgetPresets } from './BudgetPresets';
import { FeasibilityDialog } from './FeasibilityDialog';
import { OrderEditor, type OrderItem } from './OrderEditor';
import { fmtMoney } from '../../utils/format';
import { haversineKm } from '../../algorithms/coords';
import { cityByCoords } from '../../algorithms/cityLookup';

/** 同城判定阈值（与 routePlan / feasibility 保持一致） */
const SAME_CITY_KM = 80;

/** 出发地的城市名：优先按坐标，其次按文字解析 */
function originCityName(origin: { lat: number; lng: number; label: string }): string {
  return cityByCoords(origin.lat, origin.lng) ?? guessCity(origin.label) ?? '出发地';
}

/**
 * 解析一家餐厅所属城市。**优先按坐标判定**，其次才看地址文字。
 *
 * 为什么坐标优先（两处真实缺陷，都已实测复现）：
 *   ① 只按地址文字解析会「少算」：早期实现是「离出发点近就归为出发点城市，远就一律叫异地」。
 *      出发点 + 两家分别远在不同城市的店，若地址里都没写城市（靠地图点选或 POI 吸附
 *      添加的店常常只有店名），就会被并成同一个「异地」→ 不同城数 M 被少算
 *      → N=3 时（阈值 3）判不出「三者全在不同城市」，本该不合理却被放行。
 *   ② 只按地址文字解析还会「多算」：guessCity 是子串匹配，
 *      「南京东路100号」在上海，却会被匹配成「南京」（实测），把同城误判成跨城。
 *   坐标既是路线计算真正使用的数据，也没有子串歧义，所以以它为准。
 */
function cityOf(r: Restaurant, origin: { lat: number; lng: number; label: string }): string {
  const byCoords = cityByCoords(r.lat, r.lng);
  if (byCoords) return byCoords;
  // 坐标超出城市表 150km 才退回地址文字
  const byAddress = guessCity(r.address);
  if (byAddress) return byAddress;
  // 最后兜底：紧邻出发点就算同城，否则算独立的「异地」
  return haversineKm(origin, r) <= SAME_CITY_KM ? originCityName(origin) : '异地';
}

const MODE_OPTIONS: { value: TravelMode; label: string }[] = [
  { value: 'walk', label: '步行' },
  { value: 'bike', label: '骑行' },
  { value: 'drive', label: '驾车' },
  { value: 'transit', label: '公共交通（含地铁）' },
];

/** 取当前最新的勾选餐厅（按 store 顺序，稳定） */
function currentSelection(): Restaurant[] {
  const s = useRestaurantStore.getState();
  return s.restaurants.filter((r) => s.selectedIds.includes(r.id));
}

/** 把 RouteLeg 数组按「上一站 → 本站」的键做成表，便于任意顺序复用 */
function keyedLegs(order: string[], legs: RouteLeg[]): Map<string, RouteLeg> {
  const m = new Map<string, RouteLeg>();
  let prev = ORIGIN_KEY;
  order.forEach((id, i) => {
    const l = legs[i];
    if (l) m.set(`${prev}>${id}`, l);
    prev = id;
  });
  return m;
}

/** 一段通勤的展示文案：优先分段明细，退化为交通方式 */
function legText(leg: RouteLeg | undefined): string {
  if (!leg) return '待计算';
  if (leg.segments && leg.segments.length > 0) {
    return leg.segments.map((s) => `${s.label} ${Math.round(s.minutes)}分钟`).join(' → ');
  }
  return `${MODE_LABEL[leg.mode]} ${Math.round(leg.minutes)}分钟`;
}

export function PlanParamsPanel() {
  const params = usePlanStore((s) => s.params);
  const setParams = usePlanStore((s) => s.setParams);
  const setPlan = usePlanStore((s) => s.setPlan);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const selectedIds = useRestaurantStore((s) => s.selectedIds);
  const removeRestaurant = useRestaurantStore((s) => s.removeRestaurant);

  const [generating, setGenerating] = useState(false);
  const [report, setReport] = useState<FeasibilityReport | null>(null);
  /** 生成过程的可视化状态（避免"点了没反应"这种无从判断的情况） */
  const [progress, setProgress] = useState('');
  const [error, setError] = useState('');
  /** 当前展示顺序（默认=通勤最少，可拖拽改） */
  const [order, setOrder] = useState<string[]>([]);
  /** 后台算出的默认顺序，用于「是否已自定义」与恢复 */
  const [defaultIds, setDefaultIds] = useState<string[]>([]);
  /** 已取得的通勤（按 上一站>本站 键缓存），支持任意重排复用 */
  const [legs, setLegs] = useState<Map<string, RouteLeg>>(new Map());
  const [prefetching, setPrefetching] = useState(false);
  const prefetchToken = useRef(0);
  /** 上一次的「勾选签名」：只有它变了才重置打卡顺序，纯参数变化要保留用户的自定义顺序 */
  const lastSelectionRef = useRef('');
  /** 出发地「文字 → 坐标」的定位状态 */
  const [originStatus, setOriginStatus] = useState<'idle' | 'locating' | 'ok' | 'fail'>('idle');
  const originTimer = useRef<number | null>(null);

  /**
   * 把出发地文字解析成坐标 —— 这是本轮最关键的一处修复。
   *
   * 过去出发地输入框**只改文字、从不改坐标**，于是「广州 → 陈麻婆豆腐（成都）」
   * 实际算的是「成都春熙路 → 陈麻婆豆腐」，真实驾车 7 分钟被当成了跨城通勤时间。
   * （已用真实数据复现：文字=广州、坐标=成都时，广州→陈麻婆豆腐只有 3.2km。）
   */
  const locateOrigin = async (text: string, silent = false) => {
    const label = text.trim();
    if (label.length < 2) return;
    if (!silent) setOriginStatus('locating');
    try {
      const pos = await getRoutingService().geocode(label);
      if (!pos) {
        setOriginStatus('fail');
        return;
      }
      const cur = usePlanStore.getState().params.origin;
      // 与现有坐标相差不足 3km 就认为一致，避免无意义地刷新路线缓存
      if (haversineKm(cur, pos) > 3) {
        usePlanStore.getState().setParams({ origin: { lat: pos.lat, lng: pos.lng, label } });
      }
      setOriginStatus('ok');
    } catch {
      setOriginStatus('fail');
    }
  };

  /** 出发地文字一变就延迟定位（防抖 700ms，避免每敲一个字就调一次接口） */
  const handleOriginText = (text: string) => {
    set({ origin: { ...params.origin, label: text } });
    setOriginStatus('idle');
    if (originTimer.current !== null) window.clearTimeout(originTimer.current);
    if (text.trim().length < 2) return;
    originTimer.current = window.setTimeout(() => void locateOrigin(text), 700);
  };

  // 打开页面时自愈：老数据里可能存着「文字是广州、坐标是成都」这种不一致状态
  useEffect(() => {
    const o = usePlanStore.getState().params.origin;
    void locateOrigin(o.label, true);
    // 仅在挂载时执行一次
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selected = useMemo(
    () => restaurants.filter((r) => selectedIds.includes(r.id)),
    [restaurants, selectedIds],
  );

  // ---------- 两类签名：影响路线的 / 只影响显示的 ----------
  // 只把「真的会改变通勤数据」的要素放进 routeKey，
  // 否则拖动滑杆会不停清缓存并重新调用高德接口（配额会被烧掉）。
  const routeKey = [
    selected.map((r) => r.id).join(','),
    params.origin.lat,
    params.origin.lng,
    params.travelMode,
    params.intercity ?? '',
  ].join('|');
  const paramKey = [
    routeKey,
    params.startTime,
    params.endTime,
    params.days,
    params.totalBudget,
    params.peopleCount,
    params.maxStopsPerDay ?? 5,
  ].join('|');

  /**
   * 打卡顺序签名（单独使用，**绝不能并进 paramKey**）。
   *
   * 这里踩过一个很隐蔽的坑：曾经把 order 放进 paramKey，
   * 而 paramKey 会触发下面「重启路线规划」的 effect，那个 effect 内部会
   * `setOrder(...)` 把顺序重置回默认值 —— 于是用户刚拖好的顺序立刻被覆盖，
   * 表现就是「拖拽无法更换顺序」；更糟的是默认顺序与勾选顺序不同时，
   * 两边互相 setOrder 会形成反复重算的死循环。
   * 顺序变化只该清空下方反馈，不该重算路线、更不该重置顺序。
   */
  /**
   * 实际生效的打卡顺序 —— **必须与「当前勾选」严格对齐**：
   * 剔除已取消勾选的、补齐新勾选进来的。
   *
   * 为什么不能直接用 order：一旦顺序里残留了不属于当前勾选的旧 id
   * （换过勾选、后台重算还没回来时很容易发生），生成时会把顺序里的 id
   * 全部过滤掉 → ordered 为空 → 旧代码直接静默 return，
   * 页面毫无反应，只剩时间轴的空状态文案，表现为
   * 「提示未勾选餐厅、无法生成」。这里从根上杜绝这种不一致。
   */
  const effectiveOrder = useMemo(() => {
    const now = selected.map((r) => r.id);
    const kept = order.filter((id) => now.includes(id));
    const missing = now.filter((id) => !kept.includes(id));
    return [...kept, ...missing];
  }, [order, selected]);

  const orderKey = effectiveOrder.join(',');

  /**
   * 反馈清空签名：**生成按钮以上的所有要素**都要包含，
   * 包括「出发地文字」与「打卡顺序」——
   * 用户明确要求：更改出发点时，上一轮生成行程的反馈必须清空。
   * （出发地文字不进 routeKey，避免每敲一个字就去调接口；但必须进这里。）
   */
  const feedbackKey = [paramKey, orderKey, params.origin.label].join('|');

  /** 是否已过首次渲染：挂载本身不算"要素变化" */
  const mountedRef = useRef(false);

  /**
   * 指令 8：生成按钮上方的**任何**要素变化 → 清空下方反馈，需重新点击生成。
   *
   * 注意首帧跳过：挂载不等于"要素变化"。
   * 以前这个 effect 在挂载时也会执行 setPlan(null)，
   * 于是每次切回「规划」标签页（组件重新挂载）都会把上一轮生成的行程清掉，
   * 表现就是"切一下标签页，地图上的路线就没了"。
   */
  useEffect(() => {
    if (!mountedRef.current) {
      mountedRef.current = true;
      return;
    }
    setPlan(null);
    setReport(null);
  }, [feedbackKey, setPlan]);

  /**
   * ① 影响「通勤数据本身」的要素变了（勾选 / 出发点坐标 / 交通方式 / 城际方式）
   *    → 已取到的通勤与路线缓存全部作废，必须清掉。
   */
  useEffect(() => {
    clearRouteCache();
    setLegs(new Map());
    setDefaultIds([]);
  }, [routeKey]);

  /**
   * ② 「生成行程」按钮**以上的任何内容**改变 → 重启路线规划程序（后台静默重算默认顺序）。
   *
   * 这里刻意不再清路线缓存：预算 / 人数 / 滑杆 / 时间窗 这类纯展示要素
   * 并不会改变通勤数据，重算会全部命中缓存、毫秒级返回，不会额外消耗高德配额；
   * 只有当 ① 已经清过缓存时，这里才真的去取新数据。
   */
  useEffect(() => {
    setReport(null);

    const list = currentSelection();
    if (list.length === 0) {
      setOrder([]);
      lastSelectionRef.current = '';
      return;
    }

    // 只有「勾选本身变了」才把顺序重置为新算出的默认顺序；
    // 纯参数变化（时间 / 天数 / 预算 / 滑杆）必须保留用户已经拖好的自定义顺序，
    // 否则用户拖完顺序、随手动一下滑杆就会被打回默认，看起来又像"拖拽没生效"。
    const selectionSignature = list.map((r) => r.id).join(',');
    const selectionChanged = selectionSignature !== lastSelectionRef.current;
    lastSelectionRef.current = selectionSignature;
    if (selectionChanged) setOrder(list.map((r) => r.id));

    const token = prefetchToken.current + 1;
    prefetchToken.current = token;
    setPrefetching(true);
    void buildDefaultRoute(list, usePlanStore.getState().params)
      .then((res) => {
        if (prefetchToken.current !== token) return; // 期间又变了，丢弃本次结果
        setDefaultIds(res.order);
        if (selectionChanged) setOrder(res.order);
        // 通勤数据按「上一站>本站」合并，不整表替换：
        // 自定义顺序里已经取到的段不会被冲掉
        setLegs((prev) => new Map([...prev, ...keyedLegs(res.order, res.legs)]));
      })
      .catch(() => {
        if (prefetchToken.current === token) setDefaultIds([]);
      })
      .finally(() => {
        if (prefetchToken.current === token) setPrefetching(false);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paramKey]);

  const orderItems: OrderItem[] = useMemo(
    () =>
      effectiveOrder.map((id, i) => {
        const r = selected.find((x) => x.id === id);
        const from = i === 0 ? ORIGIN_KEY : effectiveOrder[i - 1];
        const leg = legs.get(`${from}>${id}`);
        return {
          id,
          name: r?.name ?? id,
          emoji: r?.emoji ?? '🍴',
          legMinutes: leg ? Math.round(leg.minutes) : 0,
          legKm: leg?.km ?? 0,
          legLabel: legText(leg),
          estimated: leg?.estimated ?? true,
        };
      }),
    [order, selected, legs],
  );

  /**
   * 生成：先取该顺序上的通勤（命中缓存的段不会重复请求），再判定合理性，最后排时间表。
   *
   * force=true 表示用户在弹窗里点了「仍然生成」：跳过合理性拦截直接出方案。
   * 这个开关是必须的 —— 按第 13 条规则，「出发地与唯一餐厅不同城」永远会被判不合理，
   * 若没有强制出口，这类行程（例如人在广州、想吃成都的店）就永远生成不出来。
   */
  const generate = async (force = false) => {
    const p = usePlanStore.getState().params;
    const list = currentSelection();
    if (list.length === 0) return;

    // 用「与勾选对齐后的顺序」；再兜一层，确保不会因为顺序缺失而漏掉任何一家勾选的餐厅
    const baseIds = effectiveOrder.length > 0 ? effectiveOrder : list.map((r) => r.id);
    const ordered = baseIds
      .map((id) => list.find((r) => r.id === id))
      .filter((r): r is Restaurant => !!r);
    for (const r of list) {
      if (!ordered.some((x) => x.id === r.id)) ordered.push(r);
    }
    if (ordered.length === 0) {
      // 绝不静默返回：以前这里直接 return，界面毫无反应，用户只能看到"没生成"
      setError(
        `没有可规划的餐厅（勾选 ${list.length} 家、顺序 ${baseIds.length} 项）——请重新勾选后再试`,
      );
      return;
    }

    setError('');
    setReport(null);
    setGenerating(true);
    /** 硬超时：任何一段卡住都不能让按钮永远停在「规划中…」 */
    const LEG_FETCH_TIMEOUT_MS = 20000;
    setProgress(`正在取通勤数据（${ordered.length} 段）…`);
    try {
      const byId = new Map(list.map((r) => [r.id, r]));
      const fetched = await Promise.race([
        fetchLegsInOrder(
          ordered.map((r) => r.id),
          byId,
          p,
        ),
        new Promise<RouteLeg[]>((resolve) => setTimeout(() => resolve([]), LEG_FETCH_TIMEOUT_MS)),
      ]).catch((e: unknown) => {
        setError(`取通勤数据失败：${e instanceof Error ? e.message : String(e)}`);
        return [] as RouteLeg[];
      });

      const merged = new Map(legs);
      let prev = ORIGIN_KEY;
      ordered.forEach((r, i) => {
        const l = fetched[i];
        if (l) merged.set(`${prev}>${r.id}`, l);
        prev = r.id;
      });
      setLegs(merged);

      // 指令 13：用真实通勤时间做合理性判定
      const legMinutes: number[] = [];
      const legKm: number[] = [];
      let from = ORIGIN_KEY;
      for (const r of ordered) {
        const l = merged.get(`${from}>${r.id}`);
        legMinutes.push(l ? l.minutes : 0);
        legKm.push(l ? l.km : 0);
        from = r.id;
      }

      const rep = assessFeasibility({
        restaurants: ordered.map((r) => ({
          id: r.id,
          name: r.name,
          lat: r.lat,
          lng: r.lng,
          stayMinutes: r.stayMinutes,
          hours: r.hours,
          priority: r.priority,
          avgPrice: r.avgPrice,
          city: cityOf(r, p.origin),
        })),
        origin: p.origin,
        params: p,
        legMinutes,
        legKm,
      });

      // 指令 14：不合理 → 弹窗并且不执行规划（除非用户明确要求强制生成）
      if (!rep.ok && !force) {
        setReport(rep);
        return;
      }

      const places = new Map(list.map((r) => [r.id, { lat: r.lat, lng: r.lng }]));
      const est = makeEstimateMatrix(places, p);
      const matrix: LegMatrix = {
        source: merged.size > 0 ? 'amap' : 'estimate',
        minutes: (a, b) => merged.get(`${a}>${b}`)?.minutes ?? est.minutes(a, b),
        km: (a, b) => merged.get(`${a}>${b}`)?.km ?? est.km(a, b),
        leg: (a, b) => merged.get(`${a}>${b}`),
      };
      setProgress('正在排时间表…');
      setPlan(buildPlan(ordered, p, matrix));
      setReport(null);
    } catch (e: unknown) {
      // 以前这里没有 catch：一旦中途抛错，按钮会恢复但界面毫无提示，
      // 表现就是「点了生成行程没有任何反应」。现在把原因直接显示出来。
      setError(`生成行程失败：${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setGenerating(false);
      setProgress('');
    }
  };

  /** 应用弹窗里的某条建议 → 立刻重新判定；合格就直接出方案 */
  const applyAction = async (action: FeasibilityAction) => {
    if (action.kind === 'removeRestaurant' && action.restaurantId) {
      removeRestaurant(action.restaurantId);
      setReport(null);
      return; // 移除会改变 routeKey，后台会自己重新预取
    }
    if (action.patch) {
      usePlanStore.getState().setParams(action.patch);
    }
    setReport(null);
    // 参数变化后由 routeKey/paramKey 的 effect 接管：清反馈 + 重新预取
  };

  const set = (patch: Partial<PlanParams>) => setParams(patch);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="text-sm font-medium text-ink">出发地</div>
        <Input
          value={params.origin.label}
          onChange={(e) => handleOriginText(e.target.value)}
          placeholder="出发地（写城市或地点，如：广州北京路）"
        />
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px]">
          <span
            className={
              originStatus === 'fail'
                ? 'text-amber'
                : originStatus === 'ok'
                  ? 'text-mint'
                  : 'text-black/40'
            }
          >
            {originStatus === 'locating' && '正在按出发地文字定位…'}
            {originStatus === 'ok' &&
              `已定位 ${params.origin.lat.toFixed(4)}, ${params.origin.lng.toFixed(4)}（路线从这里起算）`}
            {originStatus === 'fail' &&
              '没能识别这个出发地 → 仍在用上一次的坐标，请写得更具体（如「广州北京路」）'}
            {originStatus === 'idle' &&
              `当前坐标 ${params.origin.lat.toFixed(4)}, ${params.origin.lng.toFixed(4)}`}
          </span>
          <button
            type="button"
            onClick={() => void locateOrigin(params.origin.label)}
            className="text-brand hover:underline"
          >
            按文字重新定位
          </button>
        </div>
      </div>

      {/* 指令 12：出发时间与可用时段已合并为 开始时间 / 结束时间 */}
      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">开始时间</div>
          <Input
            type="time"
            value={params.startTime}
            onChange={(e) => set({ startTime: e.target.value })}
          />
        </div>
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">结束时间</div>
          <Input
            type="time"
            value={params.endTime}
            onChange={(e) => set({ endTime: e.target.value })}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">规划天数</div>
          <Select value={params.days} onChange={(e) => set({ days: Number(e.target.value) })}>
            {[1, 2, 3, 4, 5, 6, 7].map((d) => (
              <option key={d} value={d}>
                {d} 天
              </option>
            ))}
          </Select>
        </div>
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">交通方式</div>
          <Select
            value={params.travelMode}
            onChange={(e) => set({ travelMode: e.target.value as TravelMode })}
          >
            {MODE_OPTIONS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </Select>
        </div>
      </div>

      {/* 城际交通只在「检测到跨城」时才出现：出发地城市与任一餐厅城市不同即算跨城。
          检测只用到地址解析结果，不消耗任何接口调用。 */}
      {selected.length > 0 &&
        selected.some((r) => cityOf(r, params.origin) !== originCityName(params.origin)) && (
          <div className="space-y-1">
            <div className="text-sm font-medium text-ink">城际交通（检测到跨城）</div>
            <Select
              value={params.intercity ?? 'none'}
              onChange={(e) => {
                const v = e.target.value;
                set({ intercity: v === 'none' ? null : (v as 'rail' | 'flight') });
              }}
            >
              <option value="none">同城（不跨城）</option>
              <option value="rail">高铁 / 动车</option>
              <option value="flight">飞机</option>
            </Select>
            <div className="text-[11px] text-black/40">
              高德无城际公交/地铁数据时按估算模型计算；两岸只能航空。
            </div>
          </div>
        )}

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">总预算</div>
          <Input
            type="number"
            value={params.totalBudget}
            onChange={(e) => set({ totalBudget: Number(e.target.value) })}
          />
        </div>
        <div className="space-y-1">
          <div className="text-sm font-medium text-ink">同行人数</div>
          <Input
            type="number"
            min={1}
            value={params.peopleCount}
            onChange={(e) => set({ peopleCount: Number(e.target.value) })}
          />
        </div>
      </div>

      <BudgetPresets />

      {/* 每天最多几站：用**数轴**明确点选（替代原来模糊的"少走路 ↔ 多打卡"滑杆）。
          「严格守时 ↔ 灵活」滑杆已移除，超出每日时间窗的宽容度固定为 60 分钟。 */}
      <div className="space-y-2 rounded-xl bg-cream p-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-ink">每天最多几站</span>
          <span className="text-xs font-medium text-brand">
            {params.maxStopsPerDay ?? 5} 站 / 天
          </span>
        </div>

        <div className="relative pt-1">
          <div className="absolute left-3 right-3 top-[26px] h-px bg-black/15" />
          <div className="relative flex items-start justify-between">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => {
              const active = n === (params.maxStopsPerDay ?? 5);
              return (
                <button
                  key={n}
                  type="button"
                  aria-label={`每天最多 ${n} 站`}
                  aria-pressed={active}
                  onClick={() => set({ maxStopsPerDay: n })}
                  className="flex w-6 flex-col items-center gap-1"
                >
                  <span
                    className={`text-xs ${active ? 'font-medium text-brand' : 'text-black/40'}`}
                  >
                    {n}
                  </span>
                  <span
                    className={`rounded-full transition-all ${
                      active ? 'h-3 w-3 bg-brand' : 'h-1.5 w-1.5 bg-black/25'
                    }`}
                  />
                </button>
              );
            })}
          </div>
        </div>

        <div className="text-[11px] text-black/40">
          超过这个数量就顺延到次日；天数用尽时会明确提示哪几家没排进去。
        </div>
      </div>

      {/* 指令 2：顺序定制 */}
      {selected.length > 0 && (
        <OrderEditor
          items={orderItems}
          defaultIds={defaultIds}
          loading={prefetching}
          onChange={setOrder}
          onReset={() => setOrder(defaultIds.length > 0 ? defaultIds : order)}
        />
      )}

      <div className="rounded-xl bg-black/5 px-3 py-2 text-xs text-black/50">
        已勾选 <span className="font-medium text-brand">{selected.length}</span> 家餐厅
        {selected.length > 0 && (
          <span>
            ，预估 {fmtMoney(selected.reduce((s, r) => s + r.avgPrice * params.peopleCount, 0))}
          </span>
        )}
      </div>

      {progress !== '' && (
        <div className="rounded-xl bg-brand-light px-3 py-2 text-xs text-brand">{progress}</div>
      )}
      {error !== '' && (
        <div className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600">
          {error}（把这一行发给助手即可定位）
        </div>
      )}
      {/* 弹窗之外再给一条常驻提示：即使弹窗因故没弹出来，也能看到"为什么没生成" */}
      {report && !report.ok && (
        <div className="rounded-xl bg-red-50 px-3 py-2 text-xs text-red-600">
          判定为不合理，已按规则不生成行程（
          {report.issues
            .filter((i) => i.level === 'blocker')
            .map((i) => i.code)
            .join(' / ')}
          ）。
          {/* 把判定依据直接摊开，避免"为什么被拦"变成猜谜 */}
          <div className="mt-1 text-red-500/90">
            依据：地址 {report.stats.addressCount} 个 · 不同城 {report.stats.distinctCityCount} 个（阈值{' '}
            {report.stats.crossCityThreshold}）· 城市：
            {report.stats.cities.length > 0 ? report.stats.cities.join('、') : '（未识别）'} · 需要{' '}
            {Math.round(report.stats.requiredMinutes)} 分钟 / 可用{' '}
            {Math.round(report.stats.availableMinutes)} 分钟
          </div>
          <div className="mt-1">
            弹窗里可查看原因并一键调整，或点「仍然生成」强制出方案。
          </div>
        </div>
      )}

      <Button
        className="w-full"
        onClick={() => void generate()}
        disabled={generating || selected.length === 0}
      >
        {generating ? '规划中…' : '生成行程'}
      </Button>

      {report && (
        <FeasibilityDialog
          report={report}
          onApply={(a) => void applyAction(a)}
          onClose={() => setReport(null)}
          onForcePlan={() => {
            setReport(null);
            void generate(true);
          }}
        />
      )}
    </div>
  );
}
