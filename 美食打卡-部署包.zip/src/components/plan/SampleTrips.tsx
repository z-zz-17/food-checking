import { useRestaurantStore } from '../../store/useRestaurantStore';
import { usePlanStore } from '../../store/usePlanStore';
import { SAMPLE_TRIPS } from '../../data/sampleTrips';
import { buildPlan } from '../../algorithms/planner';
import { defaultOrder } from '../../algorithms/routePlan';
import type { Restaurant } from '../../types';

export function SampleTrips() {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const addRestaurant = useRestaurantStore((s) => s.addRestaurant);
  const selectAll = useRestaurantStore((s) => s.selectAll);
  const params = usePlanStore((s) => s.params);
  const setParams = usePlanStore((s) => s.setParams);
  const setPlan = usePlanStore((s) => s.setPlan);

  const loadSample = (index: number) => {
    const sample = SAMPLE_TRIPS[index];
    const created: Restaurant[] = sample.restaurants.map((r) =>
      addRestaurant({ ...r, note: sample.title }),
    );
    selectAll([...restaurants.map((r) => r.id), ...created.map((r) => r.id)]);
    if (created.length === 0) return;

    // 起点必须跟着示例行程的城市走：否则会出现
    //「起点在成都、餐厅在上海、步行永远到不了」→ 整份行程一家都排不进去
    const origin = {
      lat: created.reduce((s, r) => s + r.lat, 0) / created.length,
      lng: created.reduce((s, r) => s + r.lng, 0) / created.length,
      label: `${sample.city}（示例行程起点）`,
    };
    setParams({ origin });

    setTimeout(() => {
      // 样例行程不调用高德（零配额），但顺序仍要用本地估算的「通勤最少」算一遍 ——
  // 因为 planner 现在**完全按传入顺序排、不再自己重排**（见 planner 里那段说明）。
  const sampleParams = { ...params, origin };
  const orderedSample = defaultOrder(created, sampleParams)
    .map((id) => created.find((r) => r.id === id))
    .filter((r): r is (typeof created)[number] => r !== undefined);
  const plan = buildPlan(orderedSample.length > 0 ? orderedSample : created, sampleParams);
      setPlan({ ...plan, title: sample.title });
    }, 0);
  };

  return (
    <div className="space-y-2">
      <div className="text-xs font-medium text-black/50">示例行程（点一下就体验完整效果）</div>
      {SAMPLE_TRIPS.map((t, i) => (
        <button
          key={t.id}
          onClick={() => loadSample(i)}
          className="flex w-full items-center gap-3 rounded-xl bg-white p-3 text-left shadow-soft transition-transform hover:-translate-y-0.5"
        >
          <span className="text-2xl">{t.emoji}</span>
          <span className="flex-1">
            <span className="block font-medium">{t.title}</span>
            <span className="block text-xs text-black/50">{t.description}</span>
          </span>
          <span className="text-xs text-black/40">{t.city}</span>
        </button>
      ))}
    </div>
  );
}
