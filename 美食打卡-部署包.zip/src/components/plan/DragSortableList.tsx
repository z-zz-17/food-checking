import { useState } from 'react';
import { usePlanStore } from '../../store/usePlanStore';
import { useMapStore } from '../../store/useMapStore';
import { useUiStore } from '../../store/useUiStore';
import { reorderDay } from '../../algorithms/reorder';
import { segmentColor } from '../../data/lineColors';
import { DAY_COLORS } from '../../config/palette';
import { fmtKm, fmtMinutes } from '../../utils/format';
import { stripFare } from '../../utils/text';
import type { Restaurant } from '../../types';

export function DragSortableList({
  dayIndex,
  byId,
}: {
  dayIndex: number;
  byId: Map<string, Restaurant>;
}) {
  const plan = usePlanStore((s) => s.plan);
  const setPlan = usePlanStore((s) => s.setPlan);
  const params = usePlanStore((s) => s.params);
  const setHovered = useMapStore((s) => s.setHovered);
  const focusRestaurant = useMapStore((s) => s.focusRestaurant);
  const openCheckIn = useUiStore((s) => s.openCheckIn);
  const checkIns = usePlanStore((s) => s.checkIns);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  if (!plan) return null;
  const day = plan.days[dayIndex];
  if (!day) return null;

  const color = DAY_COLORS[dayIndex % DAY_COLORS.length];
  const stopIds = day.stops.map((s) => s.restaurantId);

  const handleDrop = (targetId: string) => {
    if (!dragId || dragId === targetId) {
      setDragId(null);
      setOverId(null);
      return;
    }
    const from = stopIds.indexOf(dragId);
    const to = stopIds.indexOf(targetId);
    if (from < 0 || to < 0) return;
    const next = [...stopIds];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    const { plan: newPlan } = reorderDay(plan, dayIndex, next, byId, params);
    setPlan(newPlan);
    setDragId(null);
    setOverId(null);
  };

  return (
    <div className="space-y-2">
      {day.stops.map((stop, index) => {
        const r = byId.get(stop.restaurantId);
        if (!r) return null;
        const leg = stop.travelFromPrev;
        const isDragging = dragId === stop.restaurantId;
        const isOver = overId === stop.restaurantId;
        const checked = !!checkIns[stop.restaurantId];

        // 上一站：第 1 站是出发点，其余是上一家餐厅
        const prevStop = index > 0 ? day.stops[index - 1] : null;
        const fromLabel = prevStop
          ? (byId.get(prevStop.restaurantId)?.name ?? '上一站')
          : params.origin.label;

        return (
          <div
            key={stop.restaurantId}
            draggable
            onDragStart={() => setDragId(stop.restaurantId)}
            onDragOver={(e) => {
              e.preventDefault();
              setOverId(stop.restaurantId);
            }}
            onDrop={() => handleDrop(stop.restaurantId)}
            onDragEnd={() => {
              setDragId(null);
              setOverId(null);
            }}
            onMouseEnter={() => setHovered(stop.restaurantId)}
            onMouseLeave={() => setHovered(null)}
            onClick={() => focusRestaurant(stop.restaurantId)}
            className={`cursor-grab rounded-xl bg-white p-3 shadow-soft transition-all active:cursor-grabbing ${
              isDragging ? 'opacity-50' : ''
            } ${isOver ? 'ring-2 ring-brand/40' : ''}`}
          >
            <div className="flex items-center gap-2">
              <span
                className="flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold text-white"
                style={{ background: color }}
              >
                {stop.order}
              </span>
              <span className="flex-1 truncate text-sm font-medium">
                {r.emoji ?? '🍴'} {r.name}
              </span>
              {checked && <span className="text-xs font-medium text-mint">✓</span>}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  openCheckIn(stop.restaurantId);
                }}
                className="rounded-lg bg-brand-light px-2 py-0.5 text-xs text-brand"
              >
                打卡
              </button>
              <span className="text-xs text-black/40">⋮⋮</span>
            </div>

            {/* 单段交通时**不再**单独渲染"总耗时行" —— 它和下面那条分段标签说的是同一件事，
                用户反馈过"不同城的交通方式和时间显示两次"。
                多段（公共交通换乘）时才保留「共 X 分钟 · Y km」汇总行，那时它才有意义。 */}
            {(leg.segments?.length ?? 0) > 1 && (
              <div className="mt-1 flex items-center justify-end text-xs text-black/50">
                <span>
                  共 {fmtMinutes(leg.minutes)} · {fmtKm(leg.km)}
                </span>
              </div>
            )}

            {/* 需求：每张卡片显示「出发点 → 餐厅1（或 餐厅1 → 餐厅2）」
                + 具体交通方式（含换乘）+ 所需时间。
                注意：这一段**不再**用 minutes>0 去隐藏，否则一旦某段没数据，
                整张卡片就会丢掉「从哪到哪 + 交通方式」这个必需格式。 */}
            <div className="mt-1 border-t border-black/5 pt-1.5">
                <div className="flex items-center gap-1 text-[11px]">
                  <span className="max-w-[44%] truncate font-medium text-ink/75">
                    {fromLabel}
                  </span>
                  <span className="text-black/30">→</span>
                  <span className="max-w-[44%] truncate font-medium text-ink/75">{r.name}</span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-1 gap-y-1 text-[11px]">
                  {leg.segments && leg.segments.length > 0 ? (
                    leg.segments.map((sg, j) => {
                      const c = sg.color ?? segmentColor(sg.kind, sg.label);
                      return (
                        <span key={`${sg.label}-${j}`} className="flex items-center gap-1">
                          {j > 0 && <span className="text-black/25">→</span>}
                          <span
                            className="flex items-center gap-1 rounded px-1.5 py-0.5"
                            style={{ background: `${c}1A`, color: c }}
                            title={sg.from && sg.to ? `${sg.from} → ${sg.to}` : undefined}
                          >
                            <span className="h-2 w-2 rounded-full" style={{ background: c }} />
                            {stripFare(sg.label)} {Math.round(sg.minutes)}分钟
                            {/* 单段时里程也要显示出来（此时没有"总耗时行"兜底）；
                                但标签里已经写了里程（如"高铁 · 里程约334.4km"）就不要重复。 */}
                            {!/(km|公里|里程)/i.test(sg.label) && (
                              <span className="opacity-70">· {fmtKm(sg.km ?? leg.km)}</span>
                            )}
                          </span>
                        </span>
                      );
                    })
                  ) : leg.minutes > 0 ? (
                    <span className="rounded bg-black/5 px-1.5 py-0.5 text-ink/70">
                      {fmtMinutes(leg.minutes)} · {fmtKm(leg.km)}
                    </span>
                  ) : (
                    <span className="rounded bg-amber/10 px-1.5 py-0.5 text-amber">
                      无通勤数据，请重新点「生成行程」
                    </span>
                  )}
                  {/* 城际摘要只在「分段里没有体现」时才补一条 ——
                      否则会和上面的分段标签重复显示一次
                      （用户实测反馈：不同城的交通方式和时间会显示两次） */}
                  {leg.intercitySummary && (leg.segments?.length ?? 0) === 0 && (
                    <span className="rounded bg-brand-light px-1.5 py-0.5 text-brand">
                      {stripFare(leg.intercitySummary)}
                    </span>
                  )}
                  {leg.estimated && <span className="text-amber">· 估算</span>}
                </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
