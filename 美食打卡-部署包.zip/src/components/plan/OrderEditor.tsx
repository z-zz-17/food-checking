import { useState } from 'react';
import { Button } from '../ui/Button';

export type OrderItem = {
  id: string;
  name: string;
  emoji: string;
  /** 上一站 → 这里 的通勤 */
  legMinutes: number;
  legKm: number;
  /** 该段通勤的展示文案，例如「步行 8分钟」或「地铁2号线 12分钟 → 步行 3分钟」 */
  legLabel: string;
  /** 该段是否含估算成分（含 → 反馈里要标注"仅供参考/无参考价值"） */
  estimated: boolean;
};

/**
 * 顺序定制（指令第 2 条）。
 *
 * 默认顺序由后台静默预取的路线规划给出（以「通勤时间最少」为原则）；
 * 这里只负责展示与拖拽换序，换序后由父组件按新顺序重排时间表。
 */
export function OrderEditor({
  items,
  defaultIds,
  loading,
  onChange,
  onReset,
}: {
  items: OrderItem[];
  /** 默认顺序（用于显示"是否已被改动"并提供恢复） */
  defaultIds: string[];
  loading: boolean;
  onChange: (ids: string[]) => void;
  onReset: () => void;
}) {
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  const ids = items.map((i) => i.id);
  const isDefault =
    ids.length === defaultIds.length && ids.every((id, i) => id === defaultIds[i]);

  const handleDrop = (targetId: string) => {
    if (!dragId || dragId === targetId) {
      setDragId(null);
      setOverId(null);
      return;
    }
    const next = [...ids];
    const from = next.indexOf(dragId);
    const to = next.indexOf(targetId);
    if (from < 0 || to < 0) return;
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    setDragId(null);
    setOverId(null);
    onChange(next);
  };

  if (items.length === 0) return null;

  return (
    <div className="space-y-2 rounded-xl bg-cream p-3">
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium text-ink">打卡顺序</div>
        <div className="flex items-center gap-2">
          <span className={`text-[11px] ${isDefault ? 'text-black/40' : 'text-brand'}`}>
            {isDefault ? '默认顺序（通勤最少）' : '已自定义'}
          </span>
          {!isDefault && (
            <Button size="sm" variant="ghost" onClick={onReset}>
              恢复默认
            </Button>
          )}
        </div>
      </div>

      {loading && (
        <div className="text-[11px] text-black/40">正在后台计算各段通勤时间…</div>
      )}

      <div className="space-y-1.5">
        {items.map((item, index) => {
          const isDragging = dragId === item.id;
          const isOver = overId === item.id;
          return (
            <div
              key={item.id}
              draggable
              onDragStart={() => setDragId(item.id)}
              onDragOver={(e) => {
                e.preventDefault();
                setOverId(item.id);
              }}
              onDrop={() => handleDrop(item.id)}
              onDragEnd={() => {
                setDragId(null);
                setOverId(null);
              }}
              className={`cursor-grab rounded-lg bg-white px-2.5 py-2 shadow-soft transition-all active:cursor-grabbing ${
                isDragging ? 'opacity-50' : ''
              } ${isOver ? 'ring-2 ring-brand/40' : ''}`}
            >
              <div className="flex items-center gap-2">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand text-[11px] font-bold text-white">
                  {index + 1}
                </span>
                <span className="min-w-0 flex-1 truncate text-xs font-medium">
                  {item.emoji} {item.name}
                </span>
                <span className="shrink-0 text-[11px] text-black/30">⋮⋮</span>
                {/* 拖拽在某些指针设备 / 触屏上不生效，这里补一对上下移动按钮兜底 */}
                <button
                  type="button"
                  disabled={index === 0}
                  title="上移"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (index === 0) return;
                    const next = [...ids];
                    [next[index - 1], next[index]] = [next[index], next[index - 1]];
                    onChange(next);
                  }}
                  className="shrink-0 rounded px-0.5 text-xs text-black/35 hover:text-brand disabled:opacity-25"
                >
                  ↑
                </button>
                <button
                  type="button"
                  disabled={index === items.length - 1}
                  title="下移"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (index >= ids.length - 1) return;
                    const next = [...ids];
                    [next[index + 1], next[index]] = [next[index], next[index + 1]];
                    onChange(next);
                  }}
                  className="shrink-0 rounded px-0.5 text-xs text-black/35 hover:text-brand disabled:opacity-25"
                >
                  ↓
                </button>
              </div>
              <div className="mt-1 pl-7 text-[11px] text-black/50">
                {item.legMinutes > 0 ? (
                  <>
                    {item.legLabel}
                    <span className="ml-1 text-black/35">
                      （{item.legMinutes} 分钟 / {item.legKm.toFixed(1)}km）
                    </span>
                    {item.estimated && <span className="ml-1 text-amber">· 估算</span>}
                  </>
                ) : (
                  '起点'
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[11px] text-black/35">
        拖动可调整顺序；生成行程时会按当前顺序重排时间表。
      </div>
    </div>
  );
}
