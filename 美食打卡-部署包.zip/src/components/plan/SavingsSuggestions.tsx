import { useMemo } from 'react';
import type { TripPlan } from '../../types';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { fmtMoney } from '../../utils/format';

export function SavingsSuggestions({ plan }: { plan: TripPlan }) {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const byId = useMemo(() => new Map(restaurants.map((r) => [r.id, r])), [restaurants]);

  const totalCost = plan.days.reduce((s, d) => s + d.totalCost, 0);
  const over = totalCost - plan.totalBudget;
  if (over <= 0) return null;

  const stops = plan.days
    .flatMap((d) => d.stops.map((st) => ({ r: byId.get(st.restaurantId) })))
    .filter((x) => x.r);

  const byPrice = [...stops].sort(
    (a, b) => b.r!.avgPrice * plan.peopleCount - a.r!.avgPrice * plan.peopleCount,
  );

  const suggestions: string[] = [];
  let acc = 0;
  for (const item of byPrice) {
    const cost = item.r!.avgPrice * plan.peopleCount;
    acc += cost;
    suggestions.push(`去掉「${item.r!.name}」可节省 ${fmtMoney(cost)}`);
    if (acc >= over) break;
  }

  const priciest = byPrice[0];
  if (priciest) {
    const save = Math.round(priciest.r!.avgPrice * plan.peopleCount * 0.3);
    suggestions.push(`把「${priciest.r!.name}」换到午市套餐时段约省 ${fmtMoney(save)}`);
  }

  return (
    <div className="rounded-xl bg-amber/10 p-3">
      <div className="mb-2 text-xs font-medium text-amber">预算超支 {fmtMoney(over)}，建议：</div>
      <ul className="list-disc space-y-1 pl-4 text-xs text-ink/80">
        {suggestions.slice(0, 4).map((s, i) => (
          <li key={i}>{s}</li>
        ))}
      </ul>
    </div>
  );
}
