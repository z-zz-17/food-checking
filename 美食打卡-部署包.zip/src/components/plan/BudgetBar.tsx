import { usePlanStore } from '../../store/usePlanStore';
import { fmtMoney } from '../../utils/format';

export function BudgetBar() {
  const plan = usePlanStore((s) => s.plan);
  if (!plan) return null;

  const totalCost = plan.days.reduce((s, d) => s + d.totalCost, 0);
  const budget = plan.totalBudget;
  const ratio = budget > 0 ? totalCost / budget : 0;

  let color = '#3DBE8B';
  if (ratio > 1) color = '#F44336';
  else if (ratio > 0.8) color = '#F5A623';

  const remaining = budget - totalCost;

  return (
    <div className="space-y-2">
      <div className="flex items-end justify-between">
        <div>
          <div className="text-sm font-medium">预算占用</div>
          <div className="text-xs text-black/50">
            已用 <span className="font-medium">{fmtMoney(totalCost)}</span> / 总额 {fmtMoney(budget)}
          </div>
        </div>
        <div className="text-right text-sm font-medium" style={{ color }}>
          {remaining >= 0 ? `剩余 ${fmtMoney(remaining)}` : `超支 ${fmtMoney(-remaining)}`}
        </div>
      </div>
      <div className="h-3 w-full overflow-hidden rounded-full bg-black/10">
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{ width: `${Math.min(ratio * 100, 100)}%`, background: color }}
        />
      </div>
    </div>
  );
}
