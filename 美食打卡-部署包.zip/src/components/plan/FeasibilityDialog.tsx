import type {
  FeasibilityAction,
  FeasibilityIssue,
  FeasibilityReport,
} from '../../types/planning';
import { Button } from '../ui/Button';
import { fmtMoney, fmtMinutes } from '../../utils/format';

const LEVEL_STYLE: Record<FeasibilityIssue['level'], { box: string; text: string; icon: string }> = {
  blocker: { box: 'bg-red-50', text: 'text-red-600', icon: '⛔' },
  warning: { box: 'bg-amber/10', text: 'text-amber', icon: '⚠' },
  info: { box: 'bg-black/5', text: 'text-black/50', icon: 'ℹ' },
};

/**
 * 方案合理性弹窗。
 * 判定不通过时**不生成行程**，而是把「可执行的调整建议」渲染成按钮，
 * 用户点一下即应用并重新判定；确实想强行生成时也有「仍然生成」。
 */
export function FeasibilityDialog({
  report,
  onApply,
  onClose,
  onForcePlan,
}: {
  report: FeasibilityReport;
  onApply: (action: FeasibilityAction) => void;
  onClose: () => void;
  onForcePlan: () => void;
}) {
  const { stats, intercity, issues, ok } = report;

  return (
    /**
     * 关键：遮罩**不接收任何鼠标事件**。
     * 之前遮罩铺满全屏并吃掉点击与滚轮，用户被判不合理后无法滚动左侧参数面板去看原因
     * （实测反馈：「左边栏被锁定无法下滑看原因」）。
     * 现在遮罩只做视觉压暗、事件全部穿透，而且弹窗贴底显示 ——
     * 上方的参数面板照常可以滚动、修改、点「仍然生成」。
     */
    <div className="pointer-events-none fixed inset-0 z-[2000] flex items-end justify-center p-3">
      <div className="pointer-events-auto flex max-h-[70vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl bg-white shadow-soft ring-1 ring-black/15">
        <div className="flex items-center justify-between border-b border-black/5 px-4 py-3">
          <div className="font-medium">
            {ok ? '⚠️ 可以生成，但有几处需要留意' : '⛔ 这份行程安排不合理'}
          </div>
          <button className="text-black/40 hover:text-black/70" onClick={onClose} type="button">
            ✕ 关闭
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          <div className="rounded-lg bg-black/5 px-3 py-1.5 text-[11px] text-black/50">
            左侧参数面板仍可正常滚动与修改（弹窗已不再挡住它）
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat
              label="餐厅"
              value={`${stats.restaurantCount} 家`}
              highlight={stats.restaurantCount >= 7}
            />
            <Stat
              label="不同城 / 阈值"
              value={`${stats.distinctCityCount} / ${stats.crossCityThreshold}`}
              highlight={stats.distinctCityCount >= stats.crossCityThreshold}
            />
            <Stat
              label="需要时间"
              value={fmtMinutes(stats.requiredMinutes)}
              highlight={stats.requiredMinutes > stats.availableMinutes}
            />
            <Stat
              label={`可用时间（${stats.days} 天）`}
              value={fmtMinutes(stats.availableMinutes)}
            />
          </div>

          <div className="text-[11px] text-black/45">
            通勤 {fmtMinutes(stats.commuteMinutes)} + 到店停留 {fmtMinutes(stats.stayMinutes)}
            ；每天可用 {fmtMinutes(stats.windowMinutes)}（{stats.days} 天）
            {stats.cities.length > 0 && <> · 城市：{stats.cities.join('、')}</>}
          </div>

          {intercity && (
            <div className="rounded-xl bg-brand-light p-3 text-xs text-brand">
              <div className="font-medium">
                城际方案：
                {intercity.mode === 'rail' ? '铁路' : '飞机'} · {intercity.fromCity} →{' '}
                {intercity.toCity}
              </div>
              <div className="mt-1 text-brand/80">{intercity.summary}</div>
              <div className="mt-0.5 text-brand/60">
                里程约 {intercity.km} km · 单人票价约 {fmtMoney(intercity.estimatedFare)}
                （估算值，非真实车次/航班）
              </div>
            </div>
          )}

          {issues.length === 0 ? (
            <div className="rounded-xl bg-mint/10 p-3 text-xs text-mint">
              没有发现问题，可以直接生成行程。
            </div>
          ) : (
            issues.map((issue, i) => {
              const st = LEVEL_STYLE[issue.level];
              return (
                <div key={`${issue.code}-${i}`} className={`rounded-xl p-3 ${st.box}`}>
                  <div className={`flex gap-2 text-xs font-medium ${st.text}`}>
                    <span>{st.icon}</span>
                    <span>{issue.message}</span>
                  </div>
                  {issue.actions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {issue.actions.map((a, j) => (
                        <button
                          key={`${a.kind}-${j}`}
                          type="button"
                          onClick={() => onApply(a)}
                          className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs text-ink transition-colors hover:border-brand hover:text-brand"
                        >
                          {a.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        <div className="flex justify-end gap-2 border-t border-black/5 px-4 py-3">
          <Button variant="ghost" onClick={onClose}>
            返回修改
          </Button>
          {ok ? (
            <Button onClick={onClose}>知道了</Button>
          ) : (
            <Button variant="secondary" onClick={onForcePlan}>
              仍然生成
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className={`rounded-xl p-2 ${highlight ? 'bg-red-50' : 'bg-black/5'}`}>
      <div className="text-[11px] text-black/40">{label}</div>
      <div className={`mt-0.5 font-medium ${highlight ? 'text-red-600' : 'text-ink'}`}>
        {value}
      </div>
    </div>
  );
}
