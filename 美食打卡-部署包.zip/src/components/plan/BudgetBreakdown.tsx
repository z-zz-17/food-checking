import { useMemo, useState } from 'react';
import type { TripPlan } from '../../types';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { fmtMoney } from '../../utils/format';

type Dim = 'day' | 'cuisine' | 'restaurant';

const DIMS: { key: Dim; label: string }[] = [
  { key: 'day', label: '按天' },
  { key: 'cuisine', label: '按菜系' },
  { key: 'restaurant', label: '按餐厅' },
];

export function BudgetBreakdown({ plan }: { plan: TripPlan }) {
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const byId = useMemo(() => new Map(restaurants.map((r) => [r.id, r])), [restaurants]);
  const [dim, setDim] = useState<Dim>('day');

  const data = useMemo(() => {
    const map = new Map<string, number>();
    for (const day of plan.days) {
      for (const st of day.stops) {
        const r = byId.get(st.restaurantId);
        if (!r) continue;
        const cost = r.avgPrice * plan.peopleCount;
        let key: string;
        if (dim === 'day') key = day.date;
        else if (dim === 'cuisine') key = r.cuisine;
        else key = r.name;
        map.set(key, (map.get(key) ?? 0) + cost);
      }
    }
    return [...map.entries()]
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value);
  }, [plan, byId, dim]);

  const max = Math.max(...data.map((d) => d.value), 1);
  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div className="space-y-2">
      <div className="flex gap-1">
        {DIMS.map((d) => (
          <button
            key={d.key}
            onClick={() => setDim(d.key)}
            className={`rounded-full px-3 py-1 text-xs transition-colors ${
              dim === d.key ? 'bg-brand text-white' : 'bg-black/5 text-ink/70 hover:bg-black/10'
            }`}
          >
            {d.label}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {data.map((d) => (
          <div key={d.label} className="flex items-center gap-2">
            <span className="w-16 shrink-0 truncate text-xs text-black/60">{d.label}</span>
            <div className="h-4 flex-1 overflow-hidden rounded-full bg-black/5">
              <div
                className="h-full rounded-full bg-brand transition-all"
                style={{ width: `${(d.value / max) * 100}%` }}
              />
            </div>
            <span className="w-16 shrink-0 text-right text-xs font-medium">{fmtMoney(d.value)}</span>
          </div>
        ))}
      </div>

      <div className="text-right text-xs text-black/40">合计 {fmtMoney(total)}</div>
    </div>
  );
}
