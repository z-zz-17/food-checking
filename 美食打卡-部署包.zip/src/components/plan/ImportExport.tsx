import { useRef } from 'react';
import { usePlanStore } from '../../store/usePlanStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import type { TripPlan } from '../../types';
import { Button } from '../ui/Button';

export function ImportExport() {
  const plan = usePlanStore((s) => s.plan);
  const setPlan = usePlanStore((s) => s.setPlan);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const fileRef = useRef<HTMLInputElement>(null);

  const exportJson = () => {
    if (!plan) return;
    const payload = { version: 1, exportedAt: new Date().toISOString(), plan, restaurants };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `美食打卡行程-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        if (data?.plan) {
          const p = data.plan as TripPlan;
          setPlan(p);
          alert(`已导入行程「${p.title}」，共 ${p.days.length} 天`);
        } else {
          alert('文件格式不正确');
        }
      } catch {
        alert('解析失败，请确认是导出的 JSON 文件');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="flex gap-2">
      <Button
        size="sm"
        variant="secondary"
        onClick={exportJson}
        disabled={!plan}
        className="flex-1"
      >
        导出 JSON
      </Button>
      <Button size="sm" variant="ghost" onClick={() => fileRef.current?.click()} className="flex-1">
        导入 JSON
      </Button>
      <input ref={fileRef} type="file" accept="application/json" onChange={importJson} className="hidden" />
    </div>
  );
}
