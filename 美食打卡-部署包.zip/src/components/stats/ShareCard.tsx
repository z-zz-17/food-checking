import { useRef } from 'react';
import html2canvas from 'html2canvas';
import { usePlanStore } from '../../store/usePlanStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { fmtMoney } from '../../utils/format';
import { Button } from '../ui/Button';

export function ShareCard() {
  const plan = usePlanStore((s) => s.plan);
  const checkIns = usePlanStore((s) => s.checkIns);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const byId = new Map(restaurants.map((r) => [r.id, r]));
  const cardRef = useRef<HTMLDivElement>(null);

  if (!plan) return null;

  const totalCost = plan.days.reduce((s, d) => s + d.totalCost, 0);
  const checkedCount = Object.keys(checkIns).length;
  const totalStops = plan.days.reduce((s, d) => s + d.stops.length, 0);

  const exportCard = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current, { scale: 2, backgroundColor: '#FFFBF7' });
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = '美食打卡.png';
    a.click();
  };

  return (
    <div className="space-y-3">
      <div ref={cardRef} className="rounded-2xl bg-cream p-5" style={{ width: 360 }}>
        <div className="text-center">
          <div className="text-3xl">🍜</div>
          <div className="mt-1 text-lg font-semibold">美食打卡行程</div>
          <div className="text-xs text-black/50">{new Date().toLocaleDateString('zh-CN')}</div>
        </div>

        <div className="mt-3 space-y-1 text-xs text-ink/70">
          {plan.days.map((d) => (
            <div key={d.date}>
              <div className="font-medium">
                {d.date} · {d.stops.length} 站
              </div>
              {d.stops.map((st) => {
                const r = byId.get(st.restaurantId);
                return (
                  <div key={st.restaurantId} className="flex justify-between pl-2">
                    <span>{r ? `${r.emoji ?? '🍴'} ${r.name}` : st.restaurantId}</span>
                    <span>{checkIns[st.restaurantId] ? '✓' : ''}</span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        <div className="mt-3 border-t border-black/10 pt-2 text-center text-xs">
          已打卡 {checkedCount}/{totalStops} 家 · 总花费 {fmtMoney(totalCost)}
        </div>
      </div>

      <Button className="w-full" onClick={exportCard} variant="secondary">
        导出分享图片
      </Button>
    </div>
  );
}
