import { useMemo } from 'react';
import { usePlanStore } from '../../store/usePlanStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { fmtMoney } from '../../utils/format';
import { Badge } from '../ui/Badge';
import { StarRatingDisplay } from '../ui/StarRating';
import { ShareCard } from './ShareCard';
import { formatCheckInDate } from './CheckInDialog';

export function StatsPanel() {
  const checkIns = usePlanStore((s) => s.checkIns);
  const plan = usePlanStore((s) => s.plan);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const byId = useMemo(() => new Map(restaurants.map((r) => [r.id, r])), [restaurants]);

  const checkedIds = Object.keys(checkIns);
  const total = checkedIds.length;
  const totalStops = plan ? plan.days.reduce((s, d) => s + d.stops.length, 0) : restaurants.length;
  const rate = totalStops > 0 ? Math.round((total / totalStops) * 100) : 0;
  const totalSpend = checkedIds.reduce((s, id) => s + (checkIns[id].actualCost || 0), 0);
  const avgRating = checkedIds.length
    ? checkedIds.reduce((s, id) => s + checkIns[id].rating, 0) / checkedIds.length
    : 0;

  const cuisineCount = new Map<string, number>();
  checkedIds.forEach((id) => {
    const r = byId.get(id);
    if (!r) return;
    cuisineCount.set(r.cuisine, (cuisineCount.get(r.cuisine) ?? 0) + 1);
  });
  const favCuisine = [...cuisineCount.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];

  const cities = new Set<string>();
  checkedIds.forEach((id) => {
    const r = byId.get(id);
    const city = r?.address?.match(/^(成都市|上海市|广州市|北京市|深圳市)/)?.[1];
    if (city) cities.add(city);
  });

  const stats = [
    { label: '已打卡', value: `${total} 家` },
    { label: '打卡率', value: `${rate}%` },
    { label: '总消费', value: fmtMoney(totalSpend) },
    { label: '平均评分', value: avgRating ? `${avgRating.toFixed(1)} ★` : '—' },
    { label: '最爱菜系', value: favCuisine ?? '—' },
    { label: '足迹城市', value: cities.size ? [...cities].join('、') : '—' },
  ];

  if (total === 0) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <div className="text-4xl">📊</div>
        <p className="text-sm text-black/50">还没有打卡记录，去地图上点一家店开始打卡吧</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl bg-white p-3 shadow-soft">
            <div className="text-xs text-black/40">{s.label}</div>
            <div className="mt-1 text-lg font-semibold text-ink">{s.value}</div>
          </div>
        ))}
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-medium text-ink">已打卡卡牌</h3>
          <span className="text-xs text-black/40">共 {total} 家</span>
        </div>

        {/*
          已打卡卡牌：每张卡固定渲染 5 项信息 —— 店名（带 emoji）、完整地址、打卡日期、
          「已打卡」徽章、评价星级（同一套半星渲染 + 「4.5 星」文字）。
          若这条打卡关联的餐厅已被删除（byId 取不到），不跳过也不报错，
          而是渲染占位卡（店名/地址用占位文案），保证统计页永远能正常打开。
        */}
        <div className="space-y-2">
          {checkedIds.map((id) => {
            const ci = checkIns[id];
            const r = byId.get(id);
            return (
              <div key={id} className="rounded-xl bg-white p-3 shadow-soft">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="truncate font-medium">
                      {r ? `${r.emoji ?? '🍴'} ${r.name}` : '🍽️ 未知店铺'}
                    </span>
                    <Badge className="bg-mint/15 text-mint">已打卡</Badge>
                  </div>
                  <StarRatingDisplay value={ci.rating} size="sm" />
                </div>

                <div className="mt-1.5 text-xs text-black/55">
                  地址：{r ? r.address : '该餐厅已被删除，地址不可用'}
                </div>
                <div className="mt-1 text-xs text-black/55">
                  打卡日期：{formatCheckInDate(ci.at)}
                </div>
                <div className="mt-1 text-xs text-black/40">
                  实际花费 {fmtMoney(ci.actualCost)}
                </div>

                {ci.comment && <div className="mt-1 text-xs text-ink/70">「{ci.comment}」</div>}
                {ci.photoUrl && (
                  <img
                    src={ci.photoUrl}
                    alt=""
                    className="mt-2 h-20 w-full rounded-lg object-cover"
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <ShareCard />
    </div>
  );
}
