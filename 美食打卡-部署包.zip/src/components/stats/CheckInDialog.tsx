import { useEffect, useRef, useState } from 'react';
import type { ChangeEvent } from 'react';
import type { CheckIn, Restaurant } from '../../types';
import { usePlanStore } from '../../store/usePlanStore';
import { StarRating, formatRatingText } from '../ui/StarRating';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

/**
 * 把 checkIn.at 格式化成 2026-10-09。
 * at 的格式在历史数据里不可控：可能是 ISO（2026-10-09T12:00:00.000Z）、
 * 也可能是旧版本写的「2026-10-09 12:00」甚至脏字符串，所以先做前缀匹配，
 * 匹配不到再 Date.parse，解析失败就原样返回原文 —— 任何情况都不抛错、不崩。
 * 该函数同时被 StatsPanel 复用，保证弹窗与统计卡片上的日期格式永远一致。
 */
export function formatCheckInDate(raw: string): string {
  const text = (raw ?? '').trim();
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  const t = Date.parse(text);
  if (Number.isNaN(t)) return text;
  const d = new Date(t);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${mm}-${dd}`;
}

/** 保存前置校验：返回空字符串＝通过；否则返回要显示给用户的提示文案 */
export function validateCheckInDraft(draft: { rating: number }): string {
  return draft.rating > 0 ? '' : '请先给出评分';
}

/**
 * 组装要落库的 CheckIn（纯函数：now 由调用方传入，便于自检，也避免组件里藏时钟）。
 * 首次打卡记当天日期（ISO 字符串）；已有记录则保留原打卡日期，
 * 避免「只是改个评价就把历史打卡日期刷成今天」。
 * 花费解析失败（空 / 非数字）时回落到该店 avgPrice。
 */
export function buildCheckIn(
  restaurant: Restaurant,
  existing: CheckIn | undefined,
  draft: { rating: number; cost: string; comment: string; photoUrl?: string; now: Date },
): CheckIn {
  const parsedCost = Number.parseInt(draft.cost, 10);
  return {
    at: existing?.at ?? draft.now.toISOString(),
    actualCost: Number.isFinite(parsedCost) ? parsedCost : restaurant.avgPrice,
    rating: draft.rating,
    comment: draft.comment.trim(),
    photoUrl: draft.photoUrl,
  };
}

/**
 * 打卡弹窗（props 保持 { restaurant, onClose } 不变，App.tsx 无需改动）。
 *
 * 【原来为什么会「界面锁定」】旧实现有三个坑：
 *  1) 遮罩是 `fixed inset-0 bg-black/30`，默认 pointer-events:auto，铺满视口后把整页的
 *     点击与滚动全部吃掉，底层地图/列表完全动不了，看上去就是「锁死」了；
 *  2) 关掉弹窗的唯一出口是遮罩上的 onClick，只要 mousedown 与 mouseup 落在不同元素上
 *     （轻微拖拽、移动端手指滑动），click 就不会触发，于是弹窗再也关不掉；
 *  3) 既没有可依赖的 ✕ 出口，也没有 Esc 监听，键盘用户完全没有退路。
 *
 * 【现在的做法】照抄 FeasibilityDialog：
 *  外层容器 `pointer-events-none`（事件全部穿透，底层页面照常可点可滚），
 *  压暗层同样 `pointer-events-none`（只做视觉压暗，不抢事件），
 *  交互只发生在 `pointer-events-auto` 的卡片本体上。
 *  三种关闭方式都在：✕ 按钮、Esc、点遮罩（点卡片以外的任何位置都算点遮罩，
 *  用一个 document 级 mousedown 监听实现 —— 因为遮罩本身 pointer-events:none 收不到 click，
 *  这样既保住了「不挡住整页」，又保住了「点遮罩能关」）。
 */
export function CheckInDialog({
  restaurant,
  onClose,
}: {
  restaurant: Restaurant;
  onClose: () => void;
}) {
  const addCheckIn = usePlanStore((s) => s.addCheckIn);
  const removeCheckIn = usePlanStore((s) => s.removeCheckIn);
  const existing = usePlanStore((s) => s.checkIns[restaurant.id]);

  const [rating, setRating] = useState(existing?.rating ?? 0);
  const [cost, setCost] = useState(
    existing ? String(existing.actualCost) : String(restaurant.avgPrice),
  );
  const [comment, setComment] = useState(existing?.comment ?? '');
  const [photoUrl, setPhotoUrl] = useState<string | undefined>(existing?.photoUrl);
  const [error, setError] = useState('');
  const [askRemove, setAskRemove] = useState(false);

  const cardRef = useRef<HTMLDivElement | null>(null);

  // Esc 关闭 + 点击卡片以外（＝点遮罩）关闭
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    /**
     * 用 mousedown 而不是 click：打开本弹窗的那一次点击要到 click 阶段才结束，
     * 此时 mousedown 早已派发完，所以不会「刚打开就被同一次点击关掉」。
     */
    const handlePointerDown = (e: MouseEvent) => {
      const card = cardRef.current;
      if (card && e.target instanceof Node && card.contains(e.target)) return;
      onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handlePointerDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handlePointerDown);
    };
  }, [onClose]);

  const handlePhoto = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      // 避免 any / 不安全的断言：只有字符串结果才接受
      if (typeof reader.result === 'string') setPhotoUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const submit = () => {
    // 保存前置校验：0 分不保存（用提示而不是禁用按钮，用户才知道为什么点不动）
    const message = validateCheckInDraft({ rating });
    if (message) {
      setError(message);
      return;
    }
    addCheckIn(
      restaurant.id,
      buildCheckIn(restaurant, existing, { rating, cost, comment, photoUrl, now: new Date() }),
    );
    onClose();
  };

  const displayDate = formatCheckInDate(existing?.at ?? new Date().toISOString());

  return (
    /*
     * z-index 必须是 z-[2000]！
     *
     * Leaflet 自带的面板层级是 400（overlay-pane）/ 600（marker-pane）/
     * 700（popup-pane）/ 800（control）/ **1000（leaflet-top、leaflet-bottom）**，
     * 而 Tailwind 的 z-50 只等于 50 —— 于是弹窗被整个地图盖住、肉眼完全看不见，
     * 表现就是"点了打卡没有任何反应 / 界面像被锁住"。
     * 这里统一抬到 2000，稳居所有 Leaflet 面板之上。
     */
    <div className="pointer-events-none fixed inset-0 z-[2000] flex items-center justify-center p-4">
      {/* 压暗层：pointer-events-none，只压暗不抢事件（点击它的效果由上面的 mousedown 监听兜底） */}
      <div className="pointer-events-none absolute inset-0 bg-black/30" aria-hidden="true" />

      <div
        ref={cardRef}
        role="dialog"
        aria-label={`打卡 · ${restaurant.name}`}
        className="pointer-events-auto relative flex max-h-[85vh] w-full max-w-sm flex-col overflow-hidden rounded-2xl bg-white shadow-soft ring-1 ring-black/10"
      >
        <div className="flex items-center justify-between border-b border-black/5 px-4 py-3">
          <div className="font-medium">
            <span className="mr-1">{restaurant.emoji ?? '🍴'}</span>
            打卡 · {restaurant.name}
          </div>
          <button
            type="button"
            aria-label="关闭打卡弹窗"
            className="rounded-md px-1 text-black/40 transition-colors hover:text-black/70 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
            onClick={onClose}
          >
            ✕
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {existing && (
            <div className="rounded-xl bg-mint/10 p-3 text-xs text-mint">
              <span className="font-medium">已打卡</span>
              ：这家店在 {formatCheckInDate(existing.at)} 打卡，当前评价{' '}
              {formatRatingText(existing.rating)}；改完后再次保存即可覆盖。
            </div>
          )}

          <div>
            <label className="mb-1 block text-xs text-black/50">评分（必填）</label>
            <StarRating
              value={rating}
              size="lg"
              onChange={(v) => {
                setRating(v);
                if (v > 0) setError('');
              }}
            />
            <p className="mt-1 text-[11px] text-black/40">
              点星星左半给半颗星（第 5 颗星左半 = 4.5 星），也可以用 ←/→ 键每次微调 0.5 星
            </p>
            {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs text-black/50">实际花费 ¥（可选）</label>
              <Input
                type="number"
                min={0}
                value={cost}
                placeholder={String(restaurant.avgPrice)}
                onChange={(e) => setCost(e.target.value)}
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-black/50">打卡日期</label>
              <div className="rounded-xl bg-black/5 px-3 py-2 text-sm text-ink/70">
                {displayDate}
              </div>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs text-black/50">评论（可选）</label>
            <textarea
              rows={3}
              value={comment}
              placeholder="味道怎么样？环境如何？"
              onChange={(e) => setComment(e.target.value)}
              className="w-full resize-none rounded-xl border border-black/10 bg-white px-3 py-2 text-sm text-ink outline-none transition-colors placeholder:text-black/35 focus:border-brand"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs text-black/50">照片（可选，本地预览）</label>
            <input type="file" accept="image/*" onChange={handlePhoto} className="block text-xs" />
            {photoUrl && (
              <img
                src={photoUrl}
                alt="打卡照片预览"
                className="mt-2 h-24 w-full rounded-xl object-cover"
              />
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-black/5 px-4 py-3">
          {existing ? (
            askRemove ? (
              <div className="flex items-center gap-2 text-xs text-black/60">
                确定取消打卡？
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => {
                    removeCheckIn(restaurant.id);
                    onClose();
                  }}
                >
                  确认取消
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setAskRemove(false)}>
                  返回
                </Button>
              </div>
            ) : (
              <Button variant="ghost" size="sm" onClick={() => setAskRemove(true)}>
                取消打卡
              </Button>
            )
          ) : (
            <span className="text-[11px] text-black/35">点了保存就会进「统计 · 已打卡」</span>
          )}

          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose}>
              取消
            </Button>
            <Button onClick={submit}>保存打卡</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
