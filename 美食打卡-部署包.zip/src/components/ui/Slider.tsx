import type { ChangeEvent } from 'react';

export function Slider({
  label,
  left,
  right,
  value,
  onChange,
}: {
  label: string;
  left: string;
  right: string;
  value: number;
  onChange: (v: number) => void;
}) {
  const handle = (e: ChangeEvent<HTMLInputElement>) => onChange(Number(e.target.value));
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs text-ink/70">
        <span>{label}</span>
        <span className="font-medium text-ink">{value}</span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={handle}
        className="w-full accent-brand"
      />
      <div className="flex justify-between text-[11px] text-black/40">
        <span>{left}</span>
        <span>{right}</span>
      </div>
    </div>
  );
}
