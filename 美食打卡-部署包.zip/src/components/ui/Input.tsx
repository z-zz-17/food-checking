import { forwardRef, type InputHTMLAttributes } from 'react';

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className = '', ...props }, ref) {
    return (
      <input
        ref={ref}
        className={`w-full rounded-xl border border-black/10 bg-white px-3 py-2 text-sm text-ink outline-none transition-colors placeholder:text-black/35 focus:border-brand ${className}`}
        {...props}
      />
    );
  },
);
