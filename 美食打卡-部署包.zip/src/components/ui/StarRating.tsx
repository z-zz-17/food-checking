/**
 * 五星半星评分组件（0.5 步进）。
 *
 * 【半星是怎么实现的】
 * 每颗星都是一个「双层 ★」结构：
 *   底层 = 一颗灰星（text-black/15），充当未点亮的镂空轮廓；
 *   上层 = 同一位置再绝对定位叠一颗金星，用 overflow-hidden + width 做裁切：
 *          width: 100% → 满星；width: 50% → 只露出左半颗（这就是半星）；不渲染 → 空星。
 * 两层用完全相同的字号与 leading-none，所以裁切线正好落在星形中线上，视觉上就是标准半星。
 * 这样不依赖任何字体图标库、也不新增依赖。
 *
 * 【交互】
 * 每颗星按钮内部再切左右两个热区（各占按钮宽度 50%）：
 *   点左半 → i - 0.5（第 5 颗星左半 = 4.5 星），点右半 → i（第 5 颗星右半 = 5 星）。
 * 键盘：每颗星都是 <button type="button"> 并带 aria-label；
 *   Enter/Space（按钮默认 click）＝ 取整颗星的分值，←/→（或 ↑/↓）每次 ±0.5，
 *   所以纯键盘也能精确选出 4.5 星。
 */
import type { KeyboardEvent } from 'react';

export type StarSize = 'sm' | 'md' | 'lg';

const SIZE_CLASS: Record<StarSize, string> = {
  sm: 'text-sm',
  md: 'text-xl',
  lg: 'text-3xl',
};

/** 把任意（含脏数据）分值规整成 0～5 之间、步进 0.5 的合法值 */
export function normalizeRating(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.min(5, Math.max(0, Math.round(value * 2) / 2));
}

/** 「4.5 星」/「5 星」——弹窗与统计卡片共用同一套文案 */
export function formatRatingText(value: number): string {
  const v = normalizeRating(value);
  return `${Number.isInteger(v) ? v : v.toFixed(1)} 星`;
}

/** 单颗星的双层渲染：fill = 0 空星 / 0.5 半星 / 1 满星 */
function StarGlyph({ fill }: { fill: 0 | 0.5 | 1 }) {
  return (
    <span className="relative inline-block leading-none" aria-hidden="true">
      {/* 底层灰星：未点亮部分 */}
      <span className="leading-none text-black/15">★</span>
      {/* 上层金星：宽度决定露出比例，50% 即半星 */}
      {fill > 0 && (
        <span
          className="absolute inset-y-0 left-0 overflow-hidden whitespace-nowrap leading-none text-amber"
          style={{ width: fill === 1 ? '100%' : '50%' }}
        >
          ★
        </span>
      )}
    </span>
  );
}

/** 根据当前分值算出第 i 颗星（i 从 1 开始）该填多少 */
function fillOf(rating: number, i: number): 0 | 0.5 | 1 {
  if (rating >= i) return 1;
  if (rating >= i - 0.5) return 0.5;
  return 0;
}

const STARS = [1, 2, 3, 4, 5];

/** 只读展示：统计卡片里用它渲染「半星 + 4.5 星」 */
export function StarRatingDisplay({
  value,
  size = 'sm',
  showText = true,
}: {
  value: number;
  size?: StarSize;
  showText?: boolean;
}) {
  const rating = normalizeRating(value);
  return (
    <span className="inline-flex items-center gap-1">
      <span
        className={`inline-flex items-center gap-0.5 ${SIZE_CLASS[size]}`}
        role="img"
        aria-label={`评分 ${formatRatingText(rating)}`}
      >
        {STARS.map((i) => (
          <StarGlyph key={i} fill={fillOf(rating, i)} />
        ))}
      </span>
      {showText && <span className="text-xs text-black/50">{formatRatingText(rating)}</span>}
    </span>
  );
}

/** 可编辑评分：默认 0（未评），点击/键盘都可改，允许用户随时改 */
export function StarRating({
  value,
  onChange,
  size = 'md',
  label = '评分',
}: {
  value: number;
  onChange: (value: number) => void;
  size?: StarSize;
  label?: string;
}) {
  const rating = normalizeRating(value);

  const handleKeyDown = (e: KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
      e.preventDefault();
      onChange(normalizeRating(rating - 0.5));
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
      e.preventDefault();
      onChange(normalizeRating(rating + 0.5));
    }
  };

  return (
    <div className="flex items-center gap-2">
      <div className={`flex items-center gap-0.5 ${SIZE_CLASS[size]}`} role="group" aria-label={label}>
        {STARS.map((i) => (
          <button
            key={i}
            type="button"
            // 点击整颗星（含键盘 Enter/Space 触发的 click）= 取该颗星的整分值
            onClick={() => onChange(i)}
            onKeyDown={handleKeyDown}
            aria-label={`第 ${i} 颗星：点左半 ${i - 0.5} 星，点右半 ${i} 星`}
            aria-pressed={rating >= i - 0.5}
            className="relative rounded-md px-0.5 py-0.5 leading-none transition-transform hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
          >
            <StarGlyph fill={fillOf(rating, i)} />
            {/* 左半热区：X.5；stopPropagation 防止冒泡到按钮把自己改成整数星 */}
            <span
              className="absolute inset-y-0 left-0 w-1/2 cursor-pointer"
              aria-hidden="true"
              onClick={(e) => {
                e.stopPropagation();
                onChange(i - 0.5);
              }}
            />
            {/* 右半热区：X.0 */}
            <span
              className="absolute inset-y-0 right-0 w-1/2 cursor-pointer"
              aria-hidden="true"
              onClick={(e) => {
                e.stopPropagation();
                onChange(i);
              }}
            />
          </button>
        ))}
      </div>
      <span className="text-xs text-black/50">{rating > 0 ? formatRatingText(rating) : '未评分'}</span>
    </div>
  );
}
