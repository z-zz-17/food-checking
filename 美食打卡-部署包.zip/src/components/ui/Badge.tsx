import type { ReactNode } from 'react';
import type { Priority } from '../../types';

const priorityStyle: Record<Priority, string> = {
  must: 'bg-brand text-white',
  want: 'bg-amber/90 text-white',
  optional: 'bg-black/10 text-ink',
};

const priorityLabel: Record<Priority, string> = {
  must: '必去',
  want: '想去',
  optional: '可选',
};

export function PriorityBadge({ priority }: { priority: Priority }) {
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${priorityStyle[priority]}`}>
      {priorityLabel[priority]}
    </span>
  );
}

export function Badge({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${className}`}>
      {children}
    </span>
  );
}
