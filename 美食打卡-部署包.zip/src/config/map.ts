export type CoordinateSystem = 'gcj02' | 'wgs84';

type TileSource = {
  id: string;
  label: string;
  url: string;
  subdomains?: string[];
  coordSystem: CoordinateSystem;
  attribution: string;
};

export const TILE_SOURCES: Record<string, TileSource> = {
  amap: {
    id: 'amap',
    label: '高德地图',
    url: 'https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
    subdomains: ['1', '2', '3', '4'],
    coordSystem: 'gcj02',
    attribution: '&copy; 高德地图',
  },
  osm: {
    id: 'osm',
    label: 'OpenStreetMap',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    subdomains: ['a', 'b', 'c'],
    coordSystem: 'wgs84',
    attribution: '&copy; OpenStreetMap contributors',
  },
};

export const DEFAULT_TILE_SOURCE: TileSource = TILE_SOURCES.amap;
export const MAP_CENTER = { lat: 30.5728, lng: 104.0668 };
export const MAP_ZOOM = 12;
