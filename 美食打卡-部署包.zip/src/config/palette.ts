/** 每天的主题色（列表圆点、时间轴、地图兜底线条共用同一套） */
export const DAY_COLORS = [
  '#FF6B4A',
  '#3DBE8B',
  '#F5A623',
  '#6C8CFF',
  '#E06CDB',
  '#26B7C9',
  '#9B86F7',
];
