/**
 * 规划相关的共享类型契约（服务层 / 算法层 / UI 都引用这里，避免各写各的）。
 */
import type { LegSegment, OpenHour, PlanParams, Priority, TravelMode } from './index';

/** 一段耗时的来源：真实接口 or 估算模型 */
export type LegSource = 'amap' | 'estimate';

/** 同城一段通勤（点到点、单一交通方式） */
export type RouteLeg = {
  mode: TravelMode;
  minutes: number;
  km: number;
  source: LegSource;
  /** 只要含任何估算成分就为 true */
  estimated: boolean;
  /** 分段明细：步行/地铁/换乘，用于反馈展示 */
  segments: LegSegment[];
  /** 真实路径折线（WGS-84，调用方负责画图时转 GCJ-02）；估算/城际铁路航班为空 */
  path?: { lat: number; lng: number }[];
  summary?: string;
  /** 非空表示这一段走的是城际模块（铁路/航班/跨城公交地铁） */
  intercity?: IntercityLeg;
};

/** 城际交通方式 */
export type IntercityMode = 'rail' | 'flight';

/** 铁路分档 */
export type RailClass = 'normal' | 'emu' | 'hsr';

/** 城际一段（城市 A → 城市 B） */
export type IntercityLeg = {
  mode: IntercityMode;
  fromCity: string;
  toCity: string;
  km: number;
  minutes: number;
  railClass?: RailClass;
  source: LegSource;
  /** 估算票价（人民币元，单人） */
  estimatedFare: number;
  summary: string;
};

/** 可行性问题的可执行动作 */
export type FeasibilityActionKind =
  | 'addDays'
  | 'setMode'
  | 'setIntercity'
  | 'setTimeWindow'
  | 'removeRestaurant'
  | 'changeOrigin';

export type FeasibilityAction = {
  kind: FeasibilityActionKind;
  /** 按钮文案，例如「把天数改为 3 天」 */
  label: string;
  /** 直接合并进 PlanParams 的补丁（removeRestaurant 除外） */
  patch?: Partial<PlanParams>;
  /** 针对某家餐厅的动作（如移除） */
  restaurantId?: string;
};

export type IssueLevel = 'blocker' | 'warning' | 'info';

export type FeasibilityIssue = {
  level: IssueLevel;
  /** 机器可读码：TOO_MANY_RESTAURANTS / CROSS_CITY / TIME_NOT_ENOUGH / ... */
  code: string;
  message: string;
  actions: FeasibilityAction[];
};

export type FeasibilityStats = {
  /** 餐厅数 */
  restaurantCount: number;
  /** 地址总数 = 出发点 + 餐厅数 */
  addressCount: number;
  /** 出现的不同城市 */
  cities: string[];
  /** 不同城个数 M */
  distinctCityCount: number;
  /** 判定阈值 = min(N, 3)；M ≥ 阈值 → 判不合理 */
  crossCityThreshold: number;
  /** 通勤总分钟（按传入顺序累加） */
  commuteMinutes: number;
  /** 到店停留总分钟 */
  stayMinutes: number;
  /** 需要的时间 = 通勤 + 停留 */
  requiredMinutes: number;
  /** 按第 13 条公式算出的可用时间 */
  availableMinutes: number;
  days: number;
  /** 单日窗口长度（开始→结束） */
  windowMinutes: number;
};

export type FeasibilityReport = {
  /** true = 可以生成 */
  ok: boolean;
  issues: FeasibilityIssue[];
  intercity: IntercityLeg | null;
  stats: FeasibilityStats;
};

/** 校验所需的最小餐厅信息 */
export type FeasibilityRestaurant = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  stayMinutes: number;
  /** 从地址解析出的城市（没有则 undefined） */
  city?: string;
  /** 营业时段：用于判断「营业时间与每日可用时段是否有交集」；缺省视为全天营业 */
  hours?: OpenHour[];
  /** 优先级：判定弹窗据此挑选「可以先移除哪几家」的建议 */
  priority?: Priority;
  /** 人均消费：供「自动计算的预算 ≥ 总预算」这条判定使用 */
  avgPrice?: number;
};

export type FeasibilityInput = {
  /** 已按最终顺序排列 */
  restaurants: FeasibilityRestaurant[];
  origin: { lat: number; lng: number; label: string };
  params: PlanParams;
  /**
   * 各段通勤分钟数，顺序与 restaurants 一致：
   *   legMinutes[0] = 起点 → restaurants[0]
   *   legMinutes[i] = restaurants[i-1] → restaurants[i]
   * 缺省时内部用直线估算兜底。
   */
  legMinutes?: number[];
  legKm?: number[];
  /** 调用方已判定的城际段（跨城时提供） */
  intercity?: IntercityLeg | null;
};

/** 地图 POI（高德 PlaceSearch 结果） */
export type PoiInfo = {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  /** 高德 type 文本，餐饮为「餐饮服务;...」 */
  type: string;
  /** 距查询点距离（米） */
  distanceM: number;
};

/** 点选位置的餐饮判定结果 */
export type PoiCheckResult = {
  /** 该点本身是否就是餐饮 POI */
  isRestaurant: boolean;
  /** 命中的 POI（就是餐厅时） */
  poi?: PoiInfo;
  /** 不是餐厅时，吸附到的最近餐饮店 */
  nearest?: PoiInfo;
  /** 查询半径（米） */
  radiusM: number;
  /** 数据来源 */
  source: LegSource;
};
