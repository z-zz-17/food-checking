export type Priority = 'must' | 'want' | 'optional';

export type TravelMode = 'walk' | 'bike' | 'drive' | 'transit';

export type OpenHour = { open: string; close: string };

export type Restaurant = {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  cuisine: string;
  avgPrice: number;
  hours: OpenHour[];
  stayMinutes: number;
  priority: Priority;
  emoji?: string;
  note?: string;
  /**
   * **手动指定的城市**（清单页把卡片拖到别的城市分组里就会写入这里）。
   * 为空时按「地址里的城市名 → 坐标推断」自动判定。
   */
  city?: string;
};

export type CheckIn = {
  at: string;
  actualCost: number;
  rating: number;
  comment: string;
  photoUrl?: string;
};

/** 一段通勤内部的组成，用于反馈里展示「步行×分钟 / 地铁2号线×分钟」 */
export type LegSegmentKind =
  | 'walk'
  | 'bike'
  | 'drive'
  | 'bus'
  | 'subway'
  | 'rail'
  | 'ferry'
  | 'flight'
  | 'other';

export type LegSegment = {
  kind: LegSegmentKind;
  /** 展示文案，例如「地铁2号线」「步行」「广佛线」 */
  label: string;
  minutes: number;
  km?: number;
  /** 站点/端点名（公交地铁用于说明换乘） */
  from?: string;
  to?: string;
  /** 这一小段的真实路径折线（WGS-84），用于按线路颜色分段画线 */
  path?: { lat: number; lng: number }[];
  /** 这一小段的显示颜色（步行/骑行自定义；地铁按线路配色表） */
  color?: string;
};

export type TravelLeg = {
  mode: TravelMode;
  minutes: number;
  km: number;
  /** 数据来源：真实接口 or 估算模型 */
  source?: 'amap' | 'estimate';
  /** 只要这一段含任何估算成分就为 true（用于「无任何参考价值」提示） */
  estimated?: boolean;
  /** 分段明细：公共交通会拆成 步行 → 线路 → 步行… */
  segments?: LegSegment[];
  /** 城际段摘要（铁路/航班），例如「高铁 · 约4小时20分」 */
  intercitySummary?: string;
  /** 真实路径折线（GCJ-02，供地图绘制）；估算或城际铁路/航班为空 */
  path?: { lat: number; lng: number }[];
};

export type TripStop = {
  restaurantId: string;
  order: number;
  arriveAt: string;
  departAt: string;
  travelFromPrev: TravelLeg;
  checkIn?: CheckIn;
};

export type TripDay = {
  date: string;
  stops: TripStop[];
  totalCost: number;
  totalDistanceKm: number;
};

export type Warning = {
  level: 'info' | 'warning' | 'danger';
  message: string;
};

export type TripPlan = {
  id: string;
  title: string;
  days: TripDay[];
  totalBudget: number;
  peopleCount: number;
  /** 整份方案里是否含估算成分（只要有 → 反馈显示「无任何参考价值！！！」） */
  estimated?: boolean;
  /** 每天的真实路径折线（GCJ-02），供地图按真实道路绘制路线 */
  routePaths?: { lat: number; lng: number }[][];
  warnings: Warning[];
};

export type PlanParams = {
  origin: { lat: number; lng: number; label: string };
  /** 每天的可用时段：所有天都相同（开始时间 / 结束时间） */
  startTime: string;
  endTime: string;
  days: number;
  travelMode: TravelMode;
  totalBudget: number;
  peopleCount: number;
  weightWalk: number;
  weightTime: number;
  /**
   * 每天最多排几站（1–8，默认 5）。
   * 界面上是「每天最多几站」数轴；超出就顺延次日，天数用尽时提示哪几家没排进去。
   * 注意 weightWalk / weightTime 两个旧字段已不再被任何逻辑读取（保留仅为兼容旧存档）。
   */
  maxStopsPerDay?: number;
  /**
   * 跨城时选择的城际交通方式（'rail' | 'flight'）；
   * 同城规划为 null / undefined。用字符串字面量而非 import，
   * 避免 types/index.ts ⇄ types/planning.ts 循环依赖。
   */
  intercity?: 'rail' | 'flight' | null;
};

export type GeoSearchResult = {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  cuisine: string;
  avgPrice: number;
};
