/**
 * 行程可行性评估。
 *
 * 【职责边界 · 必读】
 * 本文件只做「合理性判定」，不做路线计算：路线数据（每一段的真实/估算通勤耗时与里程）
 * 由调用方通过 `input.legMinutes` / `input.legKm` 传入，本文件只负责求和与判定。
 * 只有在调用方没有提供某一段的耗时时，才用直线距离（haversineKm）按速度模型兜底估算，
 * 因此本文件产出的数字只用于「够不够」的量级判断，不用于排点。
 *
 * 纯函数：不导入 React / store / services，不发网络请求，不读写 localStorage，不修改入参。
 *
 * 【三条「不合理」（blocker）规则的来历与边界】
 *   规则 1（餐厅 ≥ 7 家）：一次行程里要逛的店太多，排队 / 点单 / 用餐衔接必然失控，
 *     且地址总数 N = 餐厅数 + 1（出发点也算一个地址），所以 7 家 = 8 个地址已经远超
 *     单日与短途多日的承载上限。边界：恰好 6 家仍然放行（6 家 = 7 个地址，是刻意留下的上限）。
 *   规则 2（不同城数过多）：判定式 `M >= min(N, 3)`（用户自定义规则，务必按此实现）。
 *     代入校验：N=2 时 M≥2 即不合理（两个地址还分属两城 → 单段城际不可避免）；
 *     N=3 时 M≥3 才不合理（任意两者同城即放行，允许「两城三点」）；N≥4 时 M≥3 即不合理。
 *     出发点城市解析失败时用占位名「出发地」并【单独】算作一个城市、不参与去重，
 *     避免「解析失败」反而把判定放宽。
 *   规则 3（时间不够）：可用时间 < 需要时间（通勤 + 停留）。
 *     可用时间公式见 dailyAvailableMinutes()：单日就是窗口长度；多日还要加上
 *     「夜里可自由支配的时间」——每天扣掉 3 小时睡眠（180 分钟）、其余时间可用。
 *
 * 【只做提示（warning / info）的问题】
 *   营业时间无交集、步行过远、跨城未选城际方式、单日站点偏多，这四类只是提醒，
 *   绝不设为 blocker——否则会把本来可以生成的方案误阻断。
 *
 * 任何非法输入（空数组、坐标 NaN / undefined、hours 缺失、时段非法、days 为 0 / NaN）
 * 都必须降级为默认值或一条 issue，绝不抛异常。
 * 其中「空数组」（一家店都没选）是退化情形：此时不套用三条 blocker 规则——规则 2 的阈值
 * min(N, 3) 在 N = 1 时会退化成 1，会把「没有任何餐厅」误判为跨城；只有时段本身非法时才报 blocker。
 */
import type {
  FeasibilityAction,
  FeasibilityInput,
  FeasibilityIssue,
  FeasibilityReport,
  FeasibilityRestaurant,
  FeasibilityStats,
  IntercityLeg,
  IntercityMode,
} from '../types/planning';
import type { OpenHour, PlanParams } from '../types';
import { haversineKm } from './coords';
import { estimateTravel } from './travel';
import { estimateIntercity, guessCity } from './intercity';
import { cityByCoords } from './cityLookup';
import { fmtMinutes, toMinutes } from '../utils/format';

// ---------------------------------------------------------------------------
// 具名常量（阈值 / 兜底值，改动请同步更新上面的规则说明）
// ---------------------------------------------------------------------------

/** 规则 1 阈值：餐厅数达到该值即判不合理（6 家以内的组合仍然放行） */
const MAX_RESTAURANT_COUNT = 7;

/** 规则 2 阈值上限：不同城个数达到 min(地址总数 N, 该值) 即判不合理 */
const CROSS_CITY_THRESHOLD_CAP = 3;

/** 一天的总分钟数（24 小时） */
const MINUTES_PER_DAY = 1440;

/** 多日行程里每天扣掉的睡眠时间（分钟，= 3 小时，不参与行程安排） */
const DAILY_SLEEP_MINUTES = 180;

/** 每日时间窗长度非法（≤ 0 / NaN）时的兜底值（分钟），保证后续判断有意义 */
const FALLBACK_WINDOW_MINUTES = 60;

/** 单日站点数参考上限：超过该值提示可能偏紧（仅 info） */
const MAX_STOPS_PER_DAY = 5;

/** 规则 3 建议天数的上限：UI 只提供 1–7 天，超过 7 天的建议不给按钮 */
const MAX_SUGGESTED_DAYS = 7;

/** 规则 3 建议时间窗的起止时刻（= 12 小时窗口） */
const SUGGESTED_START_TIME = '09:00';
const SUGGESTED_END_TIME = '21:00';

/** 规则 3 建议时间窗的长度（分钟，12 小时） */
const SUGGESTED_WINDOW_MINUTES = 720;

/** 步行不合理里程阈值（km，单段）：8km 步行约 1.8h，单程就吃掉当日大半可用时间 */
const WALK_TOO_FAR_KM = 8;

/** 各类提示里最多附带的「移除餐厅」动作条数，避免弹窗里塞满按钮 */
const MAX_REMOVE_ACTIONS_FOR_TOO_MANY = 3;
const MAX_REMOVE_ACTIONS_FOR_CROSS_CITY = 2;
const MAX_REMOVE_ACTIONS_FOR_TIME = 2;

/** 营业时段与时间窗的边界容差（分钟）：关闭时刻按「含端点」处理，避免刚好 21:00 关店被误判 */
const BOUNDARY_TOLERANCE_MINUTES = 1;

/** 每日可用时段兜底起点（分钟，= 09:00），仅用于文案展示 */
const FALLBACK_START_MINUTES = 9 * 60;

/** 出发地城市无法从地址解析出来时的占位名（单独算一个城市，不参与去重） */
const ORIGIN_CITY_PLACEHOLDER = '出发地';

/** 停留时长缺失 / 非法时的兜底值（分钟） */
const DEFAULT_STAY_MINUTES = 45;

/** 命中不了优先级表的脏数据排到最后 */
// （原 UNKNOWN_PRIORITY_RANK 已删除：必去/想去/可选只是标签，不参与任何排序或判定）

// ---------------------------------------------------------------------------
// 内部类型
// ---------------------------------------------------------------------------

/** 通勤腿：本文件只关心耗时与里程，不关心具体路线 */
type LegInfo = { minutes: number; km: number };

/** 距离辅助用的地理点（城际估算需要城市名，坐标非法时会被单独处理） */
type GeoPoint = { lat: number; lng: number };

/** 城市聚合结果 */
type CitySummary = {
  /** 不同城市列表（去重后，按「出发地 → 餐厅出现顺序」排列） */
  cities: string[];
  /** 不同城市个数 M */
  distinctCityCount: number;
  /** 出发地所属城市（解析失败时用占位名，并单独计为一个城市） */
  originCity: string;
  /** 是否跨城（M ≥ 2，占位名也算一个城市） */
  crossCity: boolean;
};

/** 时间窗的合法化结果 */
type ResolvedWindow = {
  /** 用于计算的窗口长度（分钟），非法时已兜底 */
  windowMinutes: number;
  /** 窗口是否非法（NaN / ≤ 0 / 超过一整天） */
  invalid: boolean;
  /** 起止时刻（分钟），缺失时用兜底值，仅用于文案 */
  startMinutes: number;
  endMinutes: number;
};

// ---------------------------------------------------------------------------
// 基础工具：全部不抛异常
// ---------------------------------------------------------------------------

/** 数值消毒：非有限值（NaN / Infinity / 非 number）一律降级为 fallback，杜绝 NaN 传播 */
function finiteOr(value: number, fallback: number): number {
  return Number.isFinite(value) ? value : fallback;
}

/** 坐标是否可用（地理编码失败时可能是 NaN / undefined / 非 number） */
function isValidGeoPoint(point: { lat?: number; lng?: number } | null | undefined): boolean {
  return point != null && Number.isFinite(point.lat) && Number.isFinite(point.lng);
}

/**
 * toMinutes 的安全包装：任何异常输入（undefined / 非字符串 / 缺冒号 / 越界）
 * 都返回 null，绝不抛错。
 */
function safeToMinutes(hhmm: string | undefined | null): number | null {
  if (typeof hhmm !== 'string' || hhmm.trim() === '') return null;
  try {
    const value = toMinutes(hhmm);
    return Number.isFinite(value) ? value : null;
  } catch {
    return null;
  }
}

/** 分钟数 → HH:MM（用于文案；越界值取当天余数，绝不产出 NaN 字符串） */
function toClockText(minutes: number): string {
  const safe = Math.trunc(finiteOr(minutes, 0));
  const rem = ((safe % MINUTES_PER_DAY) + MINUTES_PER_DAY) % MINUTES_PER_DAY;
  const hh = String(Math.floor(rem / 60)).padStart(2, '0');
  const mm = String(rem % 60).padStart(2, '0');
  return `${hh}:${mm}`;
}

/** 时间字符串 → 展示文本（解析失败时原样展示，非字符串时用兜底时刻） */
function timeText(value: string | undefined | null, fallbackMinutes: number): string {
  const parsed = safeToMinutes(value);
  if (parsed !== null) return toClockText(parsed);
  return typeof value === 'string' && value.trim() !== '' ? value : toClockText(fallbackMinutes);
}

/** 保持首次出现顺序的去重 */
function uniqueNames(names: readonly string[]): string[] {
  return [...new Set(names)];
}

/** 城市名归一化：去空白；空 / 非字符串一律视为「无法识别」 */
function normalizeCityName(value: string | undefined | null): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return trimmed === '' ? null : trimmed;
}

/** cityByCoords 的安全包装：纯计算，理论上不抛，脏数据一律 null */
function safeCityByCoords(lat: number, lng: number): string | null {
  try {
    return cityByCoords(lat, lng);
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// 城市统计：N / M 的来源
// ---------------------------------------------------------------------------

/**
 * 计算「不同城市」集合与个数 M。
 *
 * 规则：
 *   - 出发地城市：直接 `guessCity(origin.label)`；解析失败用占位名「出发地」，
 *     并【单独】算作一个城市、不参与去重（解析失败反而更严格，绝不放宽判定）；
 *   - 餐厅城市按三级顺序取：
 *       ① `restaurant.city`（调用方显式声明的优先）
 *       ② **坐标推断**（`cityByCoords`，就近 158 城）—— 关键修复，见下
 *       ③ 都没有才折算成「未知城市#序号」，彼此不合并（保守：宁可更严格）
 *
 * 为什么必须有 ②（这是一个真实踩过的坑）：
 *   早期只认 `restaurant.city`，没有就各自编一个「未知城市#i」。
 *   于是「广州出发 + 两家成都餐厅」这种情形，两家成都店会变成
 *   「未知城市#1 / 未知城市#2」→ M 被**多算**成 3 → 达到阈值 3 → 误判为跨城不合理。
 *   而按用户规则，两家店同城 ⇒「任意两者在同城则合理」，应为 M=2、不该被拦。
 *   两家店的坐标本来就在成都，直接按坐标推断即可得到正确结果。
 */
function summarizeCities(
  restaurants: readonly FeasibilityRestaurant[],
  originLabel: string,
): CitySummary {
  let originCity: string;
  try {
    originCity = guessCity(typeof originLabel === 'string' ? originLabel : '') ?? ORIGIN_CITY_PLACEHOLDER;
  } catch {
    originCity = ORIGIN_CITY_PLACEHOLDER;
  }

  const names: string[] = [originCity];
  let unknownSeq = 0;
  for (const restaurant of restaurants) {
    const declared = normalizeCityName(restaurant?.city);
    if (declared !== null) {
      names.push(declared);
      continue;
    }
    const byCoords = isValidGeoPoint(restaurant)
      ? safeCityByCoords(restaurant.lat, restaurant.lng)
      : null;
    if (byCoords !== null) {
      names.push(byCoords);
      continue;
    }
    unknownSeq += 1;
    names.push(`未知城市#${unknownSeq}`);
  }

  const cities = uniqueNames(names);
  return {
    cities,
    distinctCityCount: cities.length,
    originCity,
    crossCity: cities.length >= 2,
  };
}

// ---------------------------------------------------------------------------
// 时间窗与可用时间
// ---------------------------------------------------------------------------

/**
 * 合法化每日时间窗：endTime - startTime。
 * ≤ 0 / NaN / 超过一整天（1440 分钟）都视为非法 → 兜底为 60 分钟并标记非法。
 * 上限 1440 是因为可用时间公式里的「夜里可自由支配时间 = 1440 - window - 180」，
 * window 超过一天时该式会变成负数，多日行程反而越算越少，必须挡住。
 */
function resolveWindow(params: PlanParams): ResolvedWindow {
  const rawStart = safeToMinutes(params?.startTime);
  const rawEnd = safeToMinutes(params?.endTime);
  const startMinutes = rawStart ?? FALLBACK_START_MINUTES;
  const endMinutes = rawEnd ?? startMinutes + FALLBACK_WINDOW_MINUTES;
  const rawWindowMinutes =
    rawStart !== null && rawEnd !== null ? rawEnd - rawStart : Number.NaN;
  const invalid = !(rawWindowMinutes > 0) || rawWindowMinutes > MINUTES_PER_DAY;
  return {
    windowMinutes: invalid ? FALLBACK_WINDOW_MINUTES : rawWindowMinutes,
    invalid,
    startMinutes,
    endMinutes,
  };
}

/**
 * 行程天数合法化：0 / 负数 / NaN 一律按 1 天参与计算（保持数字守恒，不做截断）。
 * 返回 0 表示该值本身就不可信，调用方按 1 天使用。
 */
function normalizeDays(days: number): number {
  return Number.isFinite(days) && days > 0 ? Math.floor(days) : 0;
}

/**
 * 用户给定的可用时间公式（第 13 条）：
 *   days === 1 → availableMinutes = window
 *   days  >  1 → availableMinutes = days * window + (days - 1) * (1440 - window - 180)
 * 其中 1440 = 24 小时，180 = 每天扣掉的睡眠 3 小时（夜里剩余时间可自由支配）。
 * days 非法（0 / NaN）时按 1 天；window ≤ 0 / NaN 时按 60 分钟兜底。
 */
function dailyAvailableMinutes(windowMinutes: number, days: number): number {
  const safeWindow = windowMinutes > 0 ? windowMinutes : FALLBACK_WINDOW_MINUTES;
  const safeDays = normalizeDays(days) || 1;
  if (safeDays === 1) return safeWindow;
  const overnightMinutes = MINUTES_PER_DAY - safeWindow - DAILY_SLEEP_MINUTES;
  return safeDays * safeWindow + (safeDays - 1) * overnightMinutes;
}

/** 让 availableMinutes ≥ requiredMinutes 的最小天数（先按每天「净增」时间解出，再逐个校正） */
function minimalDaysFor(requiredMinutes: number, windowMinutes: number): number | null {
  const safeWindow = windowMinutes > 0 ? windowMinutes : FALLBACK_WINDOW_MINUTES;
  const perDayGain = safeWindow + (MINUTES_PER_DAY - safeWindow - DAILY_SLEEP_MINUTES);
  let days = perDayGain > 0 ? Math.ceil(requiredMinutes / perDayGain) : MAX_SUGGESTED_DAYS;
  days = Math.min(MAX_SUGGESTED_DAYS, Math.max(1, days));
  // 净增时间可能 ≤ 0（窗口极短时），上面的解不一定成立，这里逐个校正到真正满足
  while (days < MAX_SUGGESTED_DAYS && dailyAvailableMinutes(safeWindow, days) < requiredMinutes) {
    days += 1;
  }
  return dailyAvailableMinutes(safeWindow, days) >= requiredMinutes ? days : null;
}

// ---------------------------------------------------------------------------
// 通勤腿：优先用调用方传入的数据，缺失时才直线估算兜底
// ---------------------------------------------------------------------------

/** 单段兜底估算：坐标非法返回 0，异常一律吞掉 */
function estimateLegMinutes(a: GeoPoint, b: GeoPoint, params: PlanParams): LegInfo {
  if (!isValidGeoPoint(a) || !isValidGeoPoint(b)) return { minutes: 0, km: 0 };
  try {
    const leg = estimateTravel(a, b, params.travelMode);
    return { minutes: finiteOr(leg.minutes, 0), km: finiteOr(leg.km, 0) };
  } catch {
    return { minutes: 0, km: 0 };
  }
}

/**
 * 一段通勤的耗时 / 里程：
 * 调用方给了 legMinutes / legKm 且是有限数就直接采信；
 * 缺哪一项就补哪一项——补算全部走同一次直线估算，不做重复计算。
 */
function legInfoAt(
  index: number,
  a: GeoPoint,
  b: GeoPoint,
  legMinutes: readonly number[],
  legKm: readonly number[],
  params: PlanParams,
): LegInfo {
  const givenMinutes = legMinutes[index];
  const givenKm = legKm[index];
  const needMinutes = !Number.isFinite(givenMinutes);
  const needKm = !Number.isFinite(givenKm);
  if (!needMinutes && !needKm) {
    return { minutes: givenMinutes, km: givenKm };
  }
  const fallback = estimateLegMinutes(a, b, params);
  return {
    minutes: needMinutes ? fallback.minutes : givenMinutes,
    km: needKm ? fallback.km : givenKm,
  };
}

/**
 * 展开成「出发地 → 餐厅1 → … → 餐厅n」的逐段信息，长度 = 餐厅数。
 * 数组入参不是数组（脏数据）时按空数组处理；坐标非法的段按 0 分钟 / 0km 处理。
 */
function computeLegs(input: FeasibilityInput): LegInfo[] {
  const restaurants = input.restaurants;
  const legMinutes = Array.isArray(input.legMinutes) ? input.legMinutes : [];
  const legKm = Array.isArray(input.legKm) ? input.legKm : [];
  const points: GeoPoint[] = [input.origin, ...restaurants];
  const legs: LegInfo[] = [];
  for (let i = 0; i < restaurants.length; i += 1) {
    legs.push(legInfoAt(i, points[i], points[i + 1], legMinutes, legKm, input.params));
  }
  return legs;
}

// ---------------------------------------------------------------------------
// 可执行动作
// ---------------------------------------------------------------------------

/**
 * 移除候选的排序（供"太多了"类问题挑选建议移除哪几家）。
 *
 * **不再按 priority（必去 / 想去 / 可选）排序** —— 用户明确要求这三个只是标签、
 * 不影响任何程序行为。改为「按给定顺序从后往前」：
 * 顺序本身是按「通勤最少」排出来的，末尾几家通常最不顺路、最适合砍掉，
 * 而且结果完全可预测、与标签无关。
 */
function sortByRemovability(
  restaurants: readonly FeasibilityRestaurant[],
): FeasibilityRestaurant[] {
  return [...restaurants].reverse();
}

/** 生成「移除餐厅」动作 */
function removalActions(restaurants: readonly FeasibilityRestaurant[]): FeasibilityAction[] {
  return restaurants.map((restaurant) => ({
    kind: 'removeRestaurant' as const,
    restaurantId: restaurant.id,
    label: `移除「${restaurant.name}」`,
  }));
}

/** 改乘城际交通的动作 */
function intercityActions(): FeasibilityAction[] {
  return [
    { kind: 'setIntercity', label: '改乘高铁', patch: { intercity: 'rail' } },
    { kind: 'setIntercity', label: '改乘飞机', patch: { intercity: 'flight' } },
  ];
}

/**
 * 供「太多了」类问题使用的移除候选：最多 limit 条，**与 priority 标签无关**。
 * 返回空数组表示不推荐移除任何一家（此时只给 message，不给按钮）。
 */
function removalCandidates(
  restaurants: readonly FeasibilityRestaurant[],
  limit: number,
): FeasibilityRestaurant[] {
  return sortByRemovability(restaurants).slice(0, Math.max(0, limit));
}

/** 规则 3 用的移除候选：优先 optional，其次 want（同样避免直接砍 must） */
function timeReliefCandidates(
  restaurants: readonly FeasibilityRestaurant[],
  limit: number,
): FeasibilityRestaurant[] {
  return removalCandidates(restaurants, limit);
}

// ---------------------------------------------------------------------------
// 营业时间判定
// ---------------------------------------------------------------------------

/** 两个闭区间是否有交集（含 tolerance 容差） */
function intervalsTouch(
  aStart: number,
  aEnd: number,
  bStart: number,
  bEnd: number,
): boolean {
  return aStart <= bEnd + BOUNDARY_TOLERANCE_MINUTES && bStart <= aEnd + BOUNDARY_TOLERANCE_MINUTES;
}

/**
 * 营业时段是否与 [windowStart, windowEnd] 有交集。
 * hours 缺失 / 空数组 / 全部无法解析 → 视为全天营业，返回 true（不判）。
 * 跨夜营业（open > close，例如 22:00-02:00）拆成两段处理。
 */
function hoursIntersectWindow(
  hours: readonly OpenHour[] | undefined,
  windowStart: number,
  windowEnd: number,
): boolean {
  if (!Array.isArray(hours) || hours.length === 0) return true;
  let anyParsed = false;
  for (const hour of hours) {
    const open = safeToMinutes(hour?.open);
    const close = safeToMinutes(hour?.close);
    if (open === null || close === null) continue;
    anyParsed = true;
    if (open <= close) {
      if (intervalsTouch(windowStart, windowEnd, open, close)) return true;
    } else {
      // 跨夜：当天 [open, 24:00] 与次日 [00:00, close] 两段各自判断
      if (intervalsTouch(windowStart, windowEnd, open, MINUTES_PER_DAY)) return true;
      if (intervalsTouch(windowStart, windowEnd, 0, close)) return true;
    }
  }
  return anyParsed ? false : true;
}

/** 营业时段文案，最多展示 3 段 */
function hoursText(hours: readonly OpenHour[] | undefined): string {
  if (!Array.isArray(hours) || hours.length === 0) return '全天营业';
  const parts: string[] = [];
  for (const hour of hours.slice(0, 3)) {
    const open = typeof hour?.open === 'string' ? hour.open : '?';
    const close = typeof hour?.close === 'string' ? hour.close : '?';
    parts.push(`${open}-${close}`);
  }
  return parts.join('、');
}

// ---------------------------------------------------------------------------
// 城际估算
// ---------------------------------------------------------------------------

/** estimateIntercity 结果消毒：字段不全 / 非有限数一律返回 null，绝不把脏数据塞进报告 */
function sanitizeIntercityLeg(leg: IntercityLeg | undefined | null): IntercityLeg | null {
  if (
    leg == null ||
    (leg.mode !== 'rail' && leg.mode !== 'flight') ||
    typeof leg.fromCity !== 'string' ||
    typeof leg.toCity !== 'string' ||
    typeof leg.summary !== 'string' ||
    !Number.isFinite(leg.km) ||
    !Number.isFinite(leg.minutes) ||
    !Number.isFinite(leg.estimatedFare)
  ) {
    return null;
  }
  return leg;
}

/**
 * 跨城时估算「出发地城市 → 距出发点最远的那个异地城市」。
 * 同城 / 坐标非法 / 估算抛异常一律返回 null（绝不抛出）。
 */
function computeIntercity(
  input: FeasibilityInput,
  originCity: string,
  crossCity: boolean,
): IntercityLeg | null {
  if (!crossCity) return null;
  const origin = input.origin;
  if (!isValidGeoPoint(origin)) return null;

  // 选「离出发点最远」的异地城市：取该城市里离出发点最近的一家餐厅做代表
  let farthestCity: string | null = null;
  let farthestKm = -1;
  for (const restaurant of input.restaurants) {
    const city = normalizeCityName(restaurant?.city);
    // 无法识别城市的餐厅无法定位「异地」，不参与最远城市选择
    if (city === null || city === originCity) continue;
    if (!isValidGeoPoint(restaurant)) continue;
    const km = haversineKm(origin, restaurant);
    if (Number.isFinite(km) && km > farthestKm) {
      farthestKm = km;
      farthestCity = city;
    }
  }
  if (farthestCity === null) return null;

  const representative = input.restaurants.find(
    (restaurant) =>
      normalizeCityName(restaurant?.city) === farthestCity && isValidGeoPoint(restaurant),
  );
  if (representative === undefined) return null;

  const preferred = input.params?.intercity;
  const intercityMode: IntercityMode | null =
    preferred === 'rail' || preferred === 'flight' ? preferred : null;
  const days = normalizeDays(input.params?.days) || 1;

  try {
    const leg = estimateIntercity(
      { lat: origin.lat, lng: origin.lng, city: originCity },
      { lat: representative.lat, lng: representative.lng, city: farthestCity },
      { prefer: intercityMode, days },
    );
    return sanitizeIntercityLeg(leg);
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// 对外函数
// ---------------------------------------------------------------------------

/**
 * 评估一次行程是否合理，并给出可直接渲染成按钮的调整建议。
 *
 * 判定顺序：规则 1（餐厅过多）→ 规则 2（跨城过多）→ 规则 3（时间不够）→ 各类提示。
 * `ok` 为 true 表示「没有任何 blocker」，此时 warning / info 仍可能非空。
 */
export function assessFeasibility(input: FeasibilityInput): FeasibilityReport {
  const restaurants: readonly FeasibilityRestaurant[] = Array.isArray(input?.restaurants)
    ? input.restaurants
    : [];
  const params: PlanParams = input.params;

  // ---- 基础统计：N / M / 时间窗 / 通勤 / 停留 ----
  const addressCount = restaurants.length + 1;
  const citySummary = summarizeCities(restaurants, input.origin?.label ?? '');
  const window = resolveWindow(params);
  const days = normalizeDays(params?.days) || 1;

  const legs = computeLegs(input);
  let commuteMinutes = 0;
  let maxLegKm = 0;
  for (const leg of legs) {
    commuteMinutes += leg.minutes;
    if (leg.km > maxLegKm) maxLegKm = leg.km;
  }
  commuteMinutes = finiteOr(commuteMinutes, 0);

  const stayMinutes = restaurants.reduce(
    (sum, restaurant) => sum + finiteOr(restaurant?.stayMinutes, DEFAULT_STAY_MINUTES),
    0,
  );

  const requiredMinutes = finiteOr(commuteMinutes + stayMinutes, 0);
  const availableMinutes = dailyAvailableMinutes(window.windowMinutes, days);
  const crossCityThreshold = Math.min(addressCount, CROSS_CITY_THRESHOLD_CAP);

  const issues: FeasibilityIssue[] = [];

  // ---- 时间窗非法：先补一条 blocker，避免「窗口无法计算」被静默忽略 ----
  if (window.invalid) {
    issues.push({
      level: 'blocker',
      code: 'INVALID_TIME_WINDOW',
      message:
        `每日可用时段不合法（开始 ${timeText(params?.startTime, window.startMinutes)} → ` +
        `结束 ${timeText(params?.endTime, window.endMinutes)}），已按 ${FALLBACK_WINDOW_MINUTES} ` +
        `分钟兜底计算，请重新设置。`,
      actions: [
        {
          kind: 'setTimeWindow',
          label: `把时间放宽到 ${SUGGESTED_START_TIME}-${SUGGESTED_END_TIME}`,
          patch: { startTime: SUGGESTED_START_TIME, endTime: SUGGESTED_END_TIME },
        },
      ],
    });
  }

  // ---- 三条「不合理」规则 ----
  // 空数组（一家店都没选）是退化情形：N = 1 会让规则 2 的阈值 min(N,3) 变成 1，
  // 从而把「没有任何餐厅」这种本来就可生成的行程判成不合理，因此三条规则整体跳过。
  // 时段非法仍然单独报 blocker（上面的 INVALID_TIME_WINDOW）。
  if (restaurants.length > 0) {
    // ---- 规则 1：餐厅 ≥ 7 家 → 不合理 ----
    if (restaurants.length >= MAX_RESTAURANT_COUNT) {
      const removable = removalCandidates(restaurants, MAX_REMOVE_ACTIONS_FOR_TOO_MANY);
      issues.push({
        level: 'blocker',
        code: 'TOO_MANY_RESTAURANTS',
        message:
          `当前 ${restaurants.length} 家餐厅，超过 ${MAX_RESTAURANT_COUNT - 1} 家上限` +
          `（地址总数 ${addressCount} 个，含出发地），一天之内无法逛完，请至少移除 ` +
          `${restaurants.length - (MAX_RESTAURANT_COUNT - 1)} 家。`,
        actions: removalActions(removable),
      });
    }

    // ---- 规则 2：不同城个数 ≥ min(N, 3) → 不合理 ----
    // 注意：**选不选城际交通与这条规则无关**（用户已明确）。
    // 所以这里不再提供「改乘高铁 / 改乘飞机」按钮 —— 那会让人误以为选了就能通过判定，
    // 而实际上判定只看不同城个数。城际交通的建议放在下面的 NEED_INTERCITY 警告里，
    // 两者互不影响：警告可以提示你去选，选完这条 blocker 依然存在。
    if (citySummary.distinctCityCount >= crossCityThreshold) {
      const actions: FeasibilityAction[] = [];
      if (restaurants.length >= 3) {
        actions.push(
          ...removalActions(removalCandidates(restaurants, MAX_REMOVE_ACTIONS_FOR_CROSS_CITY)),
        );
      }
      issues.push({
        level: 'blocker',
        code: 'CROSS_CITY',
        message:
          `地址总数 ${addressCount} 个，涉及 ${citySummary.distinctCityCount} 个不同城市` +
          `（${citySummary.cities.join('、')}），达到阈值 ${crossCityThreshold}。` +
          `此判定只看「不同城个数」，与是否选择城际交通无关；` +
          `要减少异地餐厅，或在弹窗里点「仍然生成」继续出方案。`,
        actions,
      });
    }

    // ---- 规则 3：可用时间 < 需要时间 → 不合理 ----
    if (availableMinutes < requiredMinutes) {
      const actions: FeasibilityAction[] = [];
      const suggestedDays = minimalDaysFor(requiredMinutes, window.windowMinutes);
      if (suggestedDays !== null && suggestedDays > days) {
        actions.push({
          kind: 'addDays',
          label: `把天数改为 ${suggestedDays} 天`,
          patch: { days: suggestedDays },
        });
      }
      if (window.windowMinutes < SUGGESTED_WINDOW_MINUTES) {
        actions.push({
          kind: 'setTimeWindow',
          label: `把时间放宽到 ${SUGGESTED_START_TIME}-${SUGGESTED_END_TIME}`,
          patch: { startTime: SUGGESTED_START_TIME, endTime: SUGGESTED_END_TIME },
        });
      }
      actions.push(
        ...removalActions(timeReliefCandidates(restaurants, MAX_REMOVE_ACTIONS_FOR_TIME)),
      );
      issues.push({
        level: 'blocker',
        code: 'TIME_NOT_ENOUGH',
        message:
          `时间不够：通勤 ${fmtMinutes(commuteMinutes)} + 停留 ${fmtMinutes(stayMinutes)} = ` +
          `需要 ${fmtMinutes(requiredMinutes)}，但按 ${days} 天（每天 ` +
          `${timeText(params?.startTime, window.startMinutes)}-` +
          `${timeText(params?.endTime, window.endMinutes)}）只有 ${fmtMinutes(availableMinutes)} 可用。`,
        actions,
      });
    }

    // ---- 规则 4：自动计算的预算 ≥ 自主设置的总预算 → 不合理 ----
    // 口径与「统计」页一致：Σ(每家店人均 × 同行人数)。
    // 用户明确要求：**只给提示、不给一键按钮**，所以 actions 固定为空数组。
    const peopleCount = Math.max(1, finiteOr(params?.peopleCount, 1));
    const computedBudget = restaurants.reduce(
      (sum, item) => sum + Math.max(0, finiteOr(item?.avgPrice ?? 0, 0)) * peopleCount,
      0,
    );
    const budgetLimit = Math.max(0, finiteOr(params?.totalBudget, 0));
    if (computedBudget >= budgetLimit) {
      issues.push({
        level: 'blocker',
        code: 'BUDGET_NOT_ENOUGH',
        message:
          `预算不足：按当前餐厅算，合计约 ¥${Math.round(computedBudget)}` +
          `（${restaurants.length} 家 × 同行 ${peopleCount} 人），` +
          `已达到或超过你设置的总预算 ¥${Math.round(budgetLimit)}。` +
          `请提高总预算，或减少餐厅数量。`,
        actions: [],
      });
    }
  }

  // ---- 非阻断 1：营业时间与时间窗完全没有交集（warning） ----
  for (const restaurant of restaurants) {
    const hours = restaurant?.hours;
    if (!Array.isArray(hours) || hours.length === 0) continue; // 缺失 = 全天营业，不判
    if (hoursIntersectWindow(hours, window.startMinutes, window.endMinutes)) continue;
    issues.push({
      level: 'warning',
      code: 'CLOSED_IN_WINDOW',
      message:
        `「${restaurant.name}」营业时间 ${hoursText(hours)}，与你的时间窗 ` +
        `${timeText(params?.startTime, window.startMinutes)}-` +
        `${timeText(params?.endTime, window.endMinutes)} 没有交集，去的时候可能关着门。`,
      actions: removalActions([restaurant]),
    });
  }

  // ---- 非阻断 2：步行模式下单段超过 8km（warning） ----
  if (params?.travelMode === 'walk' && maxLegKm > WALK_TOO_FAR_KM) {
    issues.push({
      level: 'warning',
      code: 'TOO_FAR_TO_WALK',
      message:
        `步行模式下最长一段约 ${maxLegKm.toFixed(1)}km，超过 ${WALK_TOO_FAR_KM}km 的合理步行距离，` +
        `建议换交通方式。`,
      actions: [
        { kind: 'setMode', label: '改为驾车', patch: { travelMode: 'drive' } },
        { kind: 'setMode', label: '改为公共交通', patch: { travelMode: 'transit' } },
      ],
    });
  }

  // ---- 非阻断 3：存在跨城但未选择城际方式（warning） ----
  const intercityPreference = params?.intercity;
  if (
    citySummary.crossCity &&
    (intercityPreference === null || intercityPreference === undefined)
  ) {
    issues.push({
      level: 'warning',
      code: 'NEED_INTERCITY',
      message:
        `行程涉及 ${citySummary.distinctCityCount} 个城市（${citySummary.cities.join('、')}），` +
        `还没有选择城际交通方式，建议先选高铁或飞机再生成方案。`,
      actions: intercityActions(),
    });
  }

  // ---- 非阻断 4：单日站点偏多（info） ----
  const stopsPerDay = Math.ceil(restaurants.length / days);
  if (stopsPerDay > MAX_STOPS_PER_DAY) {
    issues.push({
      level: 'info',
      code: 'MANY_STOPS_PER_DAY',
      message:
        `${restaurants.length} 家餐厅分 ${days} 天，平均每天 ${stopsPerDay} 家，` +
        `超过每天 ${MAX_STOPS_PER_DAY} 家的参考值，行程可能偏紧。`,
      actions: [],
    });
  }

  const stats: FeasibilityStats = {
    restaurantCount: restaurants.length,
    addressCount,
    cities: citySummary.cities,
    distinctCityCount: citySummary.distinctCityCount,
    crossCityThreshold,
    commuteMinutes,
    stayMinutes,
    requiredMinutes,
    availableMinutes,
    days,
    windowMinutes: window.windowMinutes,
  };

  return {
    ok: !issues.some((issue) => issue.level === 'blocker'),
    issues,
    intercity: computeIntercity(input, citySummary.originCity, citySummary.crossCity),
    stats,
  };
}
