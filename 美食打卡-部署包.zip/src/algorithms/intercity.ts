/**
 * 城际交通估算模型（纯函数：不访问网络、不导入 React、不读写 localStorage）
 *
 * ============================================================================
 * 【极其重要的前提 · 必读】
 * 本项目拿不到真实的车次 / 时刻表 / 航班数据：
 *   - 12306 没有公开 API；
 *   - 高德 / 百度不提供城际铁路与航班的路径规划；
 *   - 航旅类（航班班期、运价、余票）数据均为商业授权数据。
 *
 * 因此本文件实现的是**可解释的估算模型，不是真实班次**。所有输出都必须被展示为
 * 「估算值」：source 一律为 'estimate'，summary 与界面文案都要体现「约」。
 *
 * 地区规则差异（港澳与台湾不同，不可一刀切）：
 *   - 台湾 ↔ 任何非台湾：强制航空（两岸无铁路直连），summary 会说明；
 *   - 内地 ↔ 香港：可走铁路，按大陆口径判档，注明「经广深港高铁西九龙站」；
 *   - 内地 ↔ 澳门：无铁路直达，按铁路估算但注明「需经珠海/广州换乘」，>1500km 转航空；
 *   - 香港 ↔ 澳门：按铁路口径估算，注明「经港珠澳大桥或渡轮」。
 *
 * 估算口径（模型假设，均为工程近似值，非任何官方公布数据）：
 *   - 里程：球面大圆距离（haversineKm）× 线路绕行系数，弥补铁路 / 航路不会走直线；
 *   - 时间：里程 ÷ 名义区间速度（已含中途停站） + 固定附加时间（进出站 / 候车 / 安检 / 取行李）；
 *   - 票价：里程 × 单位票价系数（民航另加机建 + 燃油固定费）。
 *
 * 已知误差来源（使用时请向用户说明）：
 *   - 绕行系数是单一常数，山区 / 海岛 / 需绕行海湾的线路会低估；
 *   - 速度是分档名义值，真实车次在不同线路上的均速差异很大；
 *   - 票价系数按二等座 / 经济舱量级取整，与具体车次、舱位、折扣无关；
 *   - 无车次频次、发车时刻、中转与换乘等待时间，因此不能用于行程排点。
 * 本模型适合「可行性判断与粗略预算」，不适合出行决策前的最终比价与排点。
 * ============================================================================
 */

import type { IntercityLeg, IntercityMode, RailClass } from '../types/planning';
import { CITY_ALIASES, CITY_POINTS, type CityPoint } from '../data/intercityData';
import { haversineKm } from './coords';
import { fmtMinutes, fmtMoney } from '../utils/format';

// ---------------------------------------------------------------------------
// 具名常量（模型参数，改动请同步更新文件头的口径说明）
// ---------------------------------------------------------------------------

/** 线路绕行系数：铁路 / 航路里程相对球面大圆距离的经验放大倍数 */
const ROUTE_DETOUR_FACTOR = 1.25;

/** 里程保留的小数位 */
const KM_DECIMALS = 1;

/** 大陆内部：不超过该里程优先动车（emu） */
const RAIL_CLASS_EMU_MAX_KM = 300;

/** 大陆内部：超过动车档但不超过该里程优先高铁（hsr） */
const RAIL_CLASS_HSR_MAX_KM = 1500;

/** 台湾岛内：不超过该里程优先铁路，否则倾向航空 */
const TAIWAN_ISLAND_RAIL_MAX_KM = 250;

/** 行程天数低于该值且里程较长时，在 summary 里提示增加天数 */
const SHORT_TRIP_DAYS = 3;

/** 区间速度（km/h，已含中途停站的名义均速） */
const SPEED_HSR_KMH = 250;
/** 动车区间速度（km/h） */
const SPEED_EMU_KMH = 180;
/** 普速列车区间速度（km/h） */
const SPEED_NORMAL_KMH = 90;
/** 民航巡航速度（km/h） */
const SPEED_FLIGHT_KMH = 700;

/** 铁路固定附加时间（分钟）：进出站 + 候车 */
const RAIL_FIXED_MINUTES = 40;
/** 民航固定附加时间（分钟）：提前到机场 + 安检 + 提取行李 */
const FLIGHT_FIXED_MINUTES = 150;

/** 高铁票价系数（元/km，单人，二等座量级） */
const FARE_HSR_PER_KM = 0.45;
/** 动车票价系数（元/km，单人，二等座量级） */
const FARE_EMU_PER_KM = 0.3;
/** 普速列车票价系数（元/km，单人，硬座量级） */
const FARE_NORMAL_PER_KM = 0.15;
/** 民航票价系数（元/km，单人，经济舱量级） */
const FARE_FLIGHT_PER_KM = 0.6;
/** 民航固定附加费（元）：机场建设费 + 燃油附加费 */
const FARE_FLIGHT_FIXED = 100;

/** 无法识别城市时的占位名 */
const PLACEHOLDER_FROM = '起点';
const PLACEHOLDER_TO = '终点';

/** summary 尾注 */
const NOTE_CROSS_STRAIT = '两岸需航空或航运，本项目按航空估算';
const NOTE_HONGKONG_RAIL = '经广深港高铁西九龙站';
const NOTE_MACAU_TRANSFER = '需经珠海/广州换乘';
const NOTE_HK_MACAU = '经港珠澳大桥或渡轮';
const NOTE_SHORT_TRIP = '（建议行程 ≥ 3 天）';

/** 在字符串中查找但未命中时使用的哨兵下标 */
const NOT_FOUND = Number.POSITIVE_INFINITY;

// ---------------------------------------------------------------------------
// 内部工具
// ---------------------------------------------------------------------------

/** 城市名 → 城市点（含台湾 / 港澳标记），用于判定两岸与港澳规则 */
const CITY_POINT_BY_NAME: Map<string, CityPoint> = new Map(
  CITY_POINTS.map((p): [string, CityPoint] => [p.city, p]),
);

/** 别名表按长度降序，保证同一起点上优先取更长的别名 */
const CITY_ALIAS_ENTRIES: ReadonlyArray<readonly [string, string]> = Object.entries(
  CITY_ALIASES,
).sort((a, b) => b[0].length - a[0].length);

/** 城市名按长度降序，配合「最靠前出现位置」实现最长匹配的稳定优先级 */
const CITY_NAMES_BY_LENGTH_DESC: readonly string[] = CITY_POINTS.map((p) => p.city).sort(
  (a, b) => b.length - a.length,
);

/** 城市名是否为台湾地区城市 */
function isTaiwanCity(city: string): boolean {
  return CITY_POINT_BY_NAME.get(city)?.taiwan === true;
}

/** 城市名是否为香港 / 澳门特别行政区 */
function isSarCity(city: string): boolean {
  return CITY_POINT_BY_NAME.get(city)?.sar === true;
}

/** 按坐标找最近城市（仅在调用方未给出 city 且地址无法解析时兜底） */
function nearestCityByCoords(lat: number, lng: number): string | null {
  let best: string | null = null;
  let bestKm = Number.POSITIVE_INFINITY;
  for (const point of CITY_POINTS) {
    const km = haversineKm({ lat, lng }, point);
    if (km < bestKm) {
      bestKm = km;
      best = point.city;
    }
  }
  return best;
}

/**
 * 解析一端的城市名：显式 city 优先，其次按坐标取最近城市，最后用占位名。
 *
 * 说明：本函数的入参只有坐标与可选城市名，**没有地址字符串**，所以这里无法调用
 * guessCity —— 地址识别由上游（拿到地址的一方）先调用 guessCity 完成，结果放进
 * city 字段传进来即可。
 */
function resolveCity(
  city: string | undefined,
  lat: number,
  lng: number,
  fallback: string,
): string {
  if (city !== undefined && city !== '') return city;
  const nearest = nearestCityByCoords(lat, lng);
  return nearest ?? fallback;
}

/** 按 railClass 取区间速度（km/h） */
function railSpeedKmh(railClass: RailClass): number {
  if (railClass === 'hsr') return SPEED_HSR_KMH;
  if (railClass === 'emu') return SPEED_EMU_KMH;
  return SPEED_NORMAL_KMH;
}

/** 按 railClass 取单位票价系数（元/km） */
function railFarePerKm(railClass: RailClass): number {
  if (railClass === 'hsr') return FARE_HSR_PER_KM;
  if (railClass === 'emu') return FARE_EMU_PER_KM;
  return FARE_NORMAL_PER_KM;
}

/**
 * 大陆内部按里程判定铁路分档。
 * 本模型只在存在高铁网络的线路上估算，因此 300km 以上统一给 hsr；
 * RailClass 的 'normal'（普速）分档保留给调用方显式指定，本函数不产出。
 */
function mainlandRailClass(km: number): RailClass {
  return km <= RAIL_CLASS_EMU_MAX_KM ? 'emu' : 'hsr';
}

/**
 * 大陆口径的方式判定：≤300km 动车、300~1500km 高铁、>1500km 默认航空。
 * 香港 / 澳门 ↔ 内地按同一把尺子处理（香港有广深港高铁直达，澳门需换乘但同样走铁路）。
 */
function mainlandMode(km: number): { mode: IntercityMode; railClass?: RailClass } {
  if (km <= RAIL_CLASS_EMU_MAX_KM) return { mode: 'rail', railClass: 'emu' };
  if (km <= RAIL_CLASS_HSR_MAX_KM) return { mode: 'rail', railClass: 'hsr' };
  return { mode: 'flight' };
}

/** 一端与另一端的关系，决定套用哪套城际规则 */
type RouteKind =
  /** 台湾 ↔ 任何非台湾（内地或港澳）：只能航空，硬规则 */
  | 'cross-strait'
  /** 台湾岛内：台铁 / 高铁与岛内航线二选一 */
  | 'taiwan-internal'
  /** 香港 ↔ 澳门：距离极近，按铁路（大桥 / 渡轮）估算 */
  | 'hk-macau'
  /** 内地 ↔ 香港：可按大陆口径走铁路，注明西九龙站 */
  | 'mainland-hongkong'
  /** 内地 ↔ 澳门：按铁路处理，但必须注明需经珠海 / 广州换乘 */
  | 'mainland-macau'
  /** 内地内部：标准大陆规则 */
  | 'mainland'
  /** 港澳 ↔ 台湾已在 cross-strait 覆盖，不会走到这里，仅作兜底 */
  | 'other';

/** 依据城市标记判定关系类型（台湾优先，因为台湾规则是硬约束） */
function routeKindOf(fromCity: string, toCity: string): RouteKind {
  const fromTaiwan = isTaiwanCity(fromCity);
  const toTaiwan = isTaiwanCity(toCity);
  if (fromTaiwan !== toTaiwan) return 'cross-strait';
  if (fromTaiwan && toTaiwan) return 'taiwan-internal';

  const fromSar = isSarCity(fromCity);
  const toSar = isSarCity(toCity);
  if (fromSar !== toSar) {
    // 一端是港澳、另一端是内地：香港可直达，澳门需换乘
    const sarName = fromSar ? fromCity : toCity;
    return sarName === '澳门' ? 'mainland-macau' : 'mainland-hongkong';
  }
  if (fromSar && toSar) {
    // 同城（理论上已被上层过滤）或香港 ↔ 澳门
    return fromCity === toCity ? 'mainland' : 'hk-macau';
  }
  return 'mainland';
}

/** 各关系类型下方式与铁路分档的默认值，以及供 summary 使用的说明文案 */
function basePlan(kind: RouteKind, km: number): {
  mode: IntercityMode;
  railClass?: RailClass;
  /** summary 尾注：直达 / 换乘说明 */
  baseLabel?: string;
  /** 是否覆盖 summary 的方式名词（香港↔澳门按公路 / 渡轮，不宜称「动车」） */
  hkMacau?: boolean;
} {
  if (kind === 'cross-strait') {
    // 两岸无铁路直连，只能航空（或航运），这里按航空估算
    return { mode: 'flight', baseLabel: NOTE_CROSS_STRAIT };
  }
  if (kind === 'taiwan-internal') {
    // 台湾岛内：≤250km 走铁路，否则倾向岛内航空
    if (km <= TAIWAN_ISLAND_RAIL_MAX_KM) {
      return { mode: 'rail', railClass: km <= RAIL_CLASS_EMU_MAX_KM ? 'emu' : 'hsr' };
    }
    return { mode: 'flight' };
  }
  if (kind === 'hk-macau') {
    // 港珠澳大桥 / 渡轮：这里沿用铁路口径的里程-时间-票价模型，但实际不是铁路
    return { mode: 'rail', railClass: 'emu', baseLabel: NOTE_HK_MACAU, hkMacau: true };
  }
  if (kind === 'mainland-hongkong') {
    // 广深港高铁西九龙站可直达内地多地，按大陆规则正常判
    const plan = mainlandMode(km);
    return plan.mode === 'rail' ? { ...plan, baseLabel: NOTE_HONGKONG_RAIL } : plan;
  }
  if (kind === 'mainland-macau') {
    // 澳门无铁路直达，需经珠海 / 广州换乘；超 1500km 仍按大陆规则默认航空
    const plan = mainlandMode(km);
    return plan.mode === 'rail' ? { ...plan, baseLabel: NOTE_MACAU_TRANSFER } : plan;
  }
  return mainlandMode(km);
}

/** 里程展示统一 1 位小数 */
function formatKm(km: number): string {
  return km.toFixed(KM_DECIMALS);
}

/**
 * 在城市名表中做最长匹配：取在地址里**出现位置最靠前**的城市名。
 *
 * 候选表已按城市名长度降序排列，因此同一下标只会被先到的（即更长的）名字占据，
 * 无需额外比较长度，天然满足「最长匹配」。
 */
function findCityName(address: string): string | null {
  let best: string | null = null;
  let bestIndex = NOT_FOUND;
  for (const city of CITY_NAMES_BY_LENGTH_DESC) {
    const index = address.indexOf(city);
    if (index === -1) continue;
    if (index < bestIndex) {
      bestIndex = index;
      best = city;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// 对外函数 1：地址 → 城市
// ---------------------------------------------------------------------------

/**
 * 从中文地址中识别城市名。
 *
 * 判定顺序（每一步一旦命中即返回）：
 *   1. 城市别名表 CITY_ALIASES（支持常见简称、雅称、旧称、'XX市' 全称写法）；
 *   2. CITY_POINTS 的城市名；
 *   3. 兜底：匹配「XX市」里的两到三个汉字。
 *
 * 「最靠前出现位置」原则：同一地址里可能同时出现多个城市名，取在字符串中**下标最小**
 * 的那个。因此「上海市南京路」命中下标 0 的「上海」，而不是下标 3 的「南京」。
 * 同一下标命中多个别名 / 城市名时，取更长的那个（最长匹配）。
 *
 * 纯函数、不访问网络。
 *
 * @returns 标准城市名；识别不出返回 null
 */
/**
 * 不可能出现在城市名里的字（虚词 / 地址专用字）。
 * 用于校验兜底规则 3 从任意地址里"猜"出来的名字：
 * 实测「某条说不出城市的路」会被贪婪匹配成城市「**不出城**」，
 * 而且它排在坐标兜底之前，会让真实餐厅因为地址怪异而被分错城市。
 */
const NOT_IN_CITY_NAME = /[不的说了是我你他她它们这那有没去到在好大小多少怎么路街号楼层室区县镇乡村]/;

export function guessCity(address: string): string | null {
  if (address === '') return null;

  // 1) 别名优先：取整体最靠前的别名
  let bestCity: string | null = null;
  let bestIndex = NOT_FOUND;
  let bestLength = 0;
  for (const [alias, city] of CITY_ALIAS_ENTRIES) {
    const index = address.indexOf(alias);
    if (index === -1) continue;
    if (index < bestIndex || (index === bestIndex && alias.length > bestLength)) {
      bestIndex = index;
      bestLength = alias.length;
      bestCity = city;
    }
  }
  if (bestCity !== null) return bestCity;

  // 2) 城市名最长匹配：按出现位置最靠前判定，同位取更长者
  const namedCity = findCityName(address);
  if (namedCity !== null) return namedCity;

  // 3) 兜底：任意「XX市」写法（2~3 个汉字 + 市）
  //
  //    ⚠ 这一步**必须校验**，否则会把普通句子切成城市名（见 NOT_IN_CITY_NAME 的注释）。
  //    两条守卫：
  //      ① 名字里不能出现虚词 / 地址专用字；
  //      ② 名字必须出现在地址很靠前的位置（真实地址的"市"基本就在开头几个字内），
  //         或者紧跟在「省 / 自治区 / 特别行政区」之后。
  //    两条都不满足 → 返回 null，交给调用方走坐标兜底。
  const suffixMatch = /([\u4e00-\u9fa5]{2,3})市/.exec(address);
  if (suffixMatch !== null) {
    const name = suffixMatch[1];
    const start = suffixMatch.index;
    const prefix = address.slice(0, start);
    const afterRegion = /(省|自治区|特别行政区)$/.test(prefix);
    if (!NOT_IN_CITY_NAME.test(name) && (afterRegion || start <= 4)) return name;
  }

  return null;
}

// ---------------------------------------------------------------------------
// 对外函数 2：城际段估算
// ---------------------------------------------------------------------------

/**
 * 估算一段城际交通（城市 A → 城市 B）。
 *
 * 业务规则（按优先级，港澳与台湾不同，不可一刀切）：
 *   1. 两岸（台湾 ↔ 任何非台湾，含内地与港澳）：**只能飞机**，硬规则，忽略 opts.prefer，
 *      summary 注明「两岸需航空或航运，本项目按航空估算」；
 *   2. 台湾岛内：里程 ≤ 250km 走 rail，否则倾向 flight；
 *   3. 内地 ↔ 香港：香港有广深港高铁直达，按大陆规则正常判
 *      （≤300 emu / 300~1500 hsr / >1500 flight），铁路时注明「经广深港高铁西九龙站」；
 *   4. 内地 ↔ 澳门：无铁路直达，按 rail 处理但注明「需经珠海/广州换乘」，
 *      >1500km 仍按大陆规则默认 flight；
 *   5. 香港 ↔ 澳门：距离极近，按 rail（港珠澳大桥 / 渡轮）估算，
 *      注明「经港珠澳大桥或渡轮」；
 *   6. 大陆内部：≤300km → rail/emu；300~1500km → rail/hsr；>1500km → 默认 flight；
 *   7. opts.prefer 显式指定 rail / flight 时优先遵从（受规则 1 硬约束）；
 *   8. opts.days < 3 且里程 > 300km 时，方式不变，summary 末尾追加「（建议行程 ≥ 3 天）」。
 *
 * 返回的 km / minutes / estimatedFare 均为估算值，source 恒为 'estimate'。
 */
export function estimateIntercity(
  a: { lat: number; lng: number; city?: string },
  b: { lat: number; lng: number; city?: string },
  opts?: { prefer?: IntercityMode | null; days?: number },
): IntercityLeg {
  const fromCity = resolveCity(a.city, a.lat, a.lng, PLACEHOLDER_FROM);
  const toCity = resolveCity(b.city, b.lat, b.lng, PLACEHOLDER_TO);

  const km = Number((haversineKm(a, b) * ROUTE_DETOUR_FACTOR).toFixed(KM_DECIMALS));

  const prefer = opts?.prefer ?? null;

  // 先按城市标记定位适用规则，再让 prefer 在规则允许的范围内覆盖默认方式
  const kind = routeKindOf(fromCity, toCity);
  const base = basePlan(kind, km);
  // 两岸是硬规则：无论 prefer 是什么都只能航空；其余情形 prefer 可覆盖默认方式
  const mode: IntercityMode = kind === 'cross-strait' ? 'flight' : (prefer ?? base.mode);
  // 分档只在铁路时给出：优先用规则默认分档，否则按里程重算
  const railClass: RailClass | undefined =
    mode === 'rail' ? (base.railClass ?? mainlandRailClass(km)) : undefined;
  // 换乘 / 直达说明只在真的按铁路走时才有意义
  const baseLabel = mode === 'rail' ? base.baseLabel : undefined;

  // 时间与票价：均按选定的方式 / 分档代入具名常量
  let minutes: number;
  let estimatedFare: number;
  if (mode === 'flight') {
    minutes = Math.round((km / SPEED_FLIGHT_KMH) * 60 + FLIGHT_FIXED_MINUTES);
    estimatedFare = Math.round(km * FARE_FLIGHT_PER_KM + FARE_FLIGHT_FIXED);
  } else {
    // railClass 在 mode === 'rail' 时必然已确定
    const effectiveRailClass = railClass ?? mainlandRailClass(km);
    minutes = Math.round((km / railSpeedKmh(effectiveRailClass)) * 60 + RAIL_FIXED_MINUTES);
    estimatedFare = Math.round(km * railFarePerKm(effectiveRailClass));
  }

  const modeLabel =
    mode === 'rail' && base.hkMacau === true ? describeHkMacau() : describeMode(mode, railClass);
  let summary =
    `${modeLabel} · 约 ${fmtMinutes(minutes)} · 里程约 ${formatKm(km)}km · 票价约 ${fmtMoney(
      estimatedFare,
    )}`;
  if (baseLabel !== undefined) {
    summary += ` · ${baseLabel}`;
  }
  const days = opts?.days;
  if (days !== undefined && days < SHORT_TRIP_DAYS && km > RAIL_CLASS_EMU_MAX_KM) {
    summary += NOTE_SHORT_TRIP;
  }

  return {
    mode,
    fromCity,
    toCity,
    km,
    minutes,
    ...(mode === 'rail' && railClass !== undefined ? { railClass } : {}),
    source: 'estimate',
    estimatedFare,
    summary,
  };
}

/** summary 里的方式前缀：如「高铁」「动车」「普速列车」「飞机」 */
function describeMode(mode: IntercityMode, railClass: RailClass | undefined): string {
  if (mode === 'flight') return '飞机';
  if (railClass === 'hsr') return '高铁';
  if (railClass === 'emu') return '动车';
  if (railClass === 'normal') return '普速列车';
  return '铁路';
}

/** 香港 ↔ 澳门实际走公路（港珠澳大桥）或渡轮，summary 里不称「动车」 */
function describeHkMacau(): string {
  return '公路/渡轮';
}
