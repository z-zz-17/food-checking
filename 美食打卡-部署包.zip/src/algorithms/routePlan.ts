/**
 * routePlan —— 逐段通勤解析：默认顺序 + 真实/估算通勤耗时（双模块：同城 / 城际）。
 *
 * ============================================================================
 * ① 双模块（同城 / 城际）的判定与降级顺序
 *
 *    按「出发点 → 餐厅1 → 餐厅2 → … → 餐厅X」逐段独立判定，每段走下面这棵树：
 *
 *      同一段的两端 = 上一站的地址、下一站的地址；
 *      出发点没有 address 字段，用 params.origin.label 当地址文本（originWaypoint）。
 *
 *      isSameCity(上一站, 下一站)?
 *        ├─ 是 → 【同城模块】
 *        │    1) svc.route(a, b, params.travelMode)（串行 + 重试，见 ②）
 *        │         成功 → 采用真实结果：保留 path / segments / summary，
 *        │                source 与 estimated 以服务自报为准
 *        │                （高德真实结果 → 'amap' + estimated:false；
 *        │                  无 Key 的 FallbackRoutingService 会自报 'estimate'，
 *        │                  这时如实标 estimated:true，不能谎报成真实路况）
 *        │         失败 / null → 降级：estimateTravel(a, b, 'walk')
 *        │                → mode:'walk'、source:'estimate'、estimated:true、
 *        │                  segments:[{kind:'walk', label:'步行', minutes, km}]
 *        └─ 否 → 【城际模块】
 *             1) 先试真实数据：svc.route(a, b, params.travelMode)（串行 + 重试）
 *                  非空 且 source === 'amap' 且 segments 里含 bus/subway/rail 类线路
 *                  （即高德确实有这条城际公交/地铁，例如广佛线）
 *                  → 采用它：source:'amap'、estimated:false、保留 path
 *                  （真实线路拿不到真实票价，因此不伪造 intercity 字段）
 *             2) 否则走估算模型：estimateIntercity(a, b, { prefer: params.intercity ?? null,
 *                                                          days: params.days })
 *                  → mode: params.travelMode、minutes/km 取城际模型、
 *                    source:'estimate'、estimated:true、
 *                    segments:[{ kind: 航班 ? 'flight' : 'rail', label: leg.summary, … }]、
 *                    intercity: leg
 *                  → **path 必须留空**：城际铁路 / 航班不在图上画线
 *
 *    任何一步抛错都被就地 try/catch 吃掉并继续走降级路径：本模块**绝不 reject**。
 *
 * ② 为什么不做 N² 预取（QPS 硬约束）
 *    用户的 Key 实测会返回 CUQPS_HAS_EXCEEDED_THE_LIMIT（QPS 超限）。
 *    N 家餐厅的两两矩阵是 N² 段请求（N=12 就是 156 次），必然打爆 QPS；
 *    而行程真正只会走「出发点 → 餐厅1 → … → 餐厅N」这一条链，只有 N+1 段。
 *    因此这里只请求实际顺序上的 N+1 段，并且：
 *      · 串行：并发恒为 1，模块级队列 runExclusive 保证「后台预取」与「生成行程」
 *        并发调用时也不会互相插队；
 *      · 间隔：相邻两次请求的**开始**时间至少相差 REQUEST_GAP_MS = 250ms（≈4 QPS 上限）；
 *      · 重试：单段失败最多重试 2 次，退避 300ms → 900ms，仍失败才降级为估算。
 *
 * ③ 缓存策略
 *    模块级 Map<string, RouteLeg>，键 = `${fromKey}|${toKey}|${mode}|${intercity ?? ''}`：
 *    fromKey / toKey 用餐厅 id，出发点固定 ORIGIN_KEY（'__origin__'）。
 *    「选中餐厅时后台预取」与「点生成行程」共用这一份缓存 → 命中的段**不再发任何请求**。
 *    键里已含 mode 与 intercity，换交通方式 / 换城际方式天然不串味；
 *    但键里**不含出发点的坐标与城市**（出发点一律是 '__origin__' 占位），
 *    所以「换出发点 / 换交通方式 / 换城际方式」之后必须由调用方 clearRouteCache() 清空。
 *    降级后的估算段也会入缓存：重试已经用尽，重复请求只会继续撞 QPS 限制。
 *    缓存命中时返回的是同一个对象引用，调用方请勿修改返回值。
 *
 * 其它约定：不使用 any、不 console.log、不 import React / store。
 * ============================================================================
 */

import type { LegSegment, PlanParams, Restaurant, TravelMode } from '../types';
import type { IntercityLeg, RouteLeg } from '../types/planning';
import { getRoutingService } from '../services/routing';
import { haversineKm } from './coords';
import { estimateIntercity, guessCity } from './intercity';
import { stripFare } from '../utils/text';
import { makeEstimateMatrix } from './planner';
import { MODE_LABEL, estimateTravel } from './travel';
import { nearestNeighbor, twoOpt } from './tsp';

// ---------------------------------------------------------------------------
// 具名常量（阈值集中在这里，改动请同步更新上面的口径说明）
// ---------------------------------------------------------------------------

/**
 * 出发点在矩阵 / 缓存里的固定 key。
 * 必须与 planner.ts 导出的 ORIGIN_KEY（'__origin__'）取值一致；
 * 这里本地定义，避免把 planner.ts 的重构风险引进本文件。
 */
const ORIGIN_KEY = '__origin__';

/**
 * 相邻两次真实请求的最小间隔（毫秒）。
 * 高德 Key 实测会 CUQPS_HAS_EXCEEDED_THE_LIMIT，250ms → 最快 4 次/秒，
 * 给 QPS 限流留出余量，同时不至于把 N+1 段拖得太慢。
 */
const REQUEST_GAP_MS = 250;

/** 重试退避（毫秒）：第 1 次重试等 300ms，第 2 次等 900ms；数组长度即最大重试次数 */
const RETRY_BACKOFF_MS: readonly number[] = [300, 900];

/** 初次请求之外的最大重试次数（= 退避表长度 → 每段最多 3 次请求） */
const MAX_RETRIES = RETRY_BACKOFF_MS.length;

/**
 * 同城判定的兜底阈值（km）：只有「两端至少有一端解析不出城市」时才用直线距离近似判断。
 * 80km 与 algorithms/feasibility.ts 的 SAME_CITY_KM 对齐（≈ 都市圈通勤上限）。
 */
const SAME_CITY_MAX_KM = 80;

/**
 * 城际「真实线路」的判定口径：高德 Transfer 方案里出现这几类分段，
 * 才算「高德确实有这条城际公交/地铁」（例如广佛线）；驾车/步行段不算。
 */
const INTERCITY_TRANSIT_KINDS: readonly LegSegment['kind'][] = ['bus', 'subway', 'rail'];

/** 城际模型没给出可读文案时的兜底标签 */
const INTERCITY_FALLBACK_LABEL = '城际估算';

/**
 * 远距跨城分界（km）：**超过它就不再采用高德公交方案，改用城际估算模型**。
 *
 * 为什么需要这条（实测数据）：
 *   高德的公交规划给出的是「地铁 + 长途汽车 + 换乘等待」，**不含高铁车次**。
 *   广州 → 成都（直线约 1230km）实测返回 **1304 分钟（21.7 小时）**，
 *   成都 → 重庆（直线约 270km）也高达 **约 19 小时**，
 *   而这两段按城际估算模型（高铁/飞机纯时长）分别为 283 分钟、约 90 分钟。
 *   若照搬高德数据，"时间够不够"就会按十几二十小时去算，
 *   本来一天能走完的跨城行程会被误判成「时间不够」或被规划器顺延丢弃。
 *
 * 阈值取 **100km**（用户确认）：
 *   广佛线 ≈ 30km、上海↔苏州 ≈ 90km 仍走高德真实城际公交/地铁；
 *   北京↔天津 ≈ 120km、成都↔重庆 ≈ 270km 及更远，现实里主要是高铁/飞机，
 *   用估算模型更贴近实际（京津城际也会因此返回估算时长，用户已接受）。
 */
const INTERCITY_REAL_MAX_KM = 100;

// ---------------------------------------------------------------------------
// 内部类型
// ---------------------------------------------------------------------------

/** 通勤一端：坐标 + 用于城市识别的地址文本（出发点用 params.origin.label），key 用于缓存/矩阵 */
type Waypoint = {
  key: string;
  lat: number;
  lng: number;
  address: string;
};

/** 估算耗时结果（内部统一消毒过的最小形状） */
type Estimate = { minutes: number; km: number };

// ---------------------------------------------------------------------------
// ③ 模块级缓存（换交通方式 / 换出发点 / 换城际方式时必须 clearRouteCache）
// ---------------------------------------------------------------------------

const legCache = new Map<string, RouteLeg>();

// ---------------------------------------------------------------------------
// ② 请求节流：全局串行队列 + 最小间隔
// ---------------------------------------------------------------------------

/** 队列尾：保证任意时刻最多 1 个高德请求在飞（并发 1） */
let queueTail: Promise<void> = Promise.resolve();

/** 上一次请求真正发出的时间戳（毫秒）；0 表示本次会话还没发过请求 */
let lastRequestStartedAt = 0;

function now(): number {
  return Date.now();
}

function sleep(ms: number): Promise<void> {
  return new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });
}

/**
 * 把任务挂到全局队列尾部串行执行。
 * 队列尾自带 catch，保证一次失败不会污染后续任务（本模块也不依赖队列抛错）。
 */
function runExclusive<T>(task: () => Promise<T>): Promise<T> {
  const run = queueTail.then(task);
  queueTail = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

/** 在队列里等待「距上次请求开始」满 REQUEST_GAP_MS，再发起请求 */
async function requestRouteOnce(a: Waypoint, b: Waypoint, mode: TravelMode): Promise<RouteLeg | null> {
  return runExclusive(async () => {
    const sinceLast = now() - lastRequestStartedAt;
    if (sinceLast < REQUEST_GAP_MS) {
      await sleep(REQUEST_GAP_MS - sinceLast);
    }
    lastRequestStartedAt = now();
    try {
      // 公交路径规划必须带城市：跨城的城际公交/地铁（如广州→佛山的「广佛线」）
      // 不传 city/cityd 就查不到，会被误降级成铁路估算。
      // 解析不出城市时传 null，服务层会自行省略该参数（实测不传 city 仍可查同城方案）。
      const hint = { fromCity: cityOf(a.address), toCity: cityOf(b.address) };
      return await getRoutingService().route(a, b, mode, hint);
    } catch {
      // RoutingService 契约上不抛错，这里只是最后一道保险
      return null;
    }
  });
}

/**
 * 取一段真实路径：串行 + 最小间隔 + 最多重试 2 次（300ms → 900ms 退避）。
 * 全部尝试都失败（或返回 null）才返回 null，由调用方走估算降级。
 */
async function requestRouteWithRetry(
  a: Waypoint,
  b: Waypoint,
  mode: TravelMode,
): Promise<RouteLeg | null> {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
    if (attempt > 0) {
      const backoff = RETRY_BACKOFF_MS[Math.min(attempt - 1, MAX_RETRIES - 1)];
      await sleep(backoff);
    }
    const leg = await requestRouteOnce(a, b, mode);
    if (leg !== null) return leg;
  }
  return null;
}

// ---------------------------------------------------------------------------
// 数值 / 分段工具
// ---------------------------------------------------------------------------

/** 数值消毒：非有限值一律降级为 fallback，杜绝 NaN / Infinity 传播到 UI */
function finiteOr(value: number, fallback: number): number {
  return Number.isFinite(value) ? value : fallback;
}

/** 地址 → 城市；guessCity 只接受字符串，脏数据（undefined 等）也不能抛出去 */
function cityOf(address: string): string | null {
  try {
    return guessCity(address);
  } catch {
    return null;
  }
}

/** 交通方式 → 分段类型（公共交通在拿不到线路明细时只能记 'other'） */
function segmentKindOf(mode: TravelMode): LegSegment['kind'] {
  if (mode === 'walk') return 'walk';
  if (mode === 'bike') return 'bike';
  if (mode === 'drive') return 'drive';
  return 'other';
}

/** estimateTravel 的安全包装：纯计算，理论上不抛，脏坐标时保底 0 */
function safeEstimate(a: Waypoint, b: Waypoint, mode: TravelMode): Estimate {
  try {
    const leg = estimateTravel(a, b, mode);
    return { minutes: finiteOr(leg.minutes, 0), km: finiteOr(leg.km, 0) };
  } catch {
    return { minutes: 0, km: 0 };
  }
}

/** 最后一道降级：按指定交通方式做直线估算（永不抛错；步行时标签就是「步行」） */
function straightLineLeg(a: Waypoint, b: Waypoint, mode: TravelMode): RouteLeg {
  const { minutes, km } = safeEstimate(a, b, mode);
  return {
    mode,
    minutes,
    km,
    source: 'estimate',
    estimated: true,
    segments: [{ kind: segmentKindOf(mode), label: MODE_LABEL[mode], minutes, km }],
  };
}

/** 采用真实接口结果：保留 path / segments / summary，provenance 以服务自报为准 */
function realLeg(real: RouteLeg, fallbackMode: TravelMode): RouteLeg {
  const source: RouteLeg['source'] = real.source === 'estimate' ? 'estimate' : 'amap';
  return {
    mode: real.mode ?? fallbackMode,
    minutes: finiteOr(real.minutes, 0),
    km: finiteOr(real.km, 0),
    source,
    // 只要含任何估算成分（或服务自报 estimate）就是 true
    estimated: source === 'estimate' || real.estimated === true,
    segments: Array.isArray(real.segments) ? real.segments : [],
    ...(real.path !== undefined ? { path: real.path } : {}),
    ...(real.summary !== undefined ? { summary: real.summary } : {}),
    ...(real.intercity !== undefined ? { intercity: real.intercity } : {}),
  };
}

/** 城际模型的 segments 明细：航班 → 'flight'，其余（高铁/动车/普速/公路渡轮）→ 'rail' */
function intercitySegment(leg: IntercityLeg): LegSegment {
  return {
    kind: leg.mode === 'flight' ? 'flight' : 'rail',
    // 需求：城际交通不显示票价。这里就把票价从文案里去掉，
    // 不能指望每个界面各自过滤 —— 界面直接用这个 label，漏一处票价就露出来了。
    label: stripFare(leg.summary) || INTERCITY_FALLBACK_LABEL,
    minutes: finiteOr(leg.minutes, 0),
    km: finiteOr(leg.km, 0),
  };
}

/** 城际模块的真实线路判定（见 INTERCITY_TRANSIT_KINDS 说明） */
function hasIntercityTransit(segments: LegSegment[] | undefined): boolean {
  if (!Array.isArray(segments)) return false;
  return segments.some((segment) => segment != null && INTERCITY_TRANSIT_KINDS.includes(segment.kind));
}

// ---------------------------------------------------------------------------
// 同城 / 城际判定
// ---------------------------------------------------------------------------

/**
 * 是否同城：两端地址都用 guessCity 解析，取到城市就比城市名；
 * 任一端解析不出城市时，退化为直线距离 ≤ SAME_CITY_MAX_KM（80km）兜底，
 * 避免「识别不出城市」被一律误判成跨城（那会把同城行程算成高铁/飞机）。
 */
function isSameCity(a: Waypoint, b: Waypoint): boolean {
  const cityA = cityOf(a.address);
  const cityB = cityOf(b.address);
  if (cityA !== null && cityB !== null) return cityA === cityB;
  try {
    return haversineKm(a, b) <= SAME_CITY_MAX_KM;
  } catch {
    return true;
  }
}

function originWaypoint(params: PlanParams): Waypoint {
  return {
    key: ORIGIN_KEY,
    lat: params.origin.lat,
    lng: params.origin.lng,
    address: params.origin.label,
  };
}

// ---------------------------------------------------------------------------
// 单段解析：同城模块 / 城际模块
// ---------------------------------------------------------------------------

/**
 * 城际估算段：先试真实数据（只在拿到 bus/subway/rail 分段时才采用），否则走 estimateIntercity。
 * path 一律留空（铁路/航班不在图上画线）。
 */
function intercityEstimateLeg(a: Waypoint, b: Waypoint, params: PlanParams): RouteLeg {
  const fromCity = cityOf(a.address);
  const toCity = cityOf(b.address);
  try {
    const leg = estimateIntercity(
      { lat: a.lat, lng: a.lng, ...(fromCity === null ? {} : { city: fromCity }) },
      { lat: b.lat, lng: b.lng, ...(toCity === null ? {} : { city: toCity }) },
      { prefer: params.intercity ?? null, days: params.days },
    );
    return {
      mode: params.travelMode,
      minutes: finiteOr(leg.minutes, 0),
      km: finiteOr(leg.km, 0),
      source: 'estimate',
      estimated: true,
      segments: [intercitySegment(leg)],
      intercity: leg,
    };
  } catch {
    // 城际模块异常（未就绪 / 内部抛错）：按当前交通方式做直线估算，保证本段非空
    return straightLineLeg(a, b, params.travelMode);
  }
}

/** 解析一段通勤；内部已逐层 try/catch，正常路径不抛错（仍由 fetchOneLeg 再兜一层） */
async function resolveLeg(from: Waypoint, to: Waypoint, params: PlanParams): Promise<RouteLeg> {
  if (isSameCity(from, to)) {
    // 同城：真实接口 → 失败降级为「步行估算」
    const real = await requestRouteWithRetry(from, to, params.travelMode);
    if (real !== null) return realLeg(real, params.travelMode);
    return straightLineLeg(from, to, 'walk');
  }

  // 跨城：按距离分两种处理（见 INTERCITY_REAL_MAX_KM 的说明）
  //   · 近距离跨城（广佛线这类，直线 ≤ 300km）→ 优先用高德真实城际公交/地铁数据
  //   · 远距离跨城（广州→成都这类）→ 直接用城际估算模型（高铁/飞机纯时长），
  //     而且**不发这次请求**，顺带省一次配额
  // 只按 segments 判定即可：无 Key 的 FallbackRoutingService 从不产出 segments，
  // 因此「有 bus/subway/rail 分段」本身就等价于「这条线路来自高德」。
  if (haversineKm(from, to) <= INTERCITY_REAL_MAX_KM) {
    const real = await requestRouteWithRetry(from, to, params.travelMode);
    if (real !== null && hasIntercityTransit(real.segments)) {
      return realLeg(real, params.travelMode);
    }
  }
  return intercityEstimateLeg(from, to, params);
}

/** 缓存键：`${fromKey}|${toKey}|${mode}|${intercity ?? ''}`（见文件头 ③） */
function cacheKey(fromKey: string, toKey: string, params: PlanParams): string {
  return `${fromKey}|${toKey}|${params.travelMode}|${params.intercity ?? ''}`;
}

/** 餐厅不在 byId 里 / 坐标非法时的占位段：不请求、不估算，但保证数组长度对齐 */
function unknownWaypointLeg(params: PlanParams): RouteLeg {
  return {
    mode: params.travelMode,
    minutes: 0,
    km: 0,
    source: 'estimate',
    estimated: true,
    segments: [],
  };
}

/** 取一段：先查缓存（命中不发请求），再解析并写回缓存；永不 reject */
async function fetchOneLeg(from: Waypoint, to: Waypoint, params: PlanParams): Promise<RouteLeg> {
  const key = cacheKey(from.key, to.key, params);
  const cached = legCache.get(key);
  if (cached !== undefined) return cached;

  let leg: RouteLeg;
  try {
    leg = await resolveLeg(from, to, params);
  } catch {
    // resolveLeg 内部已逐层兜底，这里兜住任何意外，保证「每段都有值」
    leg = straightLineLeg(from, to, params.travelMode);
  }
  legCache.set(key, leg);
  return leg;
}

// ---------------------------------------------------------------------------
// 对外函数 1：默认顺序（纯计算，不调任何接口）
// ---------------------------------------------------------------------------

/**
 * 用直线估算矩阵排出「通勤时间最少」的默认顺序（同步、纯函数、不调任何接口）。
 *
 * 算法（与 planner.ts 的调度口径保持一致）：
 *   1. must 餐厅：最近邻（nearestNeighbor，从出发点出发）+ 2-opt 求序；
 *   2. want / optional：按最近邻贪心追加到当前游标之后（O(n²) 次矩阵查询，全部命中矩阵缓存）；
 *   3. 返回餐厅 id 数组（不含出发点）。
 *
 * 代价函数只取分钟数（estimateTravel 已含 1.3 绕行系数与分方式速度），
 * 这样「最少通勤时间」与「最短跳转」在估算口径下是同一件事。
 *
 * 复杂度：O(n²) 估算 + 2-opt 的常数次迭代（n 为勾选餐厅数，规模很小）。
 */
/**
 * 穷举上限：餐厅数不超过这个值时，直接枚举全排列取最优，保证「通勤时间最少」不是近似。
 * 7! = 5040 个排列，配合缓存过的代价矩阵是毫秒级，完全值得。
 */
const EXHAUSTIVE_MAX_N = 7;

/** 全排列（Heap 算法，递归版）：n ≤ 7 时规模很小，直接返回数组更直观 */
function permutations(items: number[]): number[][] {
  if (items.length <= 1) return [items];
  const out: number[][] = [];
  for (let i = 0; i < items.length; i += 1) {
    const rest = items.slice(0, i).concat(items.slice(i + 1));
    for (const tail of permutations(rest)) out.push([items[i], ...tail]);
  }
  return out;
}

export function defaultOrder(restaurants: Restaurant[], params: PlanParams): string[] {
  if (restaurants.length < 2) return restaurants.map((restaurant) => restaurant.id);

  const places = new Map(restaurants.map((restaurant): [string, { lat: number; lng: number }] => [
    restaurant.id,
    { lat: restaurant.lat, lng: restaurant.lng },
  ]));
  const base = makeEstimateMatrix(places, params);

  /**
   * 默认顺序的代价矩阵。
   *
   * 关键（用户要求「通勤时间也应算上同城和不同城的估算」）：
   * **跨城段必须改用城际估算模型**（高铁/飞机），不能沿用直线估算 ——
   * 直线估算按「当前选择的交通方式」算速度：广州→成都在步行口径下是 358 小时，
   * 量级失真好几个数量级，会把这个跨城跳转的权重压得过大，
   * 连累同城内部的先后顺序也被算歪，于是「默认顺序是否通勤最少」就不可信了。
   * 同城段仍用直线估算：同城尺度下它足够准，且完全不消耗接口配额。
   */
  const byId = new Map(restaurants.map((restaurant): [string, Restaurant] => [restaurant.id, restaurant]));
  const originWaypoint: Waypoint = {
    key: ORIGIN_KEY,
    lat: params.origin.lat,
    lng: params.origin.lng,
    address: params.origin.label,
  };
  /**
   * 把 id 转成 Waypoint。
   * 注意：餐厅不是 Waypoint（缺 key 字段），必须显式构造，不能直接返回 Restaurant。
   */
  const toWaypoint = (key: string): Waypoint | null => {
    if (key === ORIGIN_KEY) return originWaypoint;
    const restaurant = byId.get(key);
    return restaurant
      ? { key: restaurant.id, lat: restaurant.lat, lng: restaurant.lng, address: restaurant.address }
      : null;
  };

  /** 缓存：-1 表示「同城或算不出」，用负值避开 0 分钟的歧义 */
  const crossMinutesCache = new Map<string, number>();
  const crossCityMinutes = (a: string, b: string): number | null => {
    const ck = `${a}|${b}`;
    const hit = crossMinutesCache.get(ck);
    if (hit !== undefined) return hit < 0 ? null : hit;

    const wa = toWaypoint(a);
    const wb = toWaypoint(b);
    let value = -1;
    if (wa !== null && wb !== null && !isSameCity(wa, wb)) {
      try {
        const ca = cityOf(wa.address);
        const cb = cityOf(wb.address);
        const leg = estimateIntercity(
          { lat: wa.lat, lng: wa.lng, ...(ca === null ? {} : { city: ca }) },
          { lat: wb.lat, lng: wb.lng, ...(cb === null ? {} : { city: cb }) },
          { prefer: params.intercity ?? null, days: params.days },
        );
        const minutes = Number(leg?.minutes);
        if (Number.isFinite(minutes) && minutes > 0) value = minutes;
      } catch {
        value = -1;
      }
    }
    crossMinutesCache.set(ck, value);
    return value < 0 ? null : value;
  };

  const matrix = {
    source: 'estimate' as const,
    minutes: (a: string, b: string): number => crossCityMinutes(a, b) ?? base.minutes(a, b),
    km: (a: string, b: string): number => base.km(a, b),
  };

  // tsp.ts 按下标工作：-1 代表出发点，i 代表 restaurants[i]
  const idAt = (index: number): string => (index === -1 ? ORIGIN_KEY : restaurants[index].id);
  const cost = (a: number, b: number): number => matrix.minutes(idAt(a), idAt(b));

  // ---- 小规模直接穷举，保证「通勤时间最少」是**最优解**而不是近似 ----
  // 上面的代价矩阵已经同时包含同城估算与跨城城际估算，所以这里比较的就是真实口径的通勤总和。
  if (restaurants.length <= EXHAUSTIVE_MAX_N) {
    const all = permutations(restaurants.map((_, index) => index));
    let best: number[] = all[0] ?? [];
    let bestCost = Number.POSITIVE_INFINITY;
    for (const perm of all) {
      let total = 0;
      let prev = -1; // -1 = 出发点
      for (const index of perm) {
        total += cost(prev, index);
        prev = index;
      }
      if (total < bestCost) {
        bestCost = total;
        best = perm;
      }
    }
    return best.map((index) => restaurants[index].id);
  }

  /**
   * 8 家及以上才会走到这里（≤7 家上面已经穷举出精确最优解）。
   *
   * **不按 priority 分组**：必去 / 想去 / 可选只是标签，不影响任何程序行为（用户明确要求）。
   * 曾经这里是「必去先走 TSP、其余按最近邻贪心插入」，导致同一批餐厅
   * 只因为标签不同就得到不同的默认顺序；现已改为对全部餐厅统一做
   * 「最近邻 + 2-opt」，与标签完全无关。
   */
  const allIdx = restaurants.map((_, index) => index);
  const orderIdx = twoOpt(nearestNeighbor(-1, allIdx, cost), cost, -1);

  return orderIdx.map((index) => restaurants[index].id);
}

// ---------------------------------------------------------------------------
// 对外函数 2：按给定顺序逐段取通勤
// ---------------------------------------------------------------------------

/**
 * 按给定顺序逐段取通勤：同城走真实接口，跨城走城际模块，失败逐段降级。
 *
 * 返回数组语义（严格约定）：
 *   legs[0] = 出发点 → orderedIds[0]
 *   legs[i] = orderedIds[i-1] → orderedIds[i]
 *   legs.length === orderedIds.length（餐厅缺失 / 坐标非法时也要占位）
 *
 * 请求策略见文件头 ②：只取链条上的 N+1 段、串行、间隔 250ms、每段最多重试 2 次；
 * 所有结果（含降级估算）按 ③ 入缓存。**本函数永不 reject**。
 */
export async function fetchLegsInOrder(
  orderedIds: string[],
  byId: Map<string, Restaurant>,
  params: PlanParams,
): Promise<RouteLeg[]> {
  const legs: RouteLeg[] = [];
  let previous = originWaypoint(params);

  for (const id of orderedIds) {
    const target = byId.get(id);
    if (target === undefined || !Number.isFinite(target.lat) || !Number.isFinite(target.lng)) {
      // 数据缺失：本段无法规划，但仍要占位；游标不前移（沿用上一个已知点）
      legs.push(unknownWaypointLeg(params));
      continue;
    }
    const current: Waypoint = {
      key: id,
      lat: target.lat,
      lng: target.lng,
      address: target.address,
    };
    legs.push(await fetchOneLeg(previous, current, params));
    previous = current;
  }

  return legs;
}

// ---------------------------------------------------------------------------
// 对外函数 3：默认顺序 + 真实耗时（后台预取与「生成行程」共用同一份缓存）
// ---------------------------------------------------------------------------

/**
 * 组合：defaultOrder(...)（本地估算排顺序）+ fetchLegsInOrder(...)（真实耗时）。
 * 已预取过的段会命中 ③ 的缓存，不再重复打高德接口。**永不 reject**。
 */
export async function buildDefaultRoute(
  restaurants: Restaurant[],
  params: PlanParams,
): Promise<{ order: string[]; legs: RouteLeg[] }> {
  const order = defaultOrder(restaurants, params);
  const byId = new Map(restaurants.map((restaurant): [string, Restaurant] => [restaurant.id, restaurant]));

  let legs: RouteLeg[];
  try {
    legs = await fetchLegsInOrder(order, byId, params);
  } catch {
    // fetchLegsInOrder 契约上不 reject；万一 reject 也补齐长度，绝不把异常抛给 UI
    legs = order.map(() => unknownWaypointLeg(params));
  }

  return { order, legs };
}

// ---------------------------------------------------------------------------
// 对外函数 4：清空缓存
// ---------------------------------------------------------------------------

/**
 * 清空内部缓存。
 * 换交通方式 / 换出发点 / 换城际方式时必须调用：
 * 缓存键不含出发点坐标与城市，key 上也区分不了新旧出发点。
 */
export function clearRouteCache(): void {
  legCache.clear();
}
