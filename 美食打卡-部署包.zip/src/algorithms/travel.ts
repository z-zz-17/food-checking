import { haversineKm } from './coords';
import type { TravelLeg, TravelMode } from '../types';

const SPEED_KMH: Record<TravelMode, number> = {
  walk: 4.5,
  bike: 15,
  drive: 25,
  transit: 18,
};

export const MODE_LABEL: Record<TravelMode, string> = {
  walk: '步行',
  bike: '骑行',
  drive: '驾车',
  transit: '公共交通',
};

const DETOUR = 1.3;

export function estimateTravel(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
  mode: TravelMode,
): TravelLeg {
  const direct = haversineKm(a, b);
  const km = direct * DETOUR;
  const hours = km / SPEED_KMH[mode];
  return { mode, minutes: hours * 60, km };
}
