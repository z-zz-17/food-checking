import type { PlanParams, Restaurant, TripPlan, TripStop, Warning } from '../types';
import { estimateTravel } from './travel';
import { toMinutes, toHHMM } from '../utils/format';

export function reorderDay(
  plan: TripPlan,
  dayIndex: number,
  newStopIds: string[],
  byId: Map<string, Restaurant>,
  params: PlanParams,
): { plan: TripPlan; warnings: Warning[] } {
  const day = plan.days[dayIndex];
  // 第 12 条：出发时间与可用时段合并后，所有天共用同一窗口
  const dailyStart = toMinutes(params.startTime);
  const dailyEnd = toMinutes(params.endTime);
  const warnings: Warning[] = [];

  const ordered = newStopIds.map((id, idx) => {
    const original = day.stops.find((s) => s.restaurantId === id);
    return { ...original!, order: idx + 1 };
  });

  let curTime = dailyStart;
  let prevLoc: { lat: number; lng: number } | null = params.origin;
  let totalKm = 0;
  let totalCost = 0;
  const rebuilt: TripStop[] = [];

  for (const stop of ordered) {
    const r = byId.get(stop.restaurantId);
    if (!r) {
      rebuilt.push(stop);
      continue;
    }
    const leg = estimateTravel(prevLoc, r, params.travelMode);
    let arrive = curTime + leg.minutes;
    const windows = r.hours.map((h) => ({ start: toMinutes(h.open), end: toMinutes(h.close) }));
    const openWindow = windows.find((w) => arrive < w.end && arrive >= w.start);
    if (!openWindow) {
      const nextOpen = windows.find((w) => arrive < w.start)?.start;
      if (nextOpen != null && nextOpen <= dailyEnd) {
        arrive = nextOpen;
        warnings.push({
          level: 'info',
          message: `「${r.name}」此时未营业，已顺延至 ${toHHMM(nextOpen)}`,
        });
      } else {
        warnings.push({
          level: 'warning',
          message: `「${r.name}」调整后可能超出营业/可用时段`,
        });
      }
    }
    const depart = arrive + r.stayMinutes;
    rebuilt.push({
      ...stop,
      arriveAt: toHHMM(arrive),
      departAt: toHHMM(depart),
      travelFromPrev: { mode: params.travelMode, minutes: leg.minutes, km: leg.km },
    });
    if (depart > dailyEnd) {
      warnings.push({
        level: 'danger',
        message: `第${dayIndex + 1}天安排已超出可用时段（${params.endTime}）`,
      });
    }
    curTime = depart;
    prevLoc = r;
    totalKm += leg.km;
    totalCost += r.avgPrice * params.peopleCount;
  }

  const newDay = { ...day, stops: rebuilt, totalCost, totalDistanceKm: totalKm };
  const newDays = plan.days.map((d, i) => (i === dayIndex ? newDay : d));

  return {
    plan: { ...plan, days: newDays, warnings: [...plan.warnings, ...warnings] },
    warnings,
  };
}
