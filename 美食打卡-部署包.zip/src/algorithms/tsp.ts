export type CostFn = (a: number, b: number) => number;

export function nearestNeighbor(start: number, nodes: number[], cost: CostFn): number[] {
  const unvisited = new Set(nodes);
  const path: number[] = [];
  let cur = start;
  while (unvisited.size > 0) {
    let best: number | null = null;
    let bestCost = Infinity;
    for (const n of unvisited) {
      const c = cost(cur, n);
      if (c < bestCost) {
        bestCost = c;
        best = n;
      }
    }
    path.push(best!);
    unvisited.delete(best!);
    cur = best!;
  }
  return path;
}

export function twoOpt(path: number[], cost: CostFn, start: number, maxIters = 200): number[] {
  const n = path.length;
  if (n < 4) return path;
  let best = [...path];
  let improved = true;
  let iter = 0;
  while (improved && iter < maxIters) {
    improved = false;
    iter++;
    for (let i = 0; i < n - 1; i++) {
      for (let k = i + 1; k < n; k++) {
        const candidate = [...best];
        reverseRange(candidate, i, k);
        if (totalCost(candidate, start, cost) < totalCost(best, start, cost) - 1e-9) {
          best = candidate;
          improved = true;
        }
      }
    }
  }
  return best;
}

function reverseRange(arr: number[], i: number, k: number) {
  while (i < k) {
    [arr[i], arr[k]] = [arr[k], arr[i]];
    i++;
    k--;
  }
}

export function totalCost(path: number[], start: number, cost: CostFn): number {
  let total = 0;
  let prev = start;
  for (const node of path) {
    total += cost(prev, node);
    prev = node;
  }
  return total;
}
