import type {
  PlanParams,
  Restaurant,
  TripDay,
  TripPlan,
  TripStop,
  Warning,
} from '../types';
import { estimateTravel } from './travel';
import { toMinutes, toHHMM, fmtMinutes } from '../utils/format';
import { uid } from '../utils/id';

/** 矩阵里代表「出发地」的特殊键 */
export const ORIGIN_KEY = '__origin__';

/**
 * 通勤耗时/里程矩阵，**按餐厅 id 做键**（出发地用 ORIGIN_KEY）。
 *
 * 为什么用 id 而不是数组下标：规划器**完全采用调用方给定的顺序**（默认顺序由
 * routePlan.defaultOrder 算出，用户还能在「打卡顺序」里拖拽修改），
 * 下标会随调用方的数组变化而静默错位；用 id 做键才能保证每一段「上一站 > 本站」
 * 都取到正确的那份通勤数据。
 *
 * 之所以做成可注入：让「真实路径规划」与「离线估算」共用同一套调度算法。
 *  - 不传（默认）：直线距离 × 1.3 绕路系数 + 速度模型，同步、离线、可单元测试；
 *  - 传入：调用方先用高德 JS API 异步预取两两耗时（真实道路/公交地铁线路）再注入。
 */
export type LegMatrix = {
  source: 'amap' | 'estimate';
  minutes(a: string, b: string): number;
  km(a: string, b: string): number;
  /**
   * 可选：返回该段的完整通勤信息（含分段明细与真实路径折线）。
   * 提供时会被挂到 `TripStop.travelFromPrev`，供反馈展示（步行×分/地铁×号线×分）
   * 与地图绘制真实路线；不提供时 planner 只关心 minutes/km（估算矩阵就是这样）。
   */
  leg?(a: string, b: string): import('../types/planning').RouteLeg | undefined;
};

/** 用估算模型构建矩阵（带缓存） */
export function makeEstimateMatrix(
  places: Map<string, { lat: number; lng: number }>,
  params: PlanParams,
): LegMatrix {
  const cache = new Map<string, { minutes: number; km: number }>();
  const at = (k: string) => (k === ORIGIN_KEY ? params.origin : places.get(k));
  const leg = (a: string, b: string) => {
    const key = `${a}>${b}`;
    let v = cache.get(key);
    if (!v) {
      const A = at(a);
      const B = at(b);
      v = A && B ? estimateTravel(A, B, params.travelMode) : { minutes: 0, km: 0 };
      cache.set(key, v);
    }
    return v;
  };
  return {
    source: 'estimate',
    minutes: (a, b) => leg(a, b).minutes,
    km: (a, b) => leg(a, b).km,
  };
}

/**
 * 调度参数（**已不再来自滑杆**）。
 *
 * 界面上原来那两个滑杆已经改掉：
 *   · 「少走路 ↔ 多打卡」→ 换成**数轴**，可以直接点出"每天最多几站"，
 *     值存在 `params.maxStopsPerDay`（1–8，默认 5）；
 *   · 「严格守时 ↔ 灵活」→ **移除**，超出每日时间窗的宽容度固定为 60 分钟。
 *
 * `params.weightWalk` / `params.weightTime` 字段仍保留在类型与存档里（避免数据迁移），
 * 但**不再被任何逻辑读取**。
 */
const FIXED_OVERTIME_LIMIT_MIN = 60;
const DEFAULT_MAX_STOPS_PER_DAY = 5;
const MAX_STOPS_PER_DAY_LIMIT = 20;

function tuningOf(params: PlanParams): { maxStopsPerDay: number; overtimeLimit: number } {
  const raw = Number(params.maxStopsPerDay);
  const value =
    Number.isFinite(raw) && raw >= 1 ? Math.floor(raw) : DEFAULT_MAX_STOPS_PER_DAY;
  return {
    maxStopsPerDay: Math.min(MAX_STOPS_PER_DAY_LIMIT, value),
    overtimeLimit: FIXED_OVERTIME_LIMIT_MIN,
  };
}

function openWindows(r: Restaurant): { start: number; end: number }[] {
  return r.hours.map((h) => ({ start: toMinutes(h.open), end: toMinutes(h.close) }));
}

function isOpenAt(windows: { start: number; end: number }[], t: number): boolean {
  return windows.some((w) => t >= w.start && t < w.end);
}

function emptyPlan(params: PlanParams, warnings: Warning[]): TripPlan {
  return {
    id: uid('trip-'),
    title: '美食打卡行程',
    days: [],
    totalBudget: params.totalBudget,
    peopleCount: params.peopleCount,
    warnings,
  };
}

export function buildPlan(
  restaurants: Restaurant[],
  params: PlanParams,
  matrixInput?: LegMatrix,
): TripPlan {
  const warnings: Warning[] = [];
  /**
   * **完全保留调用方给定的顺序**。
   *
   * 默认顺序由 routePlan.defaultOrder 按「通勤最少」算出，用户还能在「打卡顺序」里拖拽。
   *
   * 这里曾经写成 `[...must, ...want, ...optional]`（必去优先重新分组），会打乱调用方顺序 ——
   * 而通勤数据是按调用方顺序逐段取回来的（N+1 段），顺序一变，规划器就会去查
   * **没取过**的「上一站 > 本站」组合，退回直线估算（跨城时是几十小时的荒谬值），
   * 把可用天数耗光，于是**后面的餐厅被整批丢弃**。
   *
   * 已用真实数据复现：出发地上海城隍庙 + 上海 2 家 + 成都 3 家，
   * 只要优先级不一致（成都=必去、上海=想去），落位就从 5/5 掉到 2/5，
   * 并打印「排不进已设置的天数」；全部设为「想去」时则完全正常。
   *
   * 结论：必去/想去/可选**不再影响行程顺序**，只作为信息展示。
   */
  const pool = [...restaurants];

  if (pool.length === 0) {
    return emptyPlan(params, [{ level: 'warning', message: '请先勾选至少一家餐厅' }]);
  }

  for (const r of pool) {
    if (!r.lat || !r.lng) {
      warnings.push({ level: 'warning', message: `「${r.name}」缺少坐标，将在规划中跳过` });
    }
  }

  const valid = pool.filter((r) => r.lat && r.lng);
  if (valid.length === 0) {
    return emptyPlan(params, [
      { level: 'danger', message: '没有可定位的餐厅，请补充坐标或地理编码' },
    ]);
  }

  const places = new Map(valid.map((r) => [r.id, { lat: r.lat, lng: r.lng }]));
  const matrix = matrixInput ?? makeEstimateMatrix(places, params);
  const tuning = tuningOf(params);

  // ---------- 顺序：**完全采用调用方给定的顺序** ----------
  // 这个顺序来自「打卡顺序」编辑器：默认顺序由 routePlan.defaultOrder 按「通勤时间最少」算出，
  // 用户也可以拖拽改（需求第 2 条：按设定顺序执行）。
  // 规划器**绝不能再自己排一次**，原因有两个：
  //   1) 会覆盖用户手动设定的顺序，拖拽白做；
  //   2) 更致命：通勤数据是按「调用方顺序」逐段取回来的（N+1 段，见 routePlan），
  //      自排顺序后规划器会去查从未取过的『上一站 > 本站』组合 → 查不到就退回直线估算，
  //      于是地图画成虚线、卡片里没有交通方式；跨城段更会出现几十小时的荒谬时间，
  //      把可用天数耗光，导致后面的餐厅被误判成「排不进」。这两类反馈都源于此。
  const ordered = valid;
  const { days, warnings: schedWarnings } = schedule(ordered, params, matrix, tuning);
  warnings.push(...schedWarnings);

  if (days.length === 0) {
    // 一家都没排进去时，逐店的"排不进"提示只会刷屏，换成一条总览
    const kept = warnings.filter(
      (w) => !(w.level === 'danger' && w.message.includes('排不进已设置的')),
    );
    return emptyPlan(params, [
      ...kept,
      {
        level: 'danger',
        message: `在 ${params.days} 天、每日 ${params.startTime}-${params.endTime} 的时段内无法安排任何一家餐厅：请增加天数、放宽时段，或改用更快的交通方式`,
      },
    ]);
  }

  return {
    id: uid('trip-'),
    title: '美食打卡行程',
    days,
    totalBudget: params.totalBudget,
    peopleCount: params.peopleCount,
    warnings,
  };
}

/**
 * 把排序后的餐厅放进「天数 × 每日时段」的格子里。
 *
 * 与旧实现的关键差异：
 *  1. `params.days` 是**硬上限**，不会无限生成天数；
 *  2. 只有真正放进站点时才创建那一天 → 不再产生空白天；
 *  3. `params.startTime` 决定**第 1 天**的出发时刻，其余天从 `dailyStart` 开始；
 *  4. `params.weightWalk` 决定每天最多排几站；
 *  5. `params.weightTime` 决定每天最多允许超出 `dailyEnd` 多少分钟。
 */
function schedule(
  ordered: Restaurant[],
  params: PlanParams,
  matrix: LegMatrix,
  tuning: { maxStopsPerDay: number; overtimeLimit: number },
): { days: TripDay[]; warnings: Warning[] } {
  const warnings: Warning[] = [];
  // 第 12 条：出发时间与可用时段已合并，所有天共用同一个「开始时间–结束时间」窗口
  const dailyStart = toMinutes(params.startTime);
  const dailyEnd = toMinutes(params.endTime);
  const days: TripDay[] = [];

  /** 绝对时间轴（分钟，第 1 天 00:00 = 0）。通勤允许跨夜，所以不能用"当天几点"表示 */
  let curAbs = dailyStart;
  let prevKey = ORIGIN_KEY;
  /** 每天已排几站（用于"少走路↔多打卡"的软上限） */
  const stopsPerDay = new Map<number, number>();

  /** 只在真正落位时创建当天，避免留下空白天 */
  const ensureDay = (i: number): TripDay => {
    while (days.length <= i) {
      days.push({
        date: `第${days.length + 1}天`,
        stops: [],
        totalCost: 0,
        totalDistanceKm: 0,
      });
    }
    return days[i];
  };

  /** 一天之内的"钟点"（0–1439），用于营业时间判断 */
  const clockOf = (abs: number): number => ((abs % 1440) + 1440) % 1440;

  /**
   * 到达的绝对时间 → 该排在第几天（0 基）。
   * 超过当天窗口就算"已经跨到后面那天"：`ceil((abs − dailyEnd) / 1440)`。
   */
  const dayIndexOf = (abs: number): number => Math.max(0, Math.ceil((abs - dailyEnd) / 1440));

  for (const r of ordered) {
    const legMinutes = matrix.minutes(prevKey, r.id);
    const legKm = matrix.km(prevKey, r.id);
    const stay = Number.isFinite(r.stayMinutes) && r.stayMinutes > 0 ? r.stayMinutes : 60;
    /** 出发时刻 + 通勤时间 = 到达的绝对时间（长通勤可跨夜） */
    const arriveAbs = curAbs + legMinutes;

    let k = dayIndexOf(arriveAbs);
    let placed = false;

    while (!placed) {
      if (k >= params.days) {
        warnings.push({
          level: 'danger',
          message: `「${r.name}」排不进已设置的 ${params.days} 天行程，未纳入本方案（可增加天数或改乘高铁/飞机）`,
        });
        break;
      }

      // 若到达早于该天窗口开始（跨夜后凌晨到达）→ 等到窗口开始
      let startAbs = Math.max(arriveAbs, k * 1440 + dailyStart);

      // 营业时间：未开门就等开门；当天已无营业时段则顺延次日
      const windows = openWindows(r);
      if (windows.length > 0 && !isOpenAt(windows, clockOf(startAbs))) {
        const nextOpen = windows.find((w) => clockOf(startAbs) < w.start)?.start;
        if (nextOpen == null) {
          k += 1;
          continue;
        }
        startAbs = k * 1440 + nextOpen;
      }

      const departAbs = startAbs + stay;
      const overtime = departAbs - (k * 1440 + dailyEnd);

      /**
       * 每天最多排几站 —— 按用户选择做成**硬上限**（宁可丢餐厅也不超站）。
       * 触发时先顺延次日；天数已排满则如实提示并放弃这家。
       */
      const capped = (stopsPerDay.get(k) ?? 0) >= tuning.maxStopsPerDay;
      if (capped) {
        if (k + 1 < params.days) {
          k += 1;
          continue;
        }
        warnings.push({
          level: 'danger',
          message:
            `「${r.name}」未纳入本方案：按「少走路↔多打卡」的设置每天最多 ${tuning.maxStopsPerDay} 站，` +
            `${params.days} 天已排满（可把滑杆往「多打卡」一侧调，或增加天数）`,
        });
        break;
      }
      // 超出每日时段过多 → 顺延次日；已是最后一天则放行（不因此丢餐厅）
      if (overtime > tuning.overtimeLimit && k + 1 < params.days) {
        k += 1;
        continue;
      }

      const waited = startAbs - arriveAbs;
      if (waited > 0) {
        warnings.push({
          level: 'info',
          message: `「${r.name}」等待 ${fmtMinutes(waited)} 至 ${toHHMM(clockOf(startAbs))}${
            waited > 30 ? '（等待较久，可考虑调整出发时间）' : ''
          }`,
        });
      }
      if (overtime > 0) {
        warnings.push({
          level: 'info',
          message: `「${r.name}」超出每日可用时段约 ${Math.round(overtime)} 分钟（已按「灵活」偏好放行）`,
        });
      }

      // 若矩阵能给出完整通勤信息（真实分段明细 + 路径折线），就挂到站点上，
      // 供反馈展示（步行×分钟 / 地铁2号线×分钟）与地图绘制真实路线
      const full = matrix.leg?.(prevKey, r.id);
      const stop: TripStop = {
        restaurantId: r.id,
        order: (stopsPerDay.get(k) ?? 0) + 1,
        arriveAt: toHHMM(clockOf(startAbs)),
        departAt: toHHMM(clockOf(departAbs)),
        travelFromPrev: full
          ? {
              mode: full.mode,
              minutes: full.minutes,
              km: full.km,
              source: full.source,
              estimated: full.estimated,
              segments: full.segments,
              path: full.path,
              intercitySummary: full.intercity?.summary,
            }
          : {
              mode: params.travelMode,
              minutes: legMinutes,
              km: legKm,
              source: matrix.source,
              estimated: matrix.source === 'estimate',
            },
      };
      const day = ensureDay(k);
      day.stops.push(stop);
      day.totalCost += r.avgPrice * params.peopleCount;
      day.totalDistanceKm += legKm;
      stopsPerDay.set(k, (stopsPerDay.get(k) ?? 0) + 1);

      curAbs = departAbs;
      prevKey = r.id;
      placed = true;
    }
  }

  return { days, warnings };
}
