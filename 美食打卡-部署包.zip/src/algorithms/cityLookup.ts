/**
 * 坐标 → 城市名（用于「地址里认不出城市」时的兜底）。
 *
 * 为什么需要它（这是一个真实踩过的坑）：
 *   不合理判定按「不同城个数 M ≥ min(N, 3)」来判。
 *   如果两家相距很远的餐厅都因为地址里没写城市而被统一标成同一个「异地」，
 *   那么 M 会被**少算**，本该判不合理的行程就会被放行 —— 与规则不符。
 *   （例如：出发点成都 + 一家重庆的店 + 一家上海的店，地址都没写城市，
 *    会被算成 M=2 而不是 3，于是 N=3 时阈值 3 判不出来。）
 *
 * 做法：按坐标找最近的城市中心（CITY_POINTS 共 158 城）。
 *   同城的两家会得到同一个城市名，异地的两家会得到不同的城市名 —— 正好符合判定的需要。
 */
import { CITY_POINTS } from '../data/intercityData';
import { haversineKm } from './coords';

/** 距离任何城市中心都超过这个公里数时，认为无法可靠归属 */
const MAX_SNAP_KM = 150;

/**
 * 取该坐标最近的城市名；超过 maxKm 或坐标非法时返回 null。
 * 纯计算，不联网。
 */
export function cityByCoords(lat: number, lng: number, maxKm: number = MAX_SNAP_KM): string | null {
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  let bestCity: string | null = null;
  let bestKm = Infinity;
  for (const c of CITY_POINTS) {
    const km = haversineKm({ lat, lng }, { lat: c.lat, lng: c.lng });
    if (km < bestKm) {
      bestKm = km;
      bestCity = c.city;
    }
  }
  return bestKm <= maxKm ? bestCity : null;
}
