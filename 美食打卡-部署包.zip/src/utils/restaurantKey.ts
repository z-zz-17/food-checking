/**
 * 「同一家店」的判定键。
 *
 * 口径（用户选定）：**店名 + 地址都相同**才算同一家店。
 * 归一化：去首尾空白、把连续空白压成一个、忽略英文大小写。
 *
 * 注意：**故意不比对坐标** —— 连锁店同名但店址不同（例如"星巴克 春熙路店"与
 * "星巴克 宽窄巷子店"）必须算两家，否则会被错误合并。
 */
export function restaurantKey(r: { name?: string; address?: string }): string {
  const norm = (v: string | undefined): string =>
    (v ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
  return `${norm(r.name)}|${norm(r.address)}`;
}
