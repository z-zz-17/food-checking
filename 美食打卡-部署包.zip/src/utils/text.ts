/**
 * 文本清理小工具。
 */

/**
 * 去掉城际摘要里的票价。
 *
 * 需求：城际交通只显示方式与时间，**不显示票价**。
 * 城际模型给出的 summary 形如
 *   「飞机 · 约 4小时43分 · 里程约 1548.2km · 票价约 ¥1029（建议行程 ≥ 3 天）」
 * 这段文字会被同时用在两个地方（RouteLeg.intercity 摘要、分段 label），
 * 所以必须统一走这个函数，不能在界面里各处自己写正则。
 */
export function stripFare(s: string | undefined | null): string {
  if (!s) return '';
  return s
    .replace(/[·・|]\s*票价[^·・|]*/g, '')
    .replace(/票价[^·・|]*/g, '')
    .replace(/\s*[·・|]\s*$/, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}
