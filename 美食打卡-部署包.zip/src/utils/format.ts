export function fmtMoney(n: number): string {
  return `¥${Math.round(n)}`;
}

export function fmtKm(km: number): string {
  return km < 1 ? `${Math.round(km * 1000)}m` : `${km.toFixed(1)}km`;
}

export function fmtMinutes(min: number): string {
  const total = Math.max(0, Math.round(min));
  if (total < 60) return `${total}分钟`;
  const h = Math.floor(total / 60);
  const m = total % 60;
  return m > 0 ? `${h}小时${m}分` : `${h}小时`;
}

export function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

export function toHHMM(min: number): string {
  // 必须先取整再拆分：min 常带有小数（按速度模型算出的通勤耗时），
  // 否则会拼出 "15:10.084842882815792" 这种脏字符串
  const total = Math.round(min);
  const day = Math.floor(total / 1440);
  const rem = ((total % 1440) + 1440) % 1440;
  const h = Math.floor(rem / 60);
  const m = rem % 60;
  const hh = String(h).padStart(2, '0');
  const mm = String(m).padStart(2, '0');
  return day > 0 ? `+${day}天 ${hh}:${mm}` : `${hh}:${mm}`;
}
