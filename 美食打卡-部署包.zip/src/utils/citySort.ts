/**
 * 城市名 → 拼音首字母（清单页按城市分类、城市按首字母排序都要用）。
 *
 * 为什么不手写 158 城的拼音表：
 *   实测 `localeCompare(?, 'zh-Hans-CN')` 就是**拼音序**（北京 B → 成都 C → 上海 S），
 *   所以"首字母"可以用 26 个拼音锚点字反推出来，不必维护一张容易写错的表。
 *
 * 多音字怎么办：
 *   系统的拼音库对多音字会挑一个读音，实测「长沙」被按 zhǎng 排进了 Z 组 ✗，
 *   因此这里保留一张**人工覆盖表**：覆盖表优先，其余走锚点推断。
 *   发现哪个城市字母不对，往 CITY_INITIAL_OVERRIDE 里加一行即可。
 */

/** 每个字母一个"拼音锚点字"（避开 i / u / v 三个不存在的声母） */
const ANCHOR_LETTERS = 'ABCDEFGHJKLMNOPQRSTWXYZ';
const ANCHOR_CHARS = [
  '阿', // A
  '八', // B
  '擦', // C
  '搭', // D
  '蛾', // E
  '发', // F
  '噶', // G
  '哈', // H
  '击', // J
  '喀', // K
  '垃', // L
  '妈', // M
  '拿', // N
  '哦', // O
  '啪', // P
  '期', // Q
  '然', // R
  '撒', // S
  '塌', // T
  '挖', // W
  '西', // X —— 实测锚点必须用「西」：用「昔」时西安/西宁会被判到 W 组
  //     （系统把「厦门」读成 shà，所以厦门必须走上面的覆盖表）
  '压', // Y
  '匝', // Z
];

/**
 * 多音字/易错城市首字母覆盖表（覆盖表优先于系统拼音）。
 * 目前收录的都是实测或已知容易出错的：长沙（系统读 zhǎng）、长治/长春（同）、
 * 六安（lù）、蚌埠（bèng）、亳州（bó）、单县（shàn）、铅山（yán）、重庆（chóng）、厦门（xià）。
 */
export const CITY_INITIAL_OVERRIDE: Record<string, string> = {
  长沙: 'C',
  长治: 'C',
  长春: 'C',
  长海: 'C',
  六安: 'L',
  蚌埠: 'B',
  亳州: 'B',
  单县: 'S',
  铅山: 'Y',
  重庆: 'C',
  厦门: 'X',
};

/** 认不出城市时归到这一组，永远排在最后 */
export const UNKNOWN_CITY = '未识别城市';

/** 取城市名的拼音首字母；空/非法输入返回 '#' */
export function cityInitial(city: string | undefined | null): string {
  const name = (city ?? '').trim();
  if (name === '') return '#';
  const override = CITY_INITIAL_OVERRIDE[name];
  if (override) return override;
  if (name === UNKNOWN_CITY) return '#';
  // 从后往前找第一个"不大于该城市名"的锚点字
  for (let i = ANCHOR_CHARS.length - 1; i >= 0; i -= 1) {
    if (name.localeCompare(ANCHOR_CHARS[i], 'zh-Hans-CN') >= 0) return ANCHOR_LETTERS[i];
  }
  return '#';
}

/**
 * 城市排序：先按首字母，再按拼音；「未识别城市」永远最后。
 */
export function compareCity(a: string, b: string): number {
  if (a === b) return 0;
  if (a === UNKNOWN_CITY) return 1;
  if (b === UNKNOWN_CITY) return -1;
  const la = cityInitial(a);
  const lb = cityInitial(b);
  if (la !== lb) return la < lb ? -1 : 1;
  return a.localeCompare(b, 'zh-Hans-CN');
}
