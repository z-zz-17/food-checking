import { TopBar } from './components/layout/TopBar';
import { ControlPanel } from './components/layout/ControlPanel';
import { MobileDrawer } from './components/layout/MobileDrawer';
import { MapView } from './components/map/MapView';
import { MapErrorBoundary } from './components/map/MapErrorBoundary';
import { CheckInDialog } from './components/stats/CheckInDialog';
import { SettingsDialog } from './components/layout/SettingsDialog';
import { useUiStore } from './store/useUiStore';
import { useRestaurantStore } from './store/useRestaurantStore';

export default function App() {
  const checkInRestaurantId = useUiStore((s) => s.checkInRestaurantId);
  const closeCheckIn = useUiStore((s) => s.closeCheckIn);
  const restaurants = useRestaurantStore((s) => s.restaurants);
  const restaurant = restaurants.find((r) => r.id === checkInRestaurantId);

  return (
    <div className="flex h-full flex-col bg-cream">
      <TopBar />
      <div className="flex flex-1 overflow-hidden">
        <aside className="hidden w-[360px] shrink-0 border-r border-black/5 md:block">
          <ControlPanel />
        </aside>
        <main className="relative flex-1">
          <MapErrorBoundary>
            <MapView />
          </MapErrorBoundary>
        </main>
      </div>
      <MobileDrawer />
      {restaurant && <CheckInDialog restaurant={restaurant} onClose={closeCheckIn} />}
      {/* 设置弹窗自己判断开关状态，这里始终挂载即可 */}
      <SettingsDialog />
    </div>
  );
}
