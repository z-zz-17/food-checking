import { create } from 'zustand';
import type { CheckIn, PlanParams, TripPlan } from '../types';
import { storage } from '../services/storage';

const DEFAULT_PARAMS: PlanParams = {
  origin: { lat: 30.6568, lng: 104.0815, label: '成都春熙路' },
  startTime: '10:00',
  endTime: '21:00',
  days: 1,
  travelMode: 'walk',
  totalBudget: 1000,
  peopleCount: 2,
  weightWalk: 50,
  weightTime: 50,
  /** 每天最多几站：界面上是「每天最多几站」数轴（1–8） */
  maxStopsPerDay: 5,
  intercity: null,
};

/**
 * 参数迁移。
 * 第 12 条把「出发时间 + 可用时段起 + 可用时段止」三字段合并成了「开始时间 + 结束时间」，
 * 但 localStorage 里可能还存着旧结构（dailyStart / dailyEnd）。这里做一次性兼容，
 * 避免老用户升级后参数丢失或变成 undefined。
 */
function migrateParams(raw: unknown): PlanParams {
  const s = (raw ?? {}) as Record<string, unknown>;
  const pickTime = (v: unknown, fallback: string): string =>
    typeof v === 'string' && /^\d{1,2}:\d{2}$/.test(v.trim()) ? v.trim() : fallback;
  const pickNum = (v: unknown, fallback: number): number =>
    typeof v === 'number' && Number.isFinite(v) ? v : fallback;

  return {
    origin:
      s.origin && typeof s.origin === 'object'
        ? (s.origin as PlanParams['origin'])
        : DEFAULT_PARAMS.origin,
    startTime: pickTime(s.startTime, pickTime(s.dailyStart, DEFAULT_PARAMS.startTime)),
    endTime: pickTime(s.endTime, pickTime(s.dailyEnd, DEFAULT_PARAMS.endTime)),
    days: Math.min(7, Math.max(1, Math.round(pickNum(s.days, DEFAULT_PARAMS.days)))),
    travelMode:
      s.travelMode === 'walk' || s.travelMode === 'bike' || s.travelMode === 'drive' || s.travelMode === 'transit'
        ? s.travelMode
        : DEFAULT_PARAMS.travelMode,
    totalBudget: pickNum(s.totalBudget, DEFAULT_PARAMS.totalBudget),
    peopleCount: Math.max(1, Math.round(pickNum(s.peopleCount, DEFAULT_PARAMS.peopleCount))),
    weightWalk: Math.min(100, Math.max(0, pickNum(s.weightWalk, DEFAULT_PARAMS.weightWalk))),
    weightTime: Math.min(100, Math.max(0, pickNum(s.weightTime, DEFAULT_PARAMS.weightTime))),
    // 每天最多几站（旧存档没有这个字段时回落默认值 5）；
    // weightWalk / weightTime 仅作兼容保留，程序不再读取它们。
    maxStopsPerDay: Math.min(
      20,
      Math.max(1, Math.round(pickNum(s.maxStopsPerDay, DEFAULT_PARAMS.maxStopsPerDay ?? 5))),
    ),
    intercity: s.intercity === 'rail' || s.intercity === 'flight' ? s.intercity : null,
  };
}

type PlanStore = {
  params: PlanParams;
  plan: TripPlan | null;
  checkIns: Record<string, CheckIn>;
  setParams: (patch: Partial<PlanParams>) => void;
  setPlan: (p: TripPlan | null) => void;
  addCheckIn: (restaurantId: string, c: CheckIn) => void;
  removeCheckIn: (restaurantId: string) => void;
  resetAll: () => void;
};

export const usePlanStore = create<PlanStore>((set, get) => ({
  params: migrateParams(storage.load<unknown>('params', null)),
  plan: storage.load<TripPlan | null>('plan', null),
  checkIns: storage.load<Record<string, CheckIn>>('checkins', {}),

  setParams: (patch) => {
    const next = { ...get().params, ...patch };
    storage.save('params', next);
    set({ params: next });
  },

  setPlan: (p) => {
    storage.save('plan', p);
    set({ plan: p });
  },

  addCheckIn: (restaurantId, c) => {
    const next = { ...get().checkIns, [restaurantId]: c };
    storage.save('checkins', next);
    set({ checkIns: next });
  },

  removeCheckIn: (restaurantId) => {
    const next = { ...get().checkIns };
    delete next[restaurantId];
    storage.save('checkins', next);
    set({ checkIns: next });
  },

  resetAll: () => {
    storage.clearAll();
    set({ params: DEFAULT_PARAMS, plan: null, checkIns: {} });
  },
}));
