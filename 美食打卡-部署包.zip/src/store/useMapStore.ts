import { create } from 'zustand';

type PickResult = { lat: number; lng: number } | null;

type MapStore = {
  pickMode: boolean;
  pickedCoord: PickResult;
  hoveredId: string | null;
  selectedRestaurantId: string | null;
  focusId: string | null;
  startPick: () => void;
  finishPick: (coord: PickResult) => void;
  clearPicked: () => void;
  cancelPick: () => void;
  setHovered: (id: string | null) => void;
  setSelected: (id: string | null) => void;
  focusRestaurant: (id: string) => void;
  clearFocus: () => void;
};

export const useMapStore = create<MapStore>((set) => ({
  pickMode: false,
  pickedCoord: null,
  hoveredId: null,
  selectedRestaurantId: null,
  focusId: null,

  startPick: () => set({ pickMode: true, pickedCoord: null }),
  // 双击确定位置后「仍留在点选模式」，可连续添加多家
  finishPick: (coord) => set({ pickMode: true, pickedCoord: coord }),
  // 只清掉待确认坐标（新增表单保存/取消时用），不退出点选模式
  clearPicked: () => set({ pickedCoord: null }),
  // 真正退出点选模式（面板上的「取消选址」）
  cancelPick: () => set({ pickMode: false, pickedCoord: null }),

  setHovered: (id) => set({ hoveredId: id }),
  setSelected: (id) => set({ selectedRestaurantId: id }),
  focusRestaurant: (id) => set({ focusId: id }),
  clearFocus: () => set({ focusId: null }),
}));
