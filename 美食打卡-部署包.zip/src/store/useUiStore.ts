import { create } from 'zustand';

/** 左侧面板的标签页；地图需要据此决定"是否显示路线"（只有规划页显示） */
export type UiTab = 'list' | 'plan' | 'stats';

type UiStore = {
  /** 当前标签页。放在 store 里而不是组件内部 state，
   *  是因为地图（MapView）在另一个子树里，需要读到它 */
  activeTab: UiTab;
  setActiveTab: (tab: UiTab) => void;

  checkInRestaurantId: string | null;
  openCheckIn: (id: string) => void;
  closeCheckIn: () => void;

  /** 设置弹窗（内含「清空所有数据」） */
  settingsOpen: boolean;
  openSettings: () => void;
  closeSettings: () => void;
};

export const useUiStore = create<UiStore>((set) => ({
  activeTab: 'list',
  setActiveTab: (activeTab) => set({ activeTab }),

  checkInRestaurantId: null,
  openCheckIn: (id) => set({ checkInRestaurantId: id }),
  closeCheckIn: () => set({ checkInRestaurantId: null }),

  settingsOpen: false,
  openSettings: () => set({ settingsOpen: true }),
  closeSettings: () => set({ settingsOpen: false }),
}));
