import { create } from 'zustand';
import type { Restaurant } from '../types';
import { storage } from '../services/storage';
import { uid } from '../utils/id';
import { restaurantKey } from '../utils/restaurantKey';
import { SAMPLE_RESTAURANTS } from '../data/sampleTrips';
import { usePlanStore } from './usePlanStore';

type RestaurantStore = {
  restaurants: Restaurant[];
  selectedIds: string[];
  addRestaurant: (r: Omit<Restaurant, 'id'>) => Restaurant;
  updateRestaurant: (id: string, patch: Partial<Restaurant>) => void;
  removeRestaurant: (id: string) => void;
  toggleSelect: (id: string) => void;
  selectAll: (ids: string[]) => void;
  clearSelection: () => void;
  /** 合并历史重复卡片，返回被合并掉的数量（0 = 没有重复） */
  dedupeRestaurants: () => number;
  /** 清空餐厅清单（写入空数组，避免下次加载又装回内置样例） */
  resetAll: () => void;
};

function loadInitial(): Restaurant[] {
  const saved = storage.load<Restaurant[] | null>('restaurants', null);
  if (saved === null) {
    storage.save('restaurants', SAMPLE_RESTAURANTS);
    return SAMPLE_RESTAURANTS;
  }
  return saved;
}

export const useRestaurantStore = create<RestaurantStore>((set, get) => ({
  restaurants: loadInitial(),
  selectedIds: [],

  /**
   * 新增餐厅。
   *
   * 【去重，用户反馈过"清单会出现 n 个相同的店"】
   * 过去的实现是无条件 `{ id: uid('r-'), ...data }` —— 零查重，
   * 而「样例行程」按钮每点一次就把整套样例追加一次（搜索添加同理），
   * 于是同一家店可以出现任意多张卡片，还会让行程与统计重复计算同一家。
   *
   * 现在的口径（用户选定）：**店名 + 地址都相同 = 同一家店**；
   * 命中已有卡片时**不新增**，而是用本次内容**覆盖**旧卡片，
   * 并且**保留原有 id** —— 行程、打卡记录里对这家店的引用因此不会失效。
   */
  addRestaurant: (data) => {
    const key = restaurantKey(data);
    const existing = get().restaurants.find((r) => restaurantKey(r) === key);
    if (existing) {
      const merged: Restaurant = { ...existing, ...data, id: existing.id };
      const next = get().restaurants.map((r) => (r.id === existing.id ? merged : r));
      storage.save('restaurants', next);
      set({ restaurants: next });
      return merged;
    }
    const r: Restaurant = { id: uid('r-'), ...data };
    const next = [...get().restaurants, r];
    storage.save('restaurants', next);
    set({ restaurants: next });
    return r;
  },

  updateRestaurant: (id, patch) => {
    const next = get().restaurants.map((r) => (r.id === id ? { ...r, ...patch } : r));
    storage.save('restaurants', next);
    set({ restaurants: next });
  },

  removeRestaurant: (id) => {
    const next = get().restaurants.filter((r) => r.id !== id);
    storage.save('restaurants', next);
    set({
      restaurants: next,
      selectedIds: get().selectedIds.filter((sid) => sid !== id),
    });
  },

  toggleSelect: (id) => {
    const cur = get().selectedIds;
    const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    set({ selectedIds: next });
  },

  selectAll: (ids) => set({ selectedIds: ids }),

  clearSelection: () => set({ selectedIds: [] }),

  /**
   * 一次性合并**历史遗留**的重复卡片（老版本的存档里已经躺着重复数据）。
   *
   * 口径（用户选定）：自动合并、**保留最早出现的那一张**，无需用户手动操作。
   * 同时尽量不丢用户已经产生的数据：
   *   · 被合并卡片的「已勾选」状态并入保留者；
   *   · 被合并卡片若在「打卡记录」里有数据、而保留者没有，则把打卡记录迁到保留者上。
   *
   * 由入口 main.tsx 在渲染前调用一次。
   */
  dedupeRestaurants: () => {
    const list = get().restaurants;
    const kept: Restaurant[] = [];
    const seen = new Map<string, Restaurant>();
    /** 被合并掉的 id → 保留的 id */
    const idMap = new Map<string, string>();

    for (const r of list) {
      const key = restaurantKey(r);
      const first = seen.get(key);
      if (first === undefined) {
        seen.set(key, r);
        kept.push(r);
      } else {
        idMap.set(r.id, first.id);
      }
    }
    if (idMap.size === 0) return 0;

    // ① 勾选状态：被合并 id 的勾选并入保留者
    const selected = new Set(get().selectedIds);
    for (const [droppedId, keptId] of idMap) {
      if (!selected.has(droppedId)) continue;
      selected.delete(droppedId);
      selected.add(keptId);
    }

    // ② 打卡记录：被合并 id 的打卡迁到保留者（保留者已有打卡则不覆盖，但清掉旧的）
    const plan = usePlanStore.getState();
    for (const [droppedId, keptId] of idMap) {
      const record = plan.checkIns[droppedId];
      if (record === undefined) continue;
      if (plan.checkIns[keptId] === undefined) plan.addCheckIn(keptId, record);
      plan.removeCheckIn(droppedId);
    }

    storage.save('restaurants', kept);
    set({ restaurants: kept, selectedIds: [...selected] });
    return idMap.size;
  },

  /**
   * 清空餐厅清单。
   *
   * 注意这里写的是**空数组**而不是 remove 掉键：`loadInitial()` 在"存档不存在"时
   * 会自动装回内置样例行程，直接删键会让用户以为没清干净。
   */
  resetAll: () => {
    storage.save('restaurants', []);
    set({ restaurants: [], selectedIds: [] });
  },
}));
