/**
 * 餐厅「类别」（菜系）分组清单。
 *
 * 分组顺序与组内子项都由用户指定，**不要随意增删或调序**：
 *   各地菜系 → 快餐 → 西餐 → 披萨 → 小吃 → 饮料 → 甜品 → 各国菜
 * 其中「各国菜」**必须包含 日本料理 / 韩国料理 / 泰国菜 / 法国菜 / 意大利菜**。
 *
 * 为什么分组标题（各地菜系、各国菜）不作为可选值：
 *   用户选的是具体菜系（川菜、日本料理…），分组只负责在下来框里分块展示，
 *   这样统计页与预算分组才能按具体菜系统计。
 *
 * 注意：清单不是封闭集合 —— 搜索添加时会带进高德给的类别（如「串串」「生煎」），
 * 表单会把这些"清单外的现有类别"动态补进选项里，见 RestaurantForm。
 */
export type CuisineGroup = {
  /** 分组标题（不可选） */
  label: string;
  /** 组内可选的具体菜系 */
  items: readonly string[];
};

export const CUISINE_GROUPS: readonly CuisineGroup[] = [
  {
    label: '各地菜系',
    items: [
      '川菜',
      '粤菜',
      '湘菜',
      '鲁菜',
      '苏菜',
      '浙菜',
      '闽菜',
      '徽菜',
      '本帮菜',
      '京菜',
      '东北菜',
      '西北菜',
      '云南菜',
      '贵州菜',
      '客家菜',
      '清真菜',
      '火锅',
      '烧烤',
    ],
  },
  { label: '快餐', items: ['快餐', '汉堡', '炸鸡', '简餐', '盖饭', '面馆', '米线', '饺子', '包子'] },
  { label: '西餐', items: ['西餐', '牛排', '意面', '自助餐', '早午餐'] },
  { label: '披萨', items: ['披萨'] },
  { label: '小吃', items: ['小吃', '早茶', '生煎', '肠粉', '串串', '麻辣烫', '卤味', '煎饼', '凉皮'] },
  { label: '饮料', items: ['饮料', '奶茶', '咖啡', '果汁', '茶饮', '酒馆'] },
  { label: '甜品', items: ['甜品', '蛋糕', '面包', '冰淇淋', '糖水', '糕点'] },
  {
    label: '各国菜',
    items: [
      // 这五个是用户点名必须有的
      '日本料理',
      '韩国料理',
      '泰国菜',
      '法国菜',
      '意大利菜',
      // 其余常见各国菜
      '越南菜',
      '印度菜',
      '墨西哥菜',
      '西班牙菜',
      '土耳其菜',
      '美式',
      '新加坡菜',
    ],
  },
];

/** 兜底类别：清单里都没有合适的就用它 */
export const OTHER_CUISINE = '其他';

/** 清单内的全部可选类别（含「其他」） */
export const ALL_CUISINES: readonly string[] = [
  ...CUISINE_GROUPS.flatMap((group) => group.items),
  OTHER_CUISINE,
];

/** 该类别是否在清单内（清单外的类别来自搜索添加，不能当成错误） */
export function isKnownCuisine(value: string): boolean {
  return ALL_CUISINES.includes(value);
}

/** 兜底大类：清单外的类别（如搜索添加带来的"私房菜"）与「其他」都归到这里 */
export const FALLBACK_GROUP: CuisineGroup = { label: OTHER_CUISINE, items: [OTHER_CUISINE] };

/** 全部大类（8 个正式分组 + 兜底「其他」），顺序固定不可乱 */
export const CUISINE_GROUP_LIST: readonly CuisineGroup[] = [...CUISINE_GROUPS, FALLBACK_GROUP];

/** 按大类名取分组；名字非法时回落到兜底组 */
export function groupByLabel(label: string): CuisineGroup {
  return CUISINE_GROUP_LIST.find((group) => group.label === label) ?? FALLBACK_GROUP;
}

/** 某个具体类别属于哪个大类；清单外类别归兜底组 */
export function groupOfCuisine(value: string): CuisineGroup {
  return CUISINE_GROUPS.find((group) => group.items.includes(value)) ?? FALLBACK_GROUP;
}
