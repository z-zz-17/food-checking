/**
 * 出行分段的配色。
 *
 * ⚠️ 关于「地铁官方标志色」的实情（已实测，不要被名字误导）：
 *   1) **高德不提供线路颜色** —— 我把公交/地铁线路对象的字段全打出来过：
 *      只有 departure_stop / arrival_stop / name / id / type / distance / duration /
 *      polyline / bustimetag / start_time / end_time / via_num / via_stops，没有任何颜色字段。
 *   2) 维基百科的「XX地铁颜色」模板能给出官方色值，但**本机环境访问不到维基**
 *      （高德接口通、维基不通），所以无法自动抓取官方色值。
 *
 * 因此这里采用**稳定且互异**的配色：同一条线路名永远得到同一个颜色，
 * 不同线路之间尽量区分。它**不是官方色值**，只用于在地图上区分线路。
 *
 * 想换成官方色值：把色值填进下面的 LINE_COLOR_OVERRIDES 即可（键是线路名去掉括号后的形式，
 * 例如「地铁2号线」「广佛线」），命中覆盖表就优先用它。
 */

/** 步行 / 骑行 / 驾车 / 其它 的固定配色（自主选择，追求与底图对比清晰） */
export const MODE_COLORS: Record<string, string> = {
  walk: '#6B7280', // 灰：步行
  bike: '#0EA5E9', // 天蓝：骑行
  drive: '#3B82F6', // 蓝：驾车
  ferry: '#0F766E',
  flight: '#7C3AED',
  other: '#9CA3AF',
};

/** 地铁/公交线路的候选配色（相邻线路尽量拉开色相） */
const LINE_PALETTE = [
  '#E4002B', // 红
  '#0072CE', // 蓝
  '#F5A623', // 橙
  '#00A650', // 绿
  '#8E44AD', // 紫
  '#00A0E9', // 亮蓝
  '#D4145A', // 玫红
  '#795548', // 棕
  '#009688', // 青
  '#C0CA33', // 黄绿
  '#F06292', // 粉
  '#455A64', // 蓝灰
];

/**
 * 官方色值覆盖表（留空表示全部使用上面的稳定配色）。
 * 例：{ '地铁2号线': '#F58220', '广佛线': '#00A650' }
 */
export const LINE_COLOR_OVERRIDES: Record<string, string> = {};

/** 稳定哈希：同一线路名 → 同一颜色（FNV-1a） */
function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** 去掉线路名里的括号备注：`地铁2号线(犀浦--龙泉驿)` → `地铁2号线` */
export function normalizeLineName(name: string): string {
  return name.replace(/\(.*?\)/g, '').trim() || name;
}

/**
 * 取某条线路的显示颜色。
 * 优先级：官方覆盖表 → 稳定调色板（按线路名哈希，跨会话稳定）。
 */
export function lineColor(rawName: string): string {
  const name = normalizeLineName(rawName);
  const override = LINE_COLOR_OVERRIDES[name];
  if (override) return override;
  // 特殊线路名给药：城际线统一一个色，便于一眼区分
  if (/城际|广佛|广清|佛肇|莞惠|深莞/.test(name)) return '#0F766E';
  return LINE_PALETTE[hash(name) % LINE_PALETTE.length];
}

/** 按 kind 取颜色（步行/骑行/驾车等） */
export function segmentColor(kind: string, label?: string): string {
  if (kind === 'subway' || kind === 'bus' || kind === 'rail') {
    return lineColor(label ?? '');
  }
  return MODE_COLORS[kind] ?? MODE_COLORS.other;
}
