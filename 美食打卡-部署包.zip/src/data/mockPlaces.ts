import type { GeoSearchResult } from '../types';

export const MOCK_PLACES: GeoSearchResult[] = [
  { id: 'mp-001', name: '陈麻婆豆腐（骡马市店）', address: '成都市青羊区西玉龙街197号', lat: 30.6722, lng: 104.0821, cuisine: '川菜', avgPrice: 60 },
  { id: 'mp-002', name: '龙抄手（总店）', address: '成都市锦江区春熙路南段', lat: 30.6568, lng: 104.0815, cuisine: '小吃', avgPrice: 30 },
  { id: 'mp-003', name: '蜀大侠火锅（春熙路店）', address: '成都市锦江区东大街188号', lat: 30.6537, lng: 104.0766, cuisine: '火锅', avgPrice: 110 },
  { id: 'mp-004', name: '钟水饺（提督街店）', address: '成都市锦江区提督街', lat: 30.6654, lng: 104.0792, cuisine: '小吃', avgPrice: 25 },
  { id: 'mp-005', name: '玉林串串香（玉林店）', address: '成都市武侯区玉林南路', lat: 30.6298, lng: 104.0499, cuisine: '串串', avgPrice: 70 },
  { id: 'mp-006', name: '宽窄巷子·三大炮', address: '成都市青羊区宽窄巷子', lat: 30.6681, lng: 104.0586, cuisine: '小吃', avgPrice: 15 },
  { id: 'mp-007', name: '朱光玉火锅馆', address: '成都市锦江区红星路', lat: 30.6512, lng: 104.0875, cuisine: '火锅', avgPrice: 120 },
  { id: 'mp-008', name: '盘飧市（腌卤店）', address: '成都市锦江区华兴正街', lat: 30.6611, lng: 104.08, cuisine: '卤味', avgPrice: 50 },
  { id: 'mp-009', name: '雷门拉面·春熙路店', address: '成都市锦江区下东大街', lat: 30.6501, lng: 104.0722, cuisine: '日料', avgPrice: 55 },
  { id: 'mp-010', name: '奎星楼街·糖油果子', address: '成都市青羊区奎星楼街', lat: 30.6703, lng: 104.0703, cuisine: '小吃', avgPrice: 10 },
  { id: 'sh-001', name: '小杨生煎（吴江路店）', address: '上海市静安区吴江路', lat: 31.2336, lng: 121.456, cuisine: '生煎', avgPrice: 30 },
  { id: 'sh-002', name: '南翔馒头店（豫园店）', address: '上海市黄浦区豫园路85号', lat: 31.2251, lng: 121.4954, cuisine: '本帮菜', avgPrice: 80 },
  { id: 'sh-003', name: '老正兴菜馆', address: '上海市黄浦区福州路556号', lat: 31.23, lng: 121.476, cuisine: '本帮菜', avgPrice: 120 },
  { id: 'sh-004', name: '静安寺·功德林素菜', address: '上海市静安区南京西路', lat: 31.2267, lng: 121.444, cuisine: '素食', avgPrice: 70 },
  { id: 'sh-005', name: '上海记忆·油墩子', address: '上海市虹口区四川北路', lat: 31.26, lng: 121.487, cuisine: '小吃', avgPrice: 8 },
  { id: 'gz-001', name: '陶陶居（第十甫路）', address: '广州市荔湾区第十甫路', lat: 23.1145, lng: 113.2445, cuisine: '早茶', avgPrice: 90 },
  { id: 'gz-002', name: '广州酒家（文昌店）', address: '广州市荔湾区文昌南路', lat: 23.118, lng: 113.242, cuisine: '早茶', avgPrice: 95 },
  { id: 'gz-003', name: '银记肠粉（上下九店）', address: '广州市荔湾区上下九路', lat: 23.1197, lng: 113.241, cuisine: '肠粉', avgPrice: 25 },
  { id: 'gz-004', name: '莲香楼（第十甫路）', address: '广州市荔湾区第十甫路', lat: 23.115, lng: 113.246, cuisine: '早茶', avgPrice: 60 },
  { id: 'gz-005', name: '宝华面店（长寿路）', address: '广州市荔湾区长寿路', lat: 23.121, lng: 113.238, cuisine: '面食', avgPrice: 35 },
];
