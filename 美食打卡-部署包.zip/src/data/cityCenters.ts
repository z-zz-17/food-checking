/**
 * 演示模式（未配置 VITE_AMAP_KEY）下的近似定位基准点。
 * 配置了高德 Key 后由 AmapGeoService 走真实地理编码，本文件不参与。
 */

export type CenterPoint = { name: string; lat: number; lng: number };

/** 城市中心点：地址里出现城市名即可落到该市范围内 */
export const CITY_CENTERS: CenterPoint[] = [
  { name: '北京', lat: 39.9042, lng: 116.4074 },
  { name: '上海', lat: 31.2304, lng: 121.4737 },
  { name: '广州', lat: 23.1291, lng: 113.2644 },
  { name: '深圳', lat: 22.5431, lng: 114.0579 },
  { name: '成都', lat: 30.5728, lng: 104.0668 },
  { name: '重庆', lat: 29.563, lng: 106.5516 },
  { name: '杭州', lat: 30.2741, lng: 120.1551 },
  { name: '南京', lat: 32.0603, lng: 118.7969 },
  { name: '武汉', lat: 30.5928, lng: 114.3055 },
  { name: '西安', lat: 34.3416, lng: 108.9398 },
  { name: '长沙', lat: 28.2282, lng: 112.9388 },
  { name: '厦门', lat: 24.4798, lng: 118.0894 },
  { name: '苏州', lat: 31.2989, lng: 120.5853 },
  { name: '天津', lat: 39.0842, lng: 117.201 },
  { name: '青岛', lat: 36.0671, lng: 120.3826 },
  { name: '昆明', lat: 25.0389, lng: 102.7183 },
];

/** 城区中心点：地址里只写「XX区」也能定位（优先级高于城市，更精确） */
export const DISTRICT_CENTERS: CenterPoint[] = [
  { name: '锦江区', lat: 30.6577, lng: 104.0834 },
  { name: '青羊区', lat: 30.6739, lng: 104.0617 },
  { name: '武侯区', lat: 30.6415, lng: 104.0435 },
  { name: '成华区', lat: 30.6602, lng: 104.1016 },
  { name: '金牛区', lat: 30.6915, lng: 104.0517 },
  { name: '黄浦区', lat: 31.2317, lng: 121.4847 },
  { name: '静安区', lat: 31.2288, lng: 121.4482 },
  { name: '徐汇区', lat: 31.1883, lng: 121.4365 },
  { name: '浦东新区', lat: 31.2216, lng: 121.5445 },
  { name: '虹口区', lat: 31.2646, lng: 121.5053 },
  { name: '荔湾区', lat: 23.1259, lng: 113.2442 },
  { name: '越秀区', lat: 23.1291, lng: 113.2668 },
  { name: '天河区', lat: 23.1247, lng: 113.3612 },
  { name: '海珠区', lat: 23.0838, lng: 113.3172 },
];
