import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { ErrorBoundary } from './components/layout/ErrorBoundary';
import { useRestaurantStore } from './store/useRestaurantStore';
import 'leaflet/dist/leaflet.css';
import './index.css';

/*
 * 渲染前先合并历史遗留的重复卡片（老版本 addRestaurant 不做查重，
 * 「样例行程」每点一次就追加一整套，导致清单里出现 n 个相同的店）。
 * 必须放在 render 之前，这样首屏就不会闪出重复卡片。
 */
useRestaurantStore.getState().dedupeRestaurants();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {/* 兜底：任何一处渲染抛错都不再是白屏，而是把错误原文显示出来 */}
    <ErrorBoundary label="应用">
      <App />
    </ErrorBoundary>
  </React.StrictMode>,
);
