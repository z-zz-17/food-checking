/**
 * 生产环境最小服务器：静态托管 dist + 反向代理高德 REST 接口。
 *
 * 【为什么必须要有它】
 *   开发环境里 `/amap` 是由 Vite dev server 代理的（见 vite.config.ts），
 *   它把 AMAP_REST_KEY 注入到查询串、并绕开浏览器 CORS 限制。
 *   **静态部署没有这一段** —— 纯静态托管时前端会拿不到真实路况，
 *   自动降级成直线估算（不会崩，但数据是估算值）。
 *
 *   本文件用 Node 内置模块实现同样的代理，**零依赖**：
 *   只要 Node 18+（自带 fetch），`AMAP_REST_KEY=你的key node server.js` 即可。
 *
 * 【安全】REST Key 只存在于服务器进程的环境变量里，绝不会进前端产物。
 *
 * 环境变量：
 *   AMAP_REST_KEY  高德 Web 服务(REST) Key —— 不填则 /amap 返回明确错误
 *   PORT           监听端口，默认 8080
 *   HOST           监听地址，默认 0.0.0.0
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

/** 允许从 server/ 旁边的 .env 读取（避免把 Key 写进命令行历史） */
function loadEnvFile() {
  const file = path.join(__dirname, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Za-z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
loadEnvFile();

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const AMAP_KEY = process.env.AMAP_REST_KEY || '';
/** dist 在上一级目录（部署包里 dist 与 server 同级） */
const DIST = path.join(__dirname, '..', 'dist');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8',
};

/** 高德 REST 反向代理：/amap/v3/xxx → https://restapi.amap.com/v3/xxx?key=... */
async function proxyAmap(req, res, url) {
  if (!AMAP_KEY) {
    res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' });
    res.end(
      JSON.stringify({
        status: '0',
        info: '服务端未配置 AMAP_REST_KEY：请设置环境变量或 server/.env 后重启',
      }),
    );
    return;
  }
  const upstreamPath = url.pathname.replace(/^\/amap/, '');
  const query = url.search ? `${url.search}&key=${encodeURIComponent(AMAP_KEY)}` : `?key=${encodeURIComponent(AMAP_KEY)}`;
  const target = `https://restapi.amap.com${upstreamPath}${query}`;

  try {
    const upstream = await fetch(target, { method: 'GET' });
    const body = await upstream.text();
    res.writeHead(upstream.status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    });
    res.end(body);
  } catch (err) {
    res.writeHead(502, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ status: '0', info: `上游请求失败: ${String(err && err.message)}` }));
  }
}

/** 静态文件 + SPA 回退到 index.html */
function serveStatic(req, res, url) {
  const rel = decodeURIComponent(url.pathname);
  let file = path.join(DIST, rel);
  // 防目录穿越
  if (!file.startsWith(DIST)) {
    res.writeHead(403).end('forbidden');
    return;
  }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    file = path.join(DIST, 'index.html'); // SPA 回退（前端没有路由，但这样更稳）
  }
  if (!fs.existsSync(file)) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('dist 不存在：请先执行 npm run build');
    return;
  }
  const ext = path.extname(file).toLowerCase();
  // 用 path.sep 判断 assets 目录：原写法 /\/assets\// 在 Windows（反斜杠路径）下永远不匹配
  const inAssets = file.includes(`${path.sep}assets${path.sep}`);
  const hashed = inAssets && /-[A-Za-z0-9_]{8,}\.[a-z]+$/.test(file);
  res.writeHead(200, {
    'content-type': MIME[ext] || 'application/octet-stream',
    // 带哈希的产物长缓存，index.html 不缓存，避免发版后用户拿到旧页面
    'cache-control': hashed ? 'public, max-age=31536000, immutable' : 'no-cache',
  });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/healthz') {
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('ok');
    return;
  }
  if (url.pathname.startsWith('/amap/')) {
    void proxyAmap(req, res, url);
    return;
  }
  serveStatic(req, res, url);
});

server.listen(PORT, HOST, () => {
  console.log(`[food-checkin] 静态站点: http://${HOST}:${PORT}`);
  console.log(`[food-checkin] 高德代理: ${AMAP_KEY ? '已启用（Key 已在服务端注入）' : '未配置 AMAP_REST_KEY（将退回估算）'}`);
  console.log(`[food-checkin] dist 目录: ${DIST} ${fs.existsSync(DIST) ? '✓' : '✗ 不存在'}`);
});
