# 美食打卡 · 智能行程规划

从零构建的「美食打卡」网站：自由录入想去的餐厅，系统在营业时间、可用时段、交通方式和总预算的约束下，自动规划出合理的打卡顺序、时间表和路线，并在地图上直观呈现。

## 功能特性

- 美食清单管理：搜索添加 / 手动填写 / 地图点选，编辑删除，批量勾选
- 智能行程规划：TSP（最近邻 + 2-opt）+ 营业时间窗口 + 用餐时段 + 分天切分
- 预算规划：三色进度条、降本建议、三维度花费分布、快捷预设
- 可交互地图：编号 Marker、分天路线、双向联动、拖拽定位、点选新增
- 打卡统计：评分点评、照片、统计面板、分享卡片导出
- 数据持久化：localStorage（版本化）
- 导出 / 导入 JSON，内置 3 套示例行程

## 安装与启动

```bash
npm install
npm run dev
```

打开终端输出的地址（默认 http://localhost:5173），即可使用。无需任何 API Key，内置 Mock 地理数据。

## 配置高德 API Key（可选）

1. 到高德开放平台申请 Web 服务 Key
2. 复制 `.env.example` 为 `.env`，填入 `VITE_AMAP_KEY=你的Key`
3. 重启 dev server

配置后 POI 搜索与地理编码自动切换为真实高德服务；未配置时自动降级为内置 Mock 数据。

## 坐标系统说明

- 默认底图使用高德瓦片（GCJ-02 / 火星坐标系）
- 内部存储统一使用 WGS-84（标准经纬度）
- 渲染前自动 WGS-84 → GCJ-02 转换（src/algorithms/coords.ts）
- 点选/拖拽的高德坐标自动转回 WGS-84 存储
- 切换 OSM/Mapbox/Google 源只需改 src/config/map.ts

## 算法思路

- 路径优化：最近邻 + 2-opt（src/algorithms/tsp.ts）
- 时间窗调度：营业时间窗口 + 用餐时段 + 分天切分（src/algorithms/planner.ts）
- 交通耗时：Haversine × 1.3 绕路系数 × 速度模型（估算值）

## 运行验证

```bash
npm install
npm run dev
npm run typecheck
npm run build
```
